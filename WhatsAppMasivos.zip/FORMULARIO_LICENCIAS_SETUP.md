# Configurar el formulario de solicitud de licencias

Este tutorial te deja el sistema completo funcionando: el cliente pide su
licencia desde el programa, tú la apruebas desde tu pantalla de
"Activación", y el código se manda solo por WhatsApp.

Son 4 partes. Tómate tu tiempo, cada una es sencilla por separado.

---

## Parte 1 — Crear el formulario

1. Ve a [forms.google.com](https://forms.google.com) y crea un formulario nuevo.
2. Título sugerido: **"Solicitud de licencia — Ola"**.
3. Agrega estas preguntas, **exactamente con estos títulos** (el programa
   busca estas palabras exactas para leer las respuestas — si cambias el
   título de una pregunta, avísame para ajustar el código):

   | Pregunta (título exacto) | Tipo de pregunta |
   |---|---|
   | `Código de equipo` | Respuesta corta |
   | `Nombres` | Respuesta corta |
   | `Apellidos` | Respuesta corta |
   | `Número de celular` | Respuesta corta |
   | `Elija su plan` | Lista desplegable — opciones: `Mensual`, `Trimestral` (exactamente así, sin agregarle nada más al texto) |
   | `Banco donde realizó su pago` | Lista desplegable — con los bancos que aceptas (ej. Pichincha, Guayaquil, Produbanco, Pacífico...) |
   | `Número de transacción de su comprobante físico o digital` | Respuesta corta |

   No hace falta pedir el comprobante como archivo adjunto — con el
   número de transacción alcanza para verificar el pago tú mismo.

4. En **Configuración** (el engranaje arriba) → pestaña **"Presentación"**:
   - En "Mensaje de confirmación", escribe algo como:
     *"¡Gracias! Revisaremos tu pago y recibirás tu código de activación por WhatsApp dentro de las próximas 12 horas."*

---

## Parte 2 — Conseguir el enlace para prellenar el código de equipo

Esto es lo que hace que, cuando el cliente le da clic a "Solicitar licencia"
desde el programa, el formulario ya le aparezca con su código escrito.

1. Con el formulario abierto, dale a los 3 puntos (arriba a la derecha) → **"Obtener enlace con datos rellenados previamente"**.
2. Escribe cualquier texto de prueba en la pregunta **"Código de equipo"** (ej. "PRUEBA123") y deja las demás en blanco.
3. Baja hasta el final y dale **"Obtener enlace"** → **"Copiar enlace"**.
4. Pega ese enlace en un bloc de notas. Se va a ver parecido a esto:
   ```
   https://docs.google.com/forms/d/e/1FAIpQLSc.../viewform?usp=pp_url&entry.123456789=PRUEBA123
   ```
5. De ese enlace, necesito **dos pedazos** por separado:
   - Todo lo que está **antes** de `?usp=pp_url` → eso es tu `URL_FORMULARIO_LICENCIA`.
   - El texto `entry.123456789` (el número va a ser distinto en tu caso, y **sin** el `=PRUEBA123` de después) → eso es tu `ENTRY_CODIGO_EQUIPO_LICENCIA`.

**Mándame esos dos valores** y los coloco en el código por ti — o, si prefieres hacerlo tú mismo, ábre `app.py`, busca estas dos líneas cerca del principio, y reemplaza `"PENDIENTE"` por tus valores (entre comillas, tal cual):

```python
URL_FORMULARIO_LICENCIA = "PENDIENTE"
ENTRY_CODIGO_EQUIPO_LICENCIA = "PENDIENTE"
```

Mientras estas dos líneas digan `"PENDIENTE"`, el botón "Solicitar licencia"
se queda oculto en la pantalla de tus clientes — no se rompe nada, solo
no aparece hasta que lo configures.

---

## Parte 3 — Publicar las respuestas para que el programa las pueda leer

1. En el formulario, ve a la pestaña **"Respuestas"** → el ícono verde de Sheets (arriba a la derecha) → **"Crear hoja de cálculo"**.
2. Se abre una hoja nueva de Google Sheets, ya conectada al formulario. Dale cualquier nombre.
3. Con esa hoja abierta: **Archivo → Compartir → Publicar en la web**.
4. En el menú que aparece:
   - Donde dice "Todo el documento", cambia a la hoja específica de respuestas si te da esa opción (normalmente se llama "Respuestas de formulario 1").
   - Donde dice "Página web", cámbialo a **"Valores separados por comas (.csv)"**.
5. Dale **"Publicar"**, confirma, y copia el enlace que te da.
6. Abre "Ola" en tu computadora (la única que tiene la pantalla de Activación), ve a **Activación → Configuración**, y pega ese enlace en **"Enlace de la hoja de Google"**. Dale "Guardar configuración".

---

## Parte 4 — Probar que todo funciona

1. Desde otra computadora (o pídele a alguien de confianza), llena el formulario completo con datos de prueba.
2. En tu programa, ve a **Activación** → dale **"Sincronizar solicitudes"**.
3. Debe aparecer la solicitud de prueba en la lista.
4. Dale "Generar código", revisa el mensaje que se va a mandar, y prueba "Enviar códigos" con un número de WhatsApp tuyo para confirmar que llega bien.

---

## Un recordatorio importante

- **Los precios** (mensual/trimestral) los configuras también en Activación → Configuración — no están fijos en el código, puedes cambiarlos cuando quieras.
- **La aprobación siempre pasa por ti** — nadie recibe un código sin que tú le des clic a "Generar código" y luego a "Enviar códigos". El formulario y la hoja de cálculo solo organizan la información, no activan nada solos.
