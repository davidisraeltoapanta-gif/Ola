# WhatsApp Masivos v3 — Interfaz tipo "WA Campaign"

## Qué cambió respecto a la v2
- **Cambio de tecnología de interfaz**: de tkinter (ventanas nativas simples)
  a una **interfaz web embebida** (HTML/CSS/JS dentro de una ventana de
  escritorio, usando `pywebview`). Esto permite el diseño con sidebar morado,
  tarjetas y estilo moderno que ya tenías en tu versión anterior.
- **Segmentación por rangos**: defines segmentos según la columna `Numero`
  del Excel (ej. Segmento A = 1-50, Segmento B = 51-100), cada uno con su
  propio mensaje y adjuntos.
- **Constructor de mensaje tipo tarjetas ("Flow Builder")**: agregas módulos
  de Texto o Archivo y los reordenas arrastrando con el mouse. Se envían en
  el orden exacto en que los acomodes.
- **Detección automática de tipo de archivo**: imágenes/video, audio o
  documento (PDF, Office), según la extensión.
- **Etiquetas dinámicas**: `{Nombre}`, `{Empresa}`, `{Teléfono}` (esta
  última toma el valor de la columna `Contacto` del Excel).
- **Log en tiempo real con nombres en negrita**.
- **Dashboard real** con datos históricos: enviados del mes, tasa de
  entrega, campañas activas, contactos totales, historial mensual y
  "contactos más frecuentes" (indicador de fidelidad).
- **Reportes exportables**: Excel, CSV, PDF o Log, filtrando por campaña
  y/o mes.
- **Página de Información**: versión del programa y licencia.
- Todo el historial se guarda en una base de datos local (SQLite) en
  `%APPDATA%\WhatsAppMasivos\datos.db` — no se pierde entre sesiones.

## Nueva estructura del Excel

| Numero | Nombre | Celular | Empresa | Contacto |
|--------|--------|---------|---------|----------|
| 1 | Juan Pérez | 593999999999 | Ferretería Central | 0999999999 |
| 2 | María López | 593988888888 | Panadería Ana | 0988888888 |

- **Numero**: ID secuencial (1, 2, 3...) — define a qué segmento pertenece
  cada contacto según el rango que configures en la interfaz.
- **Nombre**: nombre del contacto (etiqueta `{Nombre}`).
- **Celular**: número de WhatsApp real al que se envía el mensaje.
- **Empresa**: nombre de la empresa del contacto (etiqueta `{Empresa}`).
- **Contacto**: un teléfono de referencia que se puede insertar en el texto
  del mensaje con la etiqueta `{Teléfono}` (por ejemplo, un número de
  soporte o callback — no es el número al que se envía).

Las columnas `Estado` y `Error` las agrega el programa automáticamente.

## Archivos del proyecto

- `app.py` — punto de entrada (crea la ventana y expone la API a JavaScript)
- `whatsapp_core.py` — motor de automatización con Selenium
- `db.py` — base de datos local (SQLite) para Dashboard y Reportes
- `ui/index.html`, `ui/style.css`, `ui/app.js` — la interfaz visual completa
- `requirements.txt`, `build.bat`, `installer.iss` — empaquetado
- `generar_excel_ejemplo.py` — genera un Excel de prueba con el formato nuevo

## Cómo probarlo (modo desarrollo, recomendado primero)

```bat
cd C:\WhatsAppMasivosV3
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python generar_excel_ejemplo.py
python app.py
```

Esto abre la ventana directamente. Ideal para iterar rápido antes de
compilar el `.exe`.

### Prueba sugerida con el Excel de ejemplo
El Excel de ejemplo trae 4 contactos con `Numero` 1 a 4. Prueba con:
- **Segmento A**: rango 1–2, con un módulo de Texto ("Hola {Nombre}...")
- **Segmento B**: rango 3–4, con un módulo de Texto distinto + un adjunto

Así verificas que cada segmento realmente envía su propio mensaje.

## Compilar el .exe

```bat
build.bat
```

Genera `dist\WhatsAppMasivos.exe` (todo empaquetado en un solo archivo,
incluida la carpeta `ui`). Luego, igual que antes, usa Inno Setup con
`installer.iss` para generar el instalador final.

**Nota técnica**: `pywebview` usa el motor **Edge WebView2** en Windows,
que ya viene integrado de fábrica en Windows 10/11 actualizados. Si en
alguna PC muy antigua no abre la ventana, puede necesitar instalar el
"WebView2 Runtime" (gratis, de Microsoft) — es poco común que falte.

## Qué revisar al probar (lo que yo no puedo verificar desde aquí)

- [ ] Que la ventana abra con el diseño correcto (sidebar morado, tarjetas)
- [ ] Cargar el Excel de ejemplo y ver el contador de contactos
- [ ] Crear 2 segmentos con rangos distintos y agregar módulos de texto/archivo
- [ ] Arrastrar los módulos con el mouse y confirmar que el orden se respeta
- [ ] Insertar las etiquetas `{Nombre}`, `{Empresa}`, `{Teléfono}` con los botones
- [ ] Iniciar campaña de prueba con 2-4 números tuyos reales
- [ ] Ver el log en tiempo real con los nombres en negrita
- [ ] Detener la campaña a la mitad y confirmar que corta bien
- [ ] Ir al Dashboard y confirmar que aparecen los números reales de la prueba
- [ ] Ir a Reportes y exportar en los 4 formatos (Excel, CSV, PDF, Log)
- [ ] Ver la página de Información

## Nota sobre lo que ya corregí antes de entregarte esto

Al revisar el código encontré y corregí un detalle importante: si detenías
una campaña a la mitad (o fallaba por un error), la campaña se quedaba
marcada como "activa" para siempre en la base de datos, inflando el
contador de "Campañas activas" del Dashboard. Ya está corregido — ahora la
campaña se cierra correctamente sin importar cómo termine (éxito, error o
detención manual).

## Pendiente para una siguiente iteración (si quieres seguir puliendo)
- Vista previa de contactos en la página "Crear Campaña" (como tenía la v2)
- Guardar plantillas de segmentos para reutilizar en futuras campañas
- Firma digital del instalador para evitar la advertencia de SmartScreen
