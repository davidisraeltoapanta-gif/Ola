"""
app.py
Punto de entrada de la aplicación. Crea la ventana de escritorio (pywebview)
que muestra ui/index.html, y expone una API Python que el JavaScript de la
interfaz puede invocar directamente (window.pywebview.api.metodo(...)).
"""

import os
import re
import subprocess
import shutil
import tempfile
import hashlib
import time

# pywebview (segun la version que traiga instalada pip) puede decidir por
# su cuenta usar CoreCLR como motor de .NET en Windows -- eso requiere
# tener instalado el ".NET Desktop Runtime" aparte, que la mayoria de PCs
# NO tienen de fabrica, y ademas tiene problemas conocidos sin resolver
# al combinarse con programas empaquetados (PyInstaller). Forzamos aqui
# .NET Framework clasico (netfx), que SI viene de fabrica en cualquier
# Windows 10/11, para no depender de esa decision automatica. Debe ir
# ANTES de "import webview".
os.environ.setdefault("PYTHONNET_RUNTIME", "netfx")

import sys
import json
import logging
import functools
import threading
import urllib.request
import urllib.error
import urllib.parse
from datetime import date, datetime

import pandas as pd
import webview

import db
import licencias
from whatsapp_core import (
    CampaignEngine, EnvioDetenido, VELOCIDADES, tipo_archivo,
    detectar_segmentos_excel, contar_segmentos_por_nombre, chequeo_previo as chequeo_previo_core,
    carpeta_perfil_chrome, liberar_perfil_chrome, normalizar_numero_whatsapp,
)

APP_VERSION = "5.0.0"

# Repositorio público de GitHub donde viven las plantillas y las
# actualizaciones publicadas (ver GITHUB_SETUP.md para cómo administrarlo).
GITHUB_USUARIO = "davidisraeltoapanta-gif"
GITHUB_REPO = "whatsapp-masivos-recursos"
GITHUB_RAW_BASE = f"https://raw.githubusercontent.com/{GITHUB_USUARIO}/{GITHUB_REPO}/main"
GITHUB_RELEASES_API = f"https://api.github.com/repos/{GITHUB_USUARIO}/{GITHUB_REPO}/releases/latest"

# Códigos de equipo del dueño (David) -- el mismo instalador se comporta
# distinto según en qué computadora corre: en estas, y solo en estas,
# aparece la pantalla de "Activación de programas". En la de cualquier
# cliente, ningún código de esta lista va a coincidir, así que la
# pantalla ni existe. Se admite más de un equipo (ej. PC de escritorio +
# laptop) -- para agregar uno nuevo: abre el programa en ese equipo,
# entra a Información, copia el "Código de equipo" que aparece ahí, y
# súmalo a esta lista.
HARDWARE_IDS_DUENO = [
    "49e011b43dd0fe58de77b18a6a8f3b6e0815a79945ce0c4673125fb9441d8c84",
    "525a5b25b9f0d7128eb106d6be4a169d649650a75e5f8b6a6492fedbc4720c2c"
]


def _ruta_log_errores():
    return os.path.join(db.carpeta_datos_app(), "errores.log")


def configurar_logging():
    """
    Cualquier error no manejado en cualquier parte del programa queda
    guardado aquí, con fecha y detalle técnico completo. Esto es LOCAL y
    automático -- no se envía a ningún lado por sí solo. El envío a
    soporte es una acción aparte, siempre pedida explícitamente (ver
    Api.enviar_reporte_error), nunca en silencio.
    """
    logging.basicConfig(
        filename=_ruta_log_errores(),
        level=logging.ERROR,
        format="%(asctime)s [%(levelname)s] %(message)s",
        encoding="utf-8",
    )


def _con_registro_errores(func):
    """Decorador: si el método de la API lanza una excepción, queda
    guardada en el log antes de propagarse -- así nunca se pierde en
    silencio, aunque el comportamiento hacia la interfaz no cambie."""
    @functools.wraps(func)
    def envoltura(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logging.error(f"Error en Api.{func.__name__}: {e}", exc_info=True)
            raise
    return envoltura


# =========================================================
# Reporte de errores a soporte (opcional, siempre con permiso explícito)
#
# Antes de que esto funcione de verdad, hay que:
#  1. Crear un Google Form con 3 preguntas de texto: "Versión", "Detalle
#     técnico", "Qué estabas haciendo (opcional)".
#  2. Obtener la URL de envío y los IDs de cada pregunta (entry.XXXXXXX)
#     -- se consiguen abriendo el formulario, botón "..." > "Insertar
#     código HTML", y buscando esos valores en el código.
#  3. Pegar esos valores en las 4 constantes de abajo.
# Mientras esas constantes digan "PENDIENTE", el botón de reportar sigue
# guardando el error localmente, solo que no lo manda a ningún lado.
# =========================================================
GOOGLE_FORM_URL = "PENDIENTE"
GOOGLE_FORM_ENTRY_VERSION = "PENDIENTE"
GOOGLE_FORM_ENTRY_DETALLE = "PENDIENTE"
GOOGLE_FORM_ENTRY_CONTEXTO = "PENDIENTE"

# =========================================================
# Formulario de SOLICITUD DE LICENCIA -- formulario distinto al de
# arriba. "PENDIENTE" hasta que David lo configure (ver
# FORMULARIO_LICENCIAS_SETUP.md) -- mientras tanto, el botón para
# solicitarla queda oculto en la pantalla de activación del cliente.
# =========================================================
URL_FORMULARIO_LICENCIA = "https://docs.google.com/forms/d/e/1FAIpQLSd1cFIeVEScwjVNwObtT-1-m776yrCDk2xHivGNv2HS6OjVhg/viewform"
ENTRY_CODIGO_EQUIPO_LICENCIA = "entry.1354353968"


def _reporte_configurado():
    return "PENDIENTE" not in (
        GOOGLE_FORM_URL, GOOGLE_FORM_ENTRY_VERSION,
        GOOGLE_FORM_ENTRY_DETALLE, GOOGLE_FORM_ENTRY_CONTEXTO,
    )



def _ruta_config_app():
    return os.path.join(db.carpeta_datos_app(), "config.json")


def _leer_config_app():
    try:
        with open(_ruta_config_app(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _guardar_config_app(cfg):
    try:
        with open(_ruta_config_app(), "w", encoding="utf-8") as f:
            json.dump(cfg, f)
    except Exception:
        pass


def _ruta_chrome():
    """
    Busca el ejecutable de Chrome en las ubicaciones típicas de Windows.
    No depende de Selenium (que tiene su propio mecanismo interno de
    detección) porque esto es para abrir una ventana normal de Chrome,
    no una controlada por el programa.
    """
    candidatos = [
        os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"), "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for ruta in candidatos:
        if ruta and os.path.exists(ruta):
            return ruta
    return shutil.which("chrome")


def _fetch_json(url, timeout=8):
    """Descarga y parsea JSON de una URL. Devuelve (datos, None) o (None, error_legible)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "WhatsAppMasivos"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8")), None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None, "No se encontró ese recurso (404). Puede que aún no esté publicado."
        if e.code == 403:
            return None, "GitHub limitó las solicitudes temporalmente. Intenta de nuevo en unos minutos."
        return None, f"Error del servidor ({e.code})"
    except urllib.error.URLError:
        return None, "No se pudo conectar a internet. Revisa tu conexión e intenta de nuevo."
    except Exception as e:
        return None, str(e)


def _fetch_csv(url, timeout=8):
    """Descarga y parsea un CSV publicado de Google Sheets. Devuelve
    (lista_de_diccionarios, None) o (None, error_legible)."""
    import csv
    import io
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Ola"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            texto = resp.read().decode("utf-8")
        lector = csv.DictReader(io.StringIO(texto))
        filas = [{(k or "").strip(): v for k, v in fila.items()} for fila in lector]
        return filas, None
    except urllib.error.HTTPError as e:
        return None, f"Error del servidor ({e.code}). ¿La hoja sigue publicada en la web?"
    except urllib.error.URLError:
        return None, "No se pudo conectar a internet. Revisa tu conexión e intenta de nuevo."
    except Exception as e:
        return None, str(e)


class Api:
    def __init__(self):
        self.window = None
        self.ruta_excel = None
        self.df_cache = None
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.hilo = None
        self.corriendo = False
        self.campana_actual_id = None
        self.ventana_diagnostico = None  # ventana aparte de pywebview, solo si el usuario la activa
        self.diag_log_path = None
        self.engine = None
        self.motor_chat_individual = None  # Selenium abierto para chats sueltos (botón WhatsApp), se reusa entre clics

    def set_window(self, window):
        self.window = window

    # =========================================================
    # Utilidades internas para hablar con el JS
    # =========================================================
    def _js(self, funcion, *args):
        if not self.window:
            return
        args_js = ", ".join(_a_js(a) for a in args)
        try:
            self.window.evaluate_js(f"{funcion}({args_js})")
        except Exception:
            pass

    def log(self, texto):
        self._js("appLog", texto)

    def progreso(self, actual, total):
        self._js("appProgreso", actual, total)

    # =========================================================
    # Archivos / Excel
    # =========================================================
    def seleccionar_excel(self, modo="avanzada"):
        resultado = self.window.create_file_dialog(
            webview.OPEN_DIALOG, file_types=("Archivos Excel (*.xlsx;*.xls)",)
        )
        if not resultado:
            return {"ok": False}

        ruta = resultado[0]
        return self._cargar_excel(ruta, modo)

    def _cargar_excel(self, ruta, modo="avanzada"):
        try:
            df = pd.read_excel(ruta, dtype=str).fillna("")
        except Exception as e:
            return {"ok": False, "error": str(e)}

        # Modo Básico: no exige la columna "Numero" (el usuario no la ve ni
        # la necesita). Se sintetiza en orden para que el resto del sistema
        # (que sí la usa internamente para segmentar) funcione igual.
        # Modo Avanzada: exige la columna "Segmento" -- es lo que le
        # permite al motor reconocer a quién pertenece cada contacto por
        # nombre, no por posición. Si no la trae, se le explica al
        # usuario en vez de dejarlo sin poder dividir su lista.
        if modo == "basica":
            requeridas = ["Nombre", "Celular"]
        else:
            requeridas = ["Numero", "Nombre", "Celular", "Segmento"]

        faltantes = [c for c in requeridas if c not in df.columns]
        if faltantes:
            if modo == "avanzada" and faltantes == ["Segmento"]:
                return {
                    "ok": False,
                    "error": "Este modo necesita la columna \"Segmento\" en tu Excel -- descarga el "
                             "Excel modelo, o usa Modo Básico si no necesitas dividir tu lista en grupos."
                }
            return {"ok": False, "error": f"Faltan columnas: {', '.join(faltantes)}"}

        if "Numero" not in df.columns:
            df["Numero"] = [str(i + 1) for i in range(len(df))]

        # "Estado" se agrega desde ya (aunque la campaña nunca se haya
        # lanzado) -- lo maneja 100% el motor (Enviado/Error/Sin
        # confirmar/Sin segmento/Omitido), nunca se edita a mano. "Error"
        # NO se agrega aquí a propósito -- recién tiene sentido después
        # de un envío real, y se sigue creando donde ya se creaba
        # (dentro de procesar_campana, en whatsapp_core.py).
        if "Estado" not in df.columns:
            df["Estado"] = ""

        # "Enviar" (Sí/No) es la decisión del usuario de a quién
        # intentarle el envío o no -- independiente de "Estado", y
        # sobrevive a "Reiniciar envíos" (que solo limpia Estado/Error).
        # Si el Excel no la trae (uno hecho antes de que existiera esta
        # función), se agrega con "Sí" en todos, para no dejar a nadie
        # afuera solo por tener un archivo viejo.
        if "Enviar" not in df.columns:
            df["Enviar"] = "Sí"

        self.ruta_excel = ruta
        self.df_cache = df

        auto_segmentos = contar_segmentos_por_nombre(df) if modo == "avanzada" else []

        primer_contacto = {}
        if len(df) > 0:
            fila0 = df.iloc[0]
            primer_contacto = {
                "Nombre": fila0.get("Nombre", ""),
                "Empresa": fila0.get("Empresa", ""),
                "Contacto": fila0.get("Contáctanos", ""),
            }

        return {
            "ok": True,
            "ruta": ruta,
            "nombre_archivo": os.path.basename(ruta),
            "total": len(df),
            "columnas": list(df.columns),
            "auto_segmentos": auto_segmentos,
            "primer_contacto": primer_contacto,
        }

    # =========================================================
    # Editor de datos dentro del programa -- corregir valores de celdas
    # sin salir a Excel, sin agregar/quitar filas ni columnas. Puede
    # abrirse con TODOS los contactos, o filtrado a un solo segmento
    # (para poder detectar rápido a alguien que se filtró por error).
    # =========================================================

    # "Estado" y "Error" nunca se muestran en el editor: "Error" es
    # información de diagnóstico que deja el motor tras un intento
    # fallido, y "Estado" pasó a ser 100% de solo lectura/gestión del
    # motor (Enviado/Error/Sin confirmar/Sin segmento/Omitido) -- la
    # única forma de decidir a quién se le manda o no es la columna
    # "Enviar" (Sí/No), no editando "Estado" a mano.
    _COLUMNAS_OCULTAS_EN_EDITOR = {"Error", "Estado"}

    def obtener_datos_para_editar(self, segmento=None):
        if self.df_cache is None:
            return {"ok": False, "error": "Primero carga un Excel."}
        df = self.df_cache

        if segmento:
            etiquetas = df.get("Segmento", pd.Series([""] * len(df), index=df.index))
            etiquetas = etiquetas.fillna("").astype(str).str.strip()
            etiquetas = etiquetas.where(etiquetas != "", "Sin segmento")
            indices = df.index[etiquetas == segmento].tolist()
        else:
            indices = df.index.tolist()

        columnas_visibles = [c for c in df.columns if c not in self._COLUMNAS_OCULTAS_EN_EDITOR]

        return {
            "ok": True,
            "columnas": columnas_visibles,
            "filas": df.loc[indices, columnas_visibles].astype(str).to_dict(orient="records"),
            # Posición real de cada fila dentro del Excel completo -- se
            # necesita para poder guardar solo estas filas de vuelta sin
            # tocar las que no se están mostrando (cuando se filtra por
            # segmento).
            "indices": [int(i) for i in indices],
        }

    def guardar_edicion_excel(self, columnas, filas, indices=None):
        if self.df_cache is None or not self.ruta_excel:
            return {"ok": False, "error": "No hay un Excel cargado."}

        try:
            if indices:
                # Edición filtrada (vino de "Ver contactos de este
                # segmento") -- solo se actualizan esas filas puntuales
                # dentro del Excel completo, el resto queda intacto.
                nuevo_df = self.df_cache.copy()
                for pos, idx in enumerate(indices):
                    for col in columnas:
                        nuevo_df.at[idx, col] = filas[pos].get(col, "")
            else:
                nuevo_df = pd.DataFrame(filas, columns=columnas).fillna("")
                # El editor nunca mandó de vuelta las columnas ocultas
                # (como "Error") -- si no se recuperan aquí, este modo
                # (edición SIN filtrar, que reconstruye la tabla entera)
                # las borraría del Excel por completo sin querer. Como
                # el editor no reordena ni filtra filas en este caso, se
                # pueden pegar de vuelta alineando por posición.
                if len(nuevo_df) == len(self.df_cache):
                    for col in self._COLUMNAS_OCULTAS_EN_EDITOR:
                        if col in self.df_cache.columns:
                            nuevo_df[col] = self.df_cache[col].values
                    orden_original = [c for c in self.df_cache.columns if c in nuevo_df.columns]
                    nuevo_df = nuevo_df[orden_original]
        except Exception as e:
            return {"ok": False, "error": f"No se pudo interpretar los datos editados: {e}"}

        self.df_cache = nuevo_df

        try:
            nuevo_df.to_excel(self.ruta_excel, index=False)
        except PermissionError:
            return {
                "ok": False,
                "error": "No se pudo guardar -- el archivo Excel está abierto en otro programa "
                         "(ciérralo e intenta de nuevo)."
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

        # Se recalculan los segmentos con los datos ya editados -- la
        # interfaz es la que decide qué hacer con esto (conservar el
        # mensaje de los segmentos que ya existían por nombre, agregar
        # los nuevos, quitar los que se quedaron sin contactos). Ya no
        # hace falta reordenar ni renumerar filas -- el motor de envío
        # ahora reconoce el segmento de cada contacto por el nombre real
        # que tiene en la columna "Segmento", sin importar su posición
        # ni si está junto a otros de su mismo segmento o no.
        auto_segmentos = contar_segmentos_por_nombre(nuevo_df) if "Segmento" in nuevo_df.columns else []

        return {
            "ok": True,
            "total": len(nuevo_df),
            "auto_segmentos": auto_segmentos,
        }

    def redetectar_segmentos(self):
        """
        Vuelve a leer la columna "Segmento" del Excel ya cargado en
        memoria (sin recargar el archivo desde disco) y devuelve la
        lista actualizada de segmentos -- para recuperar una tarjeta
        que se haya borrado por accidente en la pantalla, sin perder
        los mensajes ya configurados en las demás. La interfaz aplica
        el mismo mecanismo de reconciliación que usa al guardar una
        edición (conservar por nombre, agregar lo nuevo, quitar lo que
        ya no tenga contactos).
        """
        if self.df_cache is None:
            return {"ok": False, "error": "Primero carga un Excel."}
        if "Segmento" not in self.df_cache.columns:
            return {"ok": False, "error": "Este Excel no tiene columna \"Segmento\" (Modo Básico no la usa)."}

        auto_segmentos = contar_segmentos_por_nombre(self.df_cache)
        return {"ok": True, "auto_segmentos": auto_segmentos}

    def descargar_modelo_excel(self, modo):
        """Genera un Excel de ejemplo con las columnas correctas para que
        el usuario lo llene con sus propios contactos."""
        if modo == "basica":
            data = {
                "Nombre": ["Juan Pérez", "María López"],
                "Primer Nombre": ["Juan", "María"],
                "Segundo Nombre": ["", "Fernanda"],
                "Apellidos": ["Pérez", "López"],
                "Trato": ["Juanito", "mi María"],
                "Celular": ["593999999999", "593988888888"],
                "Empresa": ["Ferretería Central", "Panadería Ana"],
                "Contáctanos": ["0999999999", "0988888888"],
                "Enviar": ["Sí", "Sí"],
            }
            nombre_sugerido = "modelo_basico.xlsx"
        else:
            data = {
                "Numero": [1, 2, 3, 4],
                "Nombre": ["Juan Pérez", "María López", "Carlos Ruiz", "Ana Torres"],
                "Primer Nombre": ["Juan", "María", "Carlos", "Ana"],
                "Segundo Nombre": ["", "Fernanda", "", "Lucía"],
                "Apellidos": ["Pérez", "López", "Ruiz", "Torres"],
                "Trato": ["Juanito", "mi María", "Don Carlos", "Anita"],
                "Celular": ["593999999999", "593988888888", "593977777777", "593966666666"],
                "Empresa": ["Ferretería Central", "Panadería Ana", "Taller Ruiz", "Boutique Torres"],
                "Contáctanos": ["0999999999", "0988888888", "0977777777", "0966666666"],
                "Segmento": ["Cumpleaños", "Cumpleaños", "Recordatorio", "Recordatorio"],
                "Enviar": ["Sí", "Sí", "Sí", "No"],
            }
            nombre_sugerido = "modelo_avanzado.xlsx"

        resultado = self.window.create_file_dialog(
            webview.SAVE_DIALOG, save_filename=nombre_sugerido
        )
        if not resultado:
            return {"ok": False}

        ruta = resultado if isinstance(resultado, str) else resultado[0]
        try:
            pd.DataFrame(data).to_excel(ruta, index=False)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "ruta": ruta}

    def seleccionar_archivo_adjunto(self):
        resultado = self.window.create_file_dialog(webview.OPEN_DIALOG)
        if not resultado:
            return {"ok": False}
        ruta = resultado[0]
        return {
            "ok": True,
            "ruta": ruta,
            "nombre_archivo": os.path.basename(ruta),
            "tipo": tipo_archivo(ruta),
        }

    # =========================================================
    # Chequeo previo
    # =========================================================
    def chequeo_previo(self, segmentos):
        if self.df_cache is None:
            return {"ok": False, "error": "No hay Excel cargado"}
        stats = chequeo_previo_core(self.df_cache, segmentos)
        return {"ok": True, **stats}

    # =========================================================
    # Campaña: iniciar / pausar / reanudar / detener
    # =========================================================
    def crear_borrador(self, nombre_campana):
        """
        Crea (o reutiliza) la fila de la campaña en la base de datos ANTES
        de darle a "Iniciar Campaña" -- necesario para poder guardar notas,
        pasos del checklist o recordatorios mientras todavía se está
        configurando la campaña, no solo después de arrancarla.
        """
        if self.campana_actual_id is not None:
            return {"ok": True, "campana_id": self.campana_actual_id}

        if not self.ruta_excel or self.df_cache is None:
            return {"ok": False, "error": "Primero carga un archivo Excel"}

        self.campana_actual_id = db.crear_campana(
            nombre_campana or "Campaña sin nombre", self.ruta_excel, {},
            len(self.df_cache), estado="Borrador"
        )
        return {"ok": True, "campana_id": self.campana_actual_id}

    def iniciar_campana(self, config):
        """
        Arranca una campaña. Si self.campana_actual_id ya existe (porque se
        retomó una campaña previa desde el Inicio, o porque ya se corrió
        antes en esta sesión), continúa esa misma campaña -- lo cual sirve
        tanto para "reanudar tras detener" como para "reenviar solo errores"
        (el motor ya se salta automáticamente las filas marcadas "Enviado").
        """
        if self.corriendo:
            return {"ok": False, "error": "Ya hay una campaña en curso"}

        if not self.ruta_excel or self.df_cache is None:
            return {"ok": False, "error": "Primero selecciona un archivo Excel"}

        nombre_campana = config.get("nombre_campana") or "Campaña sin nombre"
        segmentos = config.get("segmentos", [])
        velocidad = config.get("velocidad", "Normal")

        if not segmentos:
            return {"ok": False, "error": "Agrega al menos un segmento"}

        if self.campana_actual_id is None:
            self.campana_actual_id = db.crear_campana(
                nombre_campana, self.ruta_excel, config, len(self.df_cache)
            )
        else:
            db.actualizar_config_campana(self.campana_actual_id, config)
            db.actualizar_estado_campana(self.campana_actual_id, "En curso")

        self.stop_event.clear()
        self.pause_event.clear()
        self.corriendo = True

        self.hilo = threading.Thread(
            target=self._ejecutar_campana,
            args=(nombre_campana, segmentos, velocidad, self.campana_actual_id),
            daemon=True
        )
        self.hilo.start()
        return {"ok": True, "campana_id": self.campana_actual_id}

    # =========================================================
    # Ventana de diagnóstico -- aparte de la ventana principal, para
    # desarrollo/soporte. Muestra datos técnicos crudos (selectores,
    # HTML, errores completos) en vivo mientras corre una campaña, y
    # guarda todo a un archivo para poder compartirlo después.
    # =========================================================
    def resumen_envios_actual(self):
        if not self.campana_actual_id:
            return {"ok": False}
        return {"ok": True, **db.resumen_envios_campana(self.campana_actual_id)}

    def abrir_ventana_diagnostico(self):
        if self.ventana_diagnostico is not None:
            return {"ok": True, "ya_abierta": True}

        carpeta = os.path.join(db.carpeta_datos_app(), "diagnostico")
        os.makedirs(carpeta, exist_ok=True)
        marca = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.diag_log_path = os.path.join(carpeta, f"diagnostico_{marca}.log")

        self.ventana_diagnostico = webview.create_window(
            "Ola -- Diagnóstico técnico",
            ruta_recurso(os.path.join("ui", "diagnostico.html")),
            width=700, height=800, x=50, y=50,
        )

        def _al_cerrar():
            self.ventana_diagnostico = None

        self.ventana_diagnostico.events.closed += _al_cerrar
        return {"ok": True, "ruta_log": self.diag_log_path}

    def cerrar_ventana_diagnostico(self):
        if self.ventana_diagnostico is not None:
            try:
                self.ventana_diagnostico.destroy()
            except Exception:
                pass
            self.ventana_diagnostico = None
        return {"ok": True}

    def diagnostico_activo(self):
        return self.ventana_diagnostico is not None

    def _diag(self, tipo, datos):
        """
        Le pasa un dato crudo a la ventana de diagnóstico (si está
        abierta) y lo guarda también al archivo de registro. Nunca debe
        poder romper un envío real -- cualquier fallo aquí se ignora.
        """
        try:
            marca = datetime.now().strftime("%H:%M:%S.%f")[:-3]
            bloque = f"[{marca}] {tipo}\n{json.dumps(datos, ensure_ascii=False, indent=2, default=str)}\n{'-'*60}\n"

            if self.diag_log_path:
                with open(self.diag_log_path, "a", encoding="utf-8") as f:
                    f.write(bloque)

            if self.ventana_diagnostico is not None:
                bloque_js = _a_js(bloque)
                self.ventana_diagnostico.evaluate_js(f"agregarBloqueDiagnostico({bloque_js})")
        except Exception:
            pass

    def _ejecutar_campana(self, nombre_campana, segmentos, velocidad, campana_id):
        # Se pasa un intermediario, no self._diag directo -- así, si
        # activas la ventana de diagnóstico DESPUÉS de haber iniciado la
        # campaña, se conecta igual (revisa en cada llamada si la
        # ventana ya está abierta, no solo una vez al arrancar).
        def _diag_dinamico(tipo, datos):
            if self.ventana_diagnostico is not None:
                self._diag(tipo, datos)

        self.engine = CampaignEngine(
            velocidad=velocidad,
            log_callback=self.log,
            progress_callback=self.progreso,
            stop_event=self.stop_event,
            pause_event=self.pause_event,
            diag_callback=_diag_dinamico,
        )
        try:
            self.engine.iniciar_navegador()
            self.engine.procesar_campana(self.ruta_excel, segmentos, nombre_campana, campana_id)
        except EnvioDetenido:
            pass  # el mensaje de log ya lo emitió el motor
        except Exception as e:
            logging.error(f"Error durante el envío de la campaña '{nombre_campana}': {e}", exc_info=True)
            self.log(f"❌ Error inesperado: {e}")
            self._js("appErrorCritico", str(e))
        finally:
            self.engine.cerrar_navegador()
            self.corriendo = False
            self._js("appCampanaFinalizada")

    def pausar_campana(self):
        if not self.corriendo:
            return {"ok": False, "error": "No hay campaña en curso"}
        self.pause_event.set()
        if self.campana_actual_id:
            db.actualizar_estado_campana(self.campana_actual_id, "Pausada")
        return {"ok": True}

    def reanudar_campana(self, config):
        """Reanuda aplicando cualquier cambio hecho a los módulos mientras
        estaba en pausa (textos o adjuntos nuevos)."""
        if not self.corriendo or self.engine is None:
            return {"ok": False, "error": "No hay campaña en pausa"}
        segmentos = config.get("segmentos", [])
        self.engine.actualizar_segmentos(segmentos)
        if self.campana_actual_id:
            db.actualizar_config_campana(self.campana_actual_id, config)
            db.actualizar_estado_campana(self.campana_actual_id, "En curso")
        self.pause_event.clear()
        return {"ok": True}

    def detener_campana(self):
        """
        Detiene el envío de forma segura -- el progreso ya guardado por
        contacto no se pierde. Uso INTERNO: lo usa el propio programa
        para cambiar entre campañas pausadas (cerrar el navegador de una
        para poder abrir el de otra) -- nunca está conectado a un botón
        que el usuario vea directamente, para eso existe
        finalizar_campana(). Dejar la campaña en 'Pausada' (recuperable)
        es lo correcto aquí, porque cambiar de campaña no es una decisión
        de "ya terminé con esta", es solo un cambio de foco temporal.
        """
        if not self.corriendo:
            return {"ok": True}
        self.pause_event.clear()
        self.stop_event.set()
        if self.hilo:
            self.hilo.join(timeout=20)
        return {"ok": True}

    def finalizar_campana(self):
        """
        Termina la campaña actual de forma deliberada y definitiva -- este
        es el que sí está conectado al botón "Finalizar" que ve el
        usuario. A diferencia de detener_campana(), esto marca la
        campaña como 'Finalizada' (no 'Pausada'): lo que no se haya
        mandado, se queda sin mandar, y así se refleja en Reportes.
        """
        if not self.corriendo:
            return {"ok": False, "error": "No hay campaña en curso"}
        campana_id = self.campana_actual_id
        self.detener_campana()
        if campana_id:
            db.actualizar_estado_campana(campana_id, "Finalizada")
        return {"ok": True}

    def estado_actual(self):
        """
        La interfaz llama esto cada vez que necesita saber la verdad sobre
        el estado de la campaña actualmente cargada -- en vez de asumirlo
        localmente en JavaScript (esa suposición era la causa del bug donde
        el botón decía "Iniciar" en vez de "Reanudar" después de volver
        desde el Inicio).
        """
        if self.campana_actual_id is None:
            return {"campana_id": None}

        campana = db.obtener_campana(self.campana_actual_id)
        hay_hilo_activo = self.corriendo and self.campana_actual_id is not None
        pausado_activo = hay_hilo_activo and self.pause_event.is_set()
        estado_db = campana["estado"] if campana else None

        return {
            "campana_id": self.campana_actual_id,
            "estado_db": estado_db,
            "hay_hilo_activo": hay_hilo_activo,
            "pausado_activo": pausado_activo,
            # "Borrador" = nunca se ha iniciado un envío real todavía.
            # Solo "Pausada" o "En curso" (sin hilo vivo, ej. tras cerrar
            # el programa) deben verse como "reanudables".
            "es_reanudable": estado_db in ("Pausada", "En curso") and not hay_hilo_activo,
        }

    def actualizar_excel_campana(self):
        """
        Reemplaza el Excel de la campaña actual -- se trata exactamente
        como cargar un Excel nuevo (misma detección automática de
        segmentos, mismo comportamiento), la única diferencia es que NO
        crea una campaña nueva: sigue siendo la misma (mismo
        campana_actual_id), así que el checklist, las observaciones y los
        recordatorios -- que viven ligados a la campaña en la base de
        datos, no al Excel -- se conservan tal cual. Todo lo demás
        (segmentos, mensajes) se vuelve a armar desde cero según lo que
        traiga el archivo nuevo, porque subir un Excel nuevo ya es, en sí
        mismo, la decisión de cambiarlo todo.
        """
        if self.corriendo:
            return {"ok": False, "error": "Detén la campaña antes de actualizar el Excel"}
        if not self.campana_actual_id:
            return {"ok": False, "error": "No hay una campaña cargada"}

        resultado = self.window.create_file_dialog(
            webview.OPEN_DIALOG, file_types=("Archivos Excel (*.xlsx;*.xls)",)
        )
        if not resultado:
            return {"ok": False}
        ruta_nueva = resultado[0]

        campana = db.obtener_campana(self.campana_actual_id)
        modo = (campana.get("config") or {}).get("modo", "avanzada") if campana else "avanzada"

        resultado_carga = self._cargar_excel(ruta_nueva, modo)
        if not resultado_carga.get("ok"):
            return resultado_carga

        # Envío fresco de verdad -- si el archivo que subieron ya traía
        # una columna Estado con datos de antes (ej. una copia vieja),
        # se limpia para que nadie quede marcado "Enviado" sin haberlo
        # sido en esta tanda.
        if "Estado" in self.df_cache.columns:
            self.df_cache["Estado"] = ""
        if "Error" in self.df_cache.columns:
            self.df_cache["Error"] = ""

        db.actualizar_estado_campana(self.campana_actual_id, "Pausada")
        return resultado_carga

    def reiniciar_envios_campana(self):
        """
        Vuelve a poner todos los contactos del Excel ya cargado como
        pendientes -- sin tocar los segmentos ni los mensajes ya
        configurados -- para poder reenviar la misma campaña desde cero
        (por ejemplo, tras editar el texto). El historial de envíos
        anteriores en Reportes/Dashboard no se borra, queda como
        registro de esa tanda anterior.
        """
        if self.corriendo:
            return {"ok": False, "error": "Detén la campaña antes de reiniciar los envíos"}
        if self.df_cache is None or not self.ruta_excel:
            return {"ok": False, "error": "No hay un Excel cargado"}

        self.df_cache["Estado"] = ""
        if "Error" in self.df_cache.columns:
            self.df_cache["Error"] = ""

        try:
            self.df_cache.to_excel(self.ruta_excel, index=False)
        except Exception as e:
            return {"ok": False, "error": f"No se pudo guardar el Excel (¿está abierto en otro programa?): {e}"}

        if self.campana_actual_id:
            # "Borrador" (no "Pausada") a propósito: como todos los
            # contactos quedaron pendientes de nuevo, conceptualmente es
            # un arranque fresco -- el botón principal debe decir
            # "Iniciar Campaña", no "Reanudar".
            db.actualizar_estado_campana(self.campana_actual_id, "Borrador")
        return {"ok": True}

    def nueva_campana(self):
        """Reinicia el estado para empezar una campaña desde cero. Si
        había otra corriendo o pausada, se detiene de forma segura
        primero (su progreso queda guardado, retomable después)."""
        if self.corriendo:
            self.detener_campana()
        self.ruta_excel = None
        self.df_cache = None
        self.campana_actual_id = None
        return {"ok": True}

    # =========================================================
    # Inicio (Home) — historial de campañas
    # =========================================================
    def listar_campanas_home(self):
        return db.listar_campanas_home()

    def retomar_campana(self, campana_id):
        # Si hay OTRA campaña corriendo (activa o pausada), la detenemos
        # de forma segura primero -- su progreso ya quedó guardado en su
        # propio Excel, contacto por contacto, así que no se pierde nada,
        # y queda lista para retomarse ella también más adelante.
        if self.corriendo and campana_id != self.campana_actual_id:
            self.detener_campana()

        campana = db.obtener_campana(campana_id)
        if not campana:
            return {"ok": False, "error": "Campaña no encontrada"}

        ruta_excel = campana.get("ruta_excel")
        if not ruta_excel or not os.path.exists(ruta_excel):
            return {
                "ok": False,
                "error": "No se encontró el archivo Excel original en su ubicación. "
                         "Selecciónalo de nuevo para continuar."
            }

        modo_guardado = (campana.get("config") or {}).get("modo", "avanzada")
        resultado_excel = self._cargar_excel(ruta_excel, modo_guardado)
        if not resultado_excel.get("ok"):
            return resultado_excel

        self.campana_actual_id = campana_id

        return {
            "ok": True,
            "campana": {
                "id": campana["id"],
                "nombre": campana["nombre"],
                "estado": campana["estado"],
                "config": campana.get("config"),
                "modo": modo_guardado,
            },
            "excel": resultado_excel,
        }

    def marcar_finalizada(self, campana_id):
        db.actualizar_estado_campana(campana_id, "Finalizada")
        return {"ok": True}

    def eliminar_campana(self, campana_id):
        if self.corriendo and campana_id == self.campana_actual_id:
            return {"ok": False, "error": "No puedes eliminar una campaña que está en curso"}
        db.eliminar_campana(campana_id)
        return {"ok": True}

    # =========================================================
    # Notas de seguimiento
    # =========================================================
    def agregar_nota(self, campana_id, texto):
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "error": "La nota está vacía"}
        db.agregar_nota(campana_id, texto)
        return {"ok": True, "notas": db.listar_notas(campana_id)}

    def listar_notas(self, campana_id):
        return db.listar_notas(campana_id)

    def editar_nota(self, nota_id, texto, campana_id):
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "error": "La nota no puede quedar vacía"}
        db.editar_nota(nota_id, texto)
        return {"ok": True, "notas": db.listar_notas(campana_id)}

    def eliminar_nota(self, nota_id, campana_id):
        db.eliminar_nota(nota_id)
        return {"ok": True, "notas": db.listar_notas(campana_id)}

    # =========================================================
    # Checklist de pasos de campaña
    # =========================================================
    def listar_pasos(self, campana_id):
        return db.listar_pasos(campana_id)

    def agregar_paso(self, campana_id, titulo):
        titulo = (titulo or "").strip()
        if not titulo:
            return {"ok": False, "error": "El paso está vacío"}
        db.agregar_paso(campana_id, titulo)
        return {"ok": True, "pasos": db.listar_pasos(campana_id)}

    def marcar_paso(self, paso_id, completado):
        db.marcar_paso(paso_id, completado)
        return {"ok": True}

    def eliminar_paso(self, paso_id, campana_id):
        db.eliminar_paso(paso_id)
        return {"ok": True, "pasos": db.listar_pasos(campana_id)}

    def editar_paso(self, paso_id, nuevo_titulo, campana_id):
        nuevo_titulo = (nuevo_titulo or "").strip()
        if not nuevo_titulo:
            return {"ok": False, "error": "El paso no puede quedar vacío"}
        db.editar_paso(paso_id, nuevo_titulo)
        return {"ok": True, "pasos": db.listar_pasos(campana_id)}

    # ---- Plantillas de campaña: instalar (Información) vs aplicar (Crear Campaña) ----
    def listar_campanas_plantillas_disponibles(self):
        """Catálogo remoto (GitHub) -- para el botón 'Instalar' en Información."""
        datos, error = _fetch_json(f"{GITHUB_RAW_BASE}/plantillas/campanas/indice.json")
        if error:
            return {"ok": False, "error": error}
        return {"ok": True, "campanas": datos.get("campanas", [])}

    def instalar_plantilla_campana_github(self, plantilla_id):
        """Descarga una plantilla de campaña desde GitHub y la guarda en la
        biblioteca LOCAL (tabla plantillas_campana) -- esto se llama desde
        Información, igual que se instalan las plantillas de mensaje por rubro.
        No la aplica a ninguna campaña todavía."""
        datos, error = _fetch_json(f"{GITHUB_RAW_BASE}/plantillas/campanas/{plantilla_id}.json")
        if error:
            return {"ok": False, "error": error}

        titulos = [p.get("titulo", "") for p in datos.get("pasos", []) if p.get("titulo")]
        if not titulos:
            return {"ok": False, "error": "La plantilla no tiene pasos definidos"}

        nombre = datos.get("nombre", plantilla_id)
        ya_instaladas = {p["nombre"] for p in db.listar_plantillas_campana()}
        if nombre in ya_instaladas:
            return {"ok": True, "ya_existia": True, "nombre": nombre}

        db.crear_plantilla_campana(nombre, datos.get("descripcion", ""), titulos)
        return {"ok": True, "ya_existia": False, "nombre": nombre}

    def listar_plantillas_campana_instaladas(self):
        """Biblioteca local -- para mostrar los chips dentro de 'Crear Campaña'."""
        return db.listar_plantillas_campana()

    def aplicar_plantilla_campana(self, campana_id, plantilla_local_id):
        """Aplica una plantilla YA instalada localmente como el checklist de
        la campaña que se está configurando ahora mismo."""
        plantilla = db.obtener_plantilla_campana(plantilla_local_id)
        if not plantilla:
            return {"ok": False, "error": "Esa plantilla ya no existe"}
        db.crear_pasos(campana_id, plantilla["pasos"])
        return {"ok": True, "pasos": db.listar_pasos(campana_id)}

    # =========================================================
    # Recordatorios
    # =========================================================
    def agregar_recordatorio(self, campana_id, texto, fecha_hora):
        texto = (texto or "").strip()
        if not texto or not fecha_hora:
            return {"ok": False, "error": "Falta el texto o la fecha/hora"}
        db.crear_recordatorio(campana_id, texto, fecha_hora)
        return {"ok": True, "recordatorios": db.listar_recordatorios(campana_id)}

    def listar_recordatorios(self, campana_id):
        return db.listar_recordatorios(campana_id)

    def eliminar_recordatorio(self, recordatorio_id, campana_id):
        db.eliminar_recordatorio(recordatorio_id)
        return {"ok": True, "recordatorios": db.listar_recordatorios(campana_id)}

    def editar_recordatorio(self, recordatorio_id, texto, fecha_hora, campana_id):
        texto = (texto or "").strip()
        if not texto or not fecha_hora:
            return {"ok": False, "error": "Falta el texto o la fecha/hora"}
        db.editar_recordatorio(recordatorio_id, texto, fecha_hora)
        return {"ok": True, "recordatorios": db.listar_recordatorios(campana_id)}

    def listar_recordatorios_pendientes_home(self):
        return db.recordatorios_pendientes_visualizacion()

    def marcar_recordatorio_visto(self, recordatorio_id):
        db.marcar_recordatorio_visto(recordatorio_id)
        return {"ok": True, "pendientes": db.recordatorios_pendientes_visualizacion()}

    def datos_seguimiento_campana(self, campana_id):
        """Usado por el popup de seguimiento del Inicio: junta notas y
        checklist de una misma campaña en una sola respuesta."""
        return {
            "notas": db.listar_notas(campana_id),
            "pasos": db.listar_pasos(campana_id),
        }

    # =========================================================
    # Plantillas de mensaje
    # =========================================================
    def guardar_plantilla(self, nombre, contenido):
        nombre = (nombre or "").strip()
        contenido = (contenido or "").strip()
        if not nombre or not contenido:
            return {"ok": False, "error": "Nombre y contenido son obligatorios"}
        pid = db.crear_plantilla(nombre, contenido)
        return {"ok": True, "id": pid}

    def listar_plantillas(self):
        return db.listar_plantillas()

    def eliminar_plantilla(self, plantilla_id):
        db.eliminar_plantilla(plantilla_id)
        return {"ok": True}

    def editar_plantilla(self, plantilla_id, nombre, contenido):
        nombre = (nombre or "").strip()
        contenido = (contenido or "").strip()
        if not nombre or not contenido:
            return {"ok": False, "error": "Nombre y contenido son obligatorios"}
        db.actualizar_plantilla(plantilla_id, nombre, contenido)
        return {"ok": True}

    # =========================================================
    # Dashboard
    # =========================================================
    def dashboard_stats(self, anio_mes=None):
        return db.stats_mes(anio_mes)

    def dashboard_meses_disponibles(self):
        return db.meses_con_datos()

    def dashboard_historial(self):
        return db.historial_mensual()

    def dashboard_top_contactos(self):
        return db.top_contactos()

    # =========================================================
    # Contactos persistentes (cimiento del Kanban, Fase 3)
    # =========================================================
    def listar_contactos(self):
        return db.listar_contactos()

    def numeros_de_campana(self, campana_id):
        return db.numeros_de_campana(campana_id)

    def contactos_resumen(self):
        return db.contactos_resumen()

    def obtener_contacto(self, numero):
        return db.obtener_contacto(numero)

    def obtener_numero_propio_whatsapp(self):
        return db.obtener_config("numero_propio_whatsapp", "")

    def guardar_numero_propio_whatsapp(self, numero):
        numero_limpio = re.sub(r"\D", "", str(numero or ""))
        db.guardar_config("numero_propio_whatsapp", numero_limpio)
        return {"ok": True}

    def abrir_whatsapp_contacto(self, numero_completo):
        """
        Abre WhatsApp Web directo en la conversación de ese contacto.

        Antes esto abría una ventana de Chrome "a mano" (subprocess),
        aparte del motor de envío -- pero ese camino resultó frágil (la
        pestaña se quedaba en blanco de forma intermitente). Ahora se
        usa el motor de campañas (Selenium), que sí espera de verdad a
        que WhatsApp Web termine de cargar.

        Cada clic cierra primero la sesión anterior (si había una) de
        forma ORDENADA con driver.quit() -- el propio mecanismo de
        Selenium para cerrar, mucho más limpio que matar el proceso por
        fuera -- y recién ahí abre una sesión nueva para el contacto
        pedido. Tarda unos segundos en lo que Chrome cierra y vuelve a
        levantar (más en equipos más lentos); es esperado, no un error.
        """
        if self.corriendo:
            return {
                "ok": False,
                "error": "Hay una campaña enviando en este momento -- espera a que termine o "
                         "pausa antes de abrir WhatsApp aparte, para no chocar con la misma sesión."
            }

        numero_limpio = re.sub(r"\D", "", str(numero_completo or ""))
        if not numero_limpio:
            return {"ok": False, "error": "Número inválido"}

        numero_propio = re.sub(r"\D", "", db.obtener_config("numero_propio_whatsapp", ""))
        es_numero_propio = bool(numero_propio) and numero_limpio == numero_propio

        try:
            if self.motor_chat_individual is not None:
                self.motor_chat_individual.cerrar_navegador()
                self.motor_chat_individual = None

            self.motor_chat_individual = CampaignEngine(velocidad="Normal", log_callback=lambda t: None)
            self.motor_chat_individual.iniciar_navegador()

            if es_numero_propio:
                # WhatsApp Web dejó de soportar abrir un chat contigo
                # mismo por enlace directo (error interno "invalid
                # wid") -- se deja WhatsApp Web abierto en la bandeja
                # general y se avisa, en vez de intentar algo que
                # sabemos que falla.
                self.motor_chat_individual.driver.get("https://web.whatsapp.com/")
                return {
                    "ok": True,
                    "aviso": "WhatsApp no permite abrir un chat contigo mismo por enlace directo -- "
                             "se abrió WhatsApp Web normal. Busca \"Tú\" arriba de tu lista de chats."
                }

            self.motor_chat_individual.abrir_chat(numero_limpio)
        except Exception as e:
            # Si algo falló a medio camino, se limpia la referencia
            # para que el próximo clic arranque una sesión nueva en vez
            # de seguir fallando con una sesión a medio morir.
            self.motor_chat_individual = None
            return {"ok": False, "error": f"No se pudo abrir el chat: {e}"}

        return {"ok": True}

    def actualizar_datos_contacto(self, numero, empresa=None, correo=None, direccion=None, ciudad=None):
        db.actualizar_datos_contacto(numero, empresa, correo, direccion, ciudad)
        return {"ok": True, "contacto": db.obtener_contacto(numero)}

    def campanas_de_contacto(self, numero):
        return db.campanas_de_contacto(numero)

    # ---- Columnas de Kanban (editables, por campaña) ----
    def columnas_de_campana(self, campana_id):
        return db.columnas_de_campana(campana_id)

    def agregar_columna_kanban(self, campana_id, nombre):
        nombre = (nombre or "").strip()
        if not nombre:
            return {"ok": False, "error": "El nombre de la columna está vacío"}
        db.agregar_columna(campana_id, nombre)
        return {"ok": True, "columnas": db.columnas_de_campana(campana_id)}

    def editar_columna_kanban(self, columna_id, nombre, campana_id):
        nombre = (nombre or "").strip()
        if not nombre:
            return {"ok": False, "error": "El nombre de la columna está vacío"}
        db.editar_columna(columna_id, nombre)
        return {"ok": True, "columnas": db.columnas_de_campana(campana_id)}

    def eliminar_columna_kanban(self, columna_id, campana_id):
        total = db.contactos_en_columna(columna_id)
        if total > 0:
            return {
                "ok": False,
                "error": f"Esta columna tiene {total} contacto(s) -- muévelos a otra columna antes de eliminarla."
            }
        db.eliminar_columna(columna_id)
        return {"ok": True, "columnas": db.columnas_de_campana(campana_id)}

    def exportar_columna_excel(self, columna_id, nombre_columna):
        """Excel informativo con todos los datos de los contactos de esa
        columna -- para llevarte la información fuera del programa
        (ej. facturación, análisis en otra herramienta)."""
        contactos = db.contactos_de_columna(columna_id)
        if not contactos:
            return {"ok": False, "error": "Esta columna no tiene contactos"}

        carpeta = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        if not carpeta:
            return {"ok": False}
        carpeta = carpeta[0]

        filas = []
        for c in contactos:
            etiquetas = ", ".join(e["nombre"] for e in db.etiquetas_de_contacto(c["numero"]))
            filas.append({
                "Nombre": c.get("nombre") or "",
                "Número": c.get("numero_completo") or c.get("numero") or "",
                "Empresa": c.get("empresa") or "",
                "Correo": c.get("correo") or "",
                "Dirección": c.get("direccion") or "",
                "Ciudad": c.get("ciudad") or "",
                "Etiquetas": etiquetas,
                "Primer contacto": (c.get("fecha_primera_vez") or "")[:10],
                "Última actividad": (c.get("fecha_ultima_actividad") or "")[:10],
            })

        nombre_archivo = f"contactos_{nombre_columna}".replace(" ", "_") + ".xlsx"
        ruta = os.path.join(carpeta, nombre_archivo)
        try:
            pd.DataFrame(filas).to_excel(ruta, index=False)
        except Exception as e:
            return {"ok": False, "error": f"No se pudo guardar el Excel: {e}"}
        return {"ok": True, "ruta": ruta, "total": len(filas)}

    def crear_campana_desde_columna(self, columna_id, modo):
        """
        Genera un Excel temporal con los contactos de esa columna y los
        carga como una campaña NUEVA -- el usuario elige el modo
        (básica/avanzada) igual que con cualquier campaña nueva. No se
        llena "Empresa" con la del contacto -- esa columna del Excel es
        para la empresa de QUIEN envía, no la del contacto (mismo motivo
        por el que se corrigió antes en upsert_contacto).
        """
        if self.corriendo:
            return {"ok": False, "error": "Detén la campaña actual antes de crear una nueva"}

        contactos = db.contactos_de_columna(columna_id)
        if not contactos:
            return {"ok": False, "error": "Esta columna no tiene contactos"}

        filas = [{
            "Nombre": c.get("nombre") or "",
            "Celular": c.get("numero_completo") or c.get("numero") or "",
        } for c in contactos]

        try:
            carpeta_temp = tempfile.mkdtemp()
            ruta = os.path.join(carpeta_temp, "contactos_columna.xlsx")
            pd.DataFrame(filas).to_excel(ruta, index=False)
        except Exception as e:
            return {"ok": False, "error": f"No se pudo generar el Excel temporal: {e}"}

        self.ruta_excel = None
        self.df_cache = None
        self.campana_actual_id = None

        return self._cargar_excel(ruta, modo)

    # ---- Tablero de una campaña ----
    def contactos_de_campana_agrupados(self, campana_id):
        return db.contactos_de_campana_agrupados(campana_id)

    def mover_contacto_columna(self, campana_id, numero, columna_id):
        db.asignar_contacto_a_columna(campana_id, numero, columna_id)
        return {"ok": True}

    # ---- Pantalla de inicio de Seguimiento ----
    def resumen_general_seguimiento(self):
        return db.resumen_general_seguimiento()

    def ultima_actividad_kanban(self):
        return db.ultima_actividad_kanban()

    def resumen_por_campana(self):
        return db.resumen_por_campana()

    # ---- Tareas por contacto ----
    def listar_tareas_contacto(self, numero):
        return db.listar_tareas_contacto(numero)

    def agregar_tarea_contacto(self, numero, titulo):
        titulo = (titulo or "").strip()
        if not titulo:
            return {"ok": False, "error": "La tarea está vacía"}
        db.agregar_tarea_contacto(numero, titulo)
        return {"ok": True, "tareas": db.listar_tareas_contacto(numero)}

    def editar_tarea_contacto(self, tarea_id, titulo, numero):
        titulo = (titulo or "").strip()
        if not titulo:
            return {"ok": False, "error": "La tarea no puede quedar vacía"}
        db.editar_tarea_contacto(tarea_id, titulo)
        return {"ok": True, "tareas": db.listar_tareas_contacto(numero)}

    def marcar_tarea_contacto(self, tarea_id, completado, numero):
        db.marcar_tarea_contacto(tarea_id, completado)
        return {"ok": True, "tareas": db.listar_tareas_contacto(numero)}

    def eliminar_tarea_contacto(self, tarea_id, numero):
        db.eliminar_tarea_contacto(tarea_id)
        return {"ok": True, "tareas": db.listar_tareas_contacto(numero)}

    # ---- Catálogo de productos/servicios ----
    def listar_catalogo_productos(self):
        return db.listar_catalogo_productos()

    def sugerir_producto_similar(self, nombre):
        return db.sugerir_producto_similar(nombre)

    def agregar_producto_catalogo(self, nombre):
        nombre = (nombre or "").strip()
        if not nombre:
            return {"ok": False, "error": "El nombre está vacío"}
        producto_id = db.agregar_producto_catalogo(nombre)
        return {"ok": True, "id": producto_id, "catalogo": db.listar_catalogo_productos()}

    def registrar_venta_contacto(self, numero, producto_id):
        db.registrar_venta_contacto(numero, producto_id)
        return {"ok": True, "ventas": db.listar_ventas_contacto(numero)}

    def listar_ventas_contacto(self, numero):
        return db.listar_ventas_contacto(numero)

    def eliminar_venta_contacto(self, venta_id, numero):
        db.eliminar_venta_contacto(venta_id)
        return {"ok": True, "ventas": db.listar_ventas_contacto(numero)}

    # ---- Catálogo de motivos de queja ----
    def listar_catalogo_quejas(self):
        return db.listar_catalogo_quejas()

    def sugerir_motivo_queja_similar(self, nombre):
        return db.sugerir_motivo_queja_similar(nombre)

    def agregar_motivo_queja_catalogo(self, nombre):
        nombre = (nombre or "").strip()
        if not nombre:
            return {"ok": False, "error": "El nombre está vacío"}
        motivo_id = db.agregar_motivo_queja_catalogo(nombre)
        return {"ok": True, "id": motivo_id, "catalogo": db.listar_catalogo_quejas()}

    def registrar_queja_contacto(self, numero, motivo_id):
        db.registrar_queja_contacto(numero, motivo_id)
        return {"ok": True, "quejas": db.listar_quejas_contacto(numero)}

    def listar_quejas_contacto(self, numero):
        return db.listar_quejas_contacto(numero)

    def eliminar_queja_contacto(self, queja_id, numero):
        db.eliminar_queja_contacto(queja_id)
        return {"ok": True, "quejas": db.listar_quejas_contacto(numero)}

    # ---- Inteligencia comercial (Dashboard) ----
    def dashboard_inteligencia_comercial(self):
        return {
            "producto_mas_vendido": db.producto_mas_vendido(),
            "motivo_queja_mas_comun": db.motivo_queja_mas_comun(),
            "compradores_unicos": db.compradores_unicos(),
        }

    def listar_notas_contacto(self, numero):
        return db.listar_notas_contacto(numero)

    def agregar_nota_contacto(self, numero, texto):
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "error": "La nota está vacía"}
        db.agregar_nota_contacto(numero, texto)
        return {"ok": True, "notas": db.listar_notas_contacto(numero)}

    def editar_nota_contacto(self, nota_id, texto, numero):
        texto = (texto or "").strip()
        if not texto:
            return {"ok": False, "error": "La nota no puede quedar vacía"}
        db.editar_nota_contacto(nota_id, texto)
        return {"ok": True, "notas": db.listar_notas_contacto(numero)}

    def eliminar_nota_contacto(self, nota_id, numero):
        db.eliminar_nota_contacto(nota_id)
        return {"ok": True, "notas": db.listar_notas_contacto(numero)}

    def listar_etiquetas(self):
        return db.listar_etiquetas()

    def etiquetas_de_contacto(self, numero):
        return db.etiquetas_de_contacto(numero)

    def agregar_etiqueta_a_contacto(self, numero, nombre_etiqueta):
        nombre_etiqueta = (nombre_etiqueta or "").strip()
        if not nombre_etiqueta:
            return {"ok": False, "error": "La etiqueta está vacía"}
        db.agregar_etiqueta_a_contacto(numero, nombre_etiqueta)
        return {"ok": True, "etiquetas": db.etiquetas_de_contacto(numero)}

    def quitar_etiqueta_de_contacto(self, numero, etiqueta_id):
        db.quitar_etiqueta_de_contacto(numero, etiqueta_id)
        return {"ok": True, "etiquetas": db.etiquetas_de_contacto(numero)}

    # =========================================================
    # Reportes
    # =========================================================
    def listar_campanas_reporte(self):
        campanas = db.listar_campanas_home()
        return [{"id": c["id"], "nombre": c["nombre"]} for c in campanas]

    TAMANO_PAGINA_REPORTE = 500

    def exportar_reporte(self, formato, campana_id, fecha_desde, fecha_hasta):
        campana_id = campana_id or None
        fecha_desde = fecha_desde or None
        fecha_hasta = fecha_hasta or None

        envios = db.obtener_envios(campana_id=campana_id, fecha_desde=fecha_desde, fecha_hasta=fecha_hasta)

        if not envios:
            return {"ok": False, "error": "No hay datos para exportar con esos filtros"}

        carpeta = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        if not carpeta:
            return {"ok": False}
        carpeta = carpeta[0]

        campana_nombre = envios[0].get("campana", "todas") if campana_id else "todas"
        rango = f"{fecha_desde or 'inicio'}_a_{fecha_hasta or 'hoy'}"
        nombre_base = f"reporte_{rango}_{campana_nombre}".replace(" ", "_")

        try:
            if formato in ("excel", "csv"):
                # Se pagina en archivos de 500 filas cuando el historial es
                # grande -- un solo archivo gigante es incómodo de abrir y
                # de mandar por correo/WhatsApp.
                paginas = [
                    envios[i:i + self.TAMANO_PAGINA_REPORTE]
                    for i in range(0, len(envios), self.TAMANO_PAGINA_REPORTE)
                ] or [envios]

                rutas = []
                sufijo = ".xlsx" if formato == "excel" else ".csv"
                for i, pagina in enumerate(paginas, start=1):
                    parte = f"_parte{i}" if len(paginas) > 1 else ""
                    ruta_pagina = os.path.join(carpeta, f"{nombre_base}{parte}{sufijo}")
                    df_pagina = pd.DataFrame(pagina)
                    if formato == "excel":
                        df_pagina.to_excel(ruta_pagina, index=False)
                    else:
                        df_pagina.to_csv(ruta_pagina, index=False, encoding="utf-8-sig")
                    rutas.append(ruta_pagina)

                return {"ok": True, "ruta": rutas[0], "rutas": rutas, "paginas": len(paginas)}

            elif formato == "pdf":
                # El PDF (reportlab) repite el encabezado en cada página
                # automáticamente -- no necesita dividirse en archivos.
                ruta = os.path.join(carpeta, nombre_base + ".pdf")
                _generar_pdf(envios, ruta, campana_nombre, fecha_desde, fecha_hasta)
            elif formato == "log":
                ruta = os.path.join(carpeta, nombre_base + ".txt")
                with open(ruta, "w", encoding="utf-8") as f:
                    for e in envios:
                        f.write(
                            f"[{e['fecha']}] Campaña: {e.get('campana','')} | "
                            f"Segmento: {e.get('segmento','')} | "
                            f"{e['nombre']} ({e['numero']}) - {e['estado']} {e.get('error','')}\n"
                        )
            else:
                return {"ok": False, "error": "Formato no reconocido"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

        return {"ok": True, "ruta": ruta, "rutas": [ruta], "paginas": 1}

    # =========================================================
    # Información
    # =========================================================
    def obtener_tema(self):
        return db.obtener_config("tema", "claro")

    def guardar_tema(self, tema):
        db.guardar_config("tema", tema)
        return {"ok": True}

    def info_app(self):
        return {"version": APP_VERSION, "licencia": "Uso comercial autorizado"}

    def exportar_respaldo(self):
        """Copia datos.db a donde el usuario elija -- historial de
        campañas, notas, checklist, recordatorios y plantillas, todo
        en un solo archivo."""
        if self.corriendo:
            return {"ok": False, "error": "Detén la campaña actual antes de exportar un respaldo"}

        nombre_sugerido = f"respaldo_whatsapp_masivos_{date.today().isoformat()}.db"
        resultado = self.window.create_file_dialog(webview.SAVE_DIALOG, save_filename=nombre_sugerido)
        if not resultado:
            return {"ok": False}
        ruta_destino = resultado if isinstance(resultado, str) else resultado[0]

        try:
            shutil.copy2(db.ruta_db(), ruta_destino)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "ruta": ruta_destino}

    def importar_respaldo(self):
        """Reemplaza la base de datos actual por un respaldo elegido por
        el usuario. Hace una copia de seguridad del estado actual antes,
        por si el usuario elige el archivo equivocado."""
        if self.corriendo:
            return {"ok": False, "error": "Detén la campaña actual antes de restaurar un respaldo"}

        resultado = self.window.create_file_dialog(
            webview.OPEN_DIALOG, file_types=("Base de datos (*.db)",)
        )
        if not resultado:
            return {"ok": False}
        ruta_origen = resultado[0]

        try:
            # Copia de seguridad del estado actual antes de sobrescribir
            respaldo_previo = db.ruta_db() + ".antes_de_restaurar.bak"
            if os.path.exists(db.ruta_db()):
                shutil.copy2(db.ruta_db(), respaldo_previo)

            shutil.copy2(ruta_origen, db.ruta_db())
        except Exception as e:
            return {"ok": False, "error": str(e)}

        return {"ok": True}

    def reporte_disponible(self):
        """La interfaz usa esto para saber si mostrar o no la opción de
        reportar a soporte -- si el proveedor todavía no configuró el
        Google Form, no tiene sentido ofrecerlo."""
        return _reporte_configurado()

    def enviar_reporte_error(self, contexto_usuario=""):
        """
        Toma las últimas líneas del log local de errores y las manda al
        formulario de soporte -- SOLO cuando el usuario lo pide
        explícitamente desde el botón de Información. Nunca en silencio.
        """
        if not _reporte_configurado():
            return {"ok": False, "error": "El envío de reportes todavía no está configurado por el proveedor."}

        try:
            ruta = _ruta_log_errores()
            if os.path.exists(ruta):
                with open(ruta, "r", encoding="utf-8") as f:
                    lineas = f.readlines()
                detalle = "".join(lineas[-60:])  # últimas ~60 líneas, suficiente contexto
            else:
                detalle = "(sin errores registrados todavía)"

            datos = urllib.parse.urlencode({
                GOOGLE_FORM_ENTRY_VERSION: APP_VERSION,
                GOOGLE_FORM_ENTRY_DETALLE: detalle[-4000:],  # los formularios de Google truncan textos muy largos
                GOOGLE_FORM_ENTRY_CONTEXTO: contexto_usuario or "(sin descripción del usuario)",
            }).encode("utf-8")

            req = urllib.request.Request(GOOGLE_FORM_URL, data=datos, headers={"User-Agent": "WhatsAppMasivos"})
            urllib.request.urlopen(req, timeout=8)
            return {"ok": True}
        except Exception as e:
            logging.error(f"No se pudo enviar el reporte de error: {e}", exc_info=True)
            return {"ok": False, "error": "No se pudo enviar el reporte (revisa tu conexión a internet)."}

    def es_primera_vez(self):
        cfg = _leer_config_app()
        return not cfg.get("onboarding_visto", False)

    def marcar_onboarding_visto(self):
        cfg = _leer_config_app()
        cfg["onboarding_visto"] = True
        _guardar_config_app(cfg)
        return {"ok": True}

    # =========================================================
    # Licencia
    # =========================================================
    def obtener_hardware_id(self):
        return licencias.hardware_id()

    def verificar_licencia(self):
        print("[Api] verificar_licencia() llamado", flush=True)
        cfg = _leer_config_app()
        lic = cfg.get("licencia")

        if not lic:
            print("[Api] verificar_licencia() -> sin_activar", flush=True)
            return {"estado": "sin_activar"}

        hoy = date.today()
        fecha_exp = date.fromisoformat(lic["fecha_expiracion"])
        ultima_observada = date.fromisoformat(
            lic.get("ultima_fecha_valida_observada", lic["fecha_generacion"])
        )

        # Si la fecha actual del sistema es ANTERIOR a la última fecha
        # válida que ya vimos, lo más probable es que alguien atrasó el
        # reloj de Windows para intentar revivir una licencia vencida.
        if hoy < ultima_observada:
            print("[Api] verificar_licencia() -> manipulada", flush=True)
            return {"estado": "manipulada"}

        lic["ultima_fecha_valida_observada"] = hoy.isoformat()
        cfg["licencia"] = lic
        _guardar_config_app(cfg)

        if hoy > fecha_exp:
            print("[Api] verificar_licencia() -> vencida", flush=True)
            return {"estado": "vencida", "fecha_expiracion": lic["fecha_expiracion"]}

        print("[Api] verificar_licencia() -> valida", flush=True)
        return {
            "estado": "valida",
            "dias_restantes": (fecha_exp - hoy).days,
            "fecha_expiracion": lic["fecha_expiracion"],
        }

    def activar_licencia(self, codigo):
        print(f"[Api] activar_licencia() llamado con código: {codigo[:15]}...", flush=True)
        resultado = licencias.validar_codigo(codigo, licencias.hardware_id())
        if not resultado["ok"]:
            print(f"[Api] activar_licencia() -> rechazado: {resultado['error']}", flush=True)
            return {"ok": False, "error": resultado["error"]}

        cfg = _leer_config_app()
        cfg["licencia"] = {
            "fecha_generacion": resultado["fecha_generacion"],
            "fecha_expiracion": resultado["fecha_expiracion"],
            "dias": resultado["dias"],
            "ultima_fecha_valida_observada": date.today().isoformat(),
        }
        _guardar_config_app(cfg)
        print("[Api] activar_licencia() -> guardado correctamente", flush=True)

        return {
            "ok": True,
            "fecha_expiracion": resultado["fecha_expiracion"],
            "dias": resultado["dias"],
        }

    # =========================================================
    # Activación de licencias (SOLO visible en el equipo del dueño)
    # =========================================================
    def es_dueno(self):
        return licencias.hardware_id() in HARDWARE_IDS_DUENO

    def obtener_url_solicitud_licencia(self):
        """Arma el enlace del formulario de solicitud, con el código de
        equipo ya prellenado -- o vacío si David todavía no lo configuró
        (ver URL_FORMULARIO_LICENCIA arriba)."""
        if URL_FORMULARIO_LICENCIA == "PENDIENTE" or ENTRY_CODIGO_EQUIPO_LICENCIA == "PENDIENTE":
            return ""
        codigo = urllib.parse.quote(licencias.hardware_id())
        separador = "&" if "?" in URL_FORMULARIO_LICENCIA else "?"
        return f"{URL_FORMULARIO_LICENCIA}{separador}{ENTRY_CODIGO_EQUIPO_LICENCIA}={codigo}"

    def obtener_precios_licencia(self):
        return {
            "mensual": float(db.obtener_config("precio_mensual", "15")),
            "trimestral": float(db.obtener_config("precio_trimestral", "38")),
        }

    def guardar_precios_licencia(self, mensual, trimestral):
        db.guardar_config("precio_mensual", str(mensual))
        db.guardar_config("precio_trimestral", str(trimestral))
        return {"ok": True}

    def obtener_url_hoja_licencias(self):
        return db.obtener_config("url_hoja_licencias", "")

    def guardar_url_hoja_licencias(self, url):
        db.guardar_config("url_hoja_licencias", url.strip())
        return {"ok": True}

    def sincronizar_solicitudes_licencia(self, url_hoja):
        """Lee la hoja de Google (publicada como CSV) y guarda las
        solicitudes nuevas -- las que ya se habían importado antes no se
        duplican."""
        if not url_hoja:
            return {"ok": False, "error": "Falta configurar el enlace de la hoja de Google"}

        filas, error = _fetch_csv(url_hoja)
        if error:
            return {"ok": False, "error": error}

        nuevas = 0
        for fila in filas:
            # Nombres de columnas tal como quedaron los títulos reales de
            # las preguntas del formulario -- si alguna pregunta cambia
            # de título más adelante, hay que ajustar estas claves.
            hardware_id = (fila.get("Código de equipo") or "").strip()
            if not hardware_id:
                continue
            fila_hash = hashlib.sha256(str(fila).encode("utf-8")).hexdigest()
            resultado = db.guardar_solicitud_si_nueva(
                fila_hash=fila_hash,
                hardware_id=hardware_id,
                nombres=(fila.get("Nombres") or "").strip(),
                apellidos=(fila.get("Apellidos") or "").strip(),
                whatsapp=(fila.get("Número de celular") or "").strip(),
                plan=(fila.get("Elija su plan") or "Mensual").strip(),
                banco=(fila.get("Banco donde realizó su pago") or "").strip(),
                num_transaccion=(fila.get("Número de transacción de su comprobante físico o digital") or "").strip(),
                comprobante_url="",
                fecha_solicitud=(fila.get("Marca temporal") or datetime.now().isoformat()),
            )
            if resultado:
                nuevas += 1

        return {"ok": True, "nuevas": nuevas, "solicitudes": db.listar_solicitudes_pendientes()}

    def listar_solicitudes_pendientes_licencia(self):
        pendientes = db.listar_solicitudes_pendientes()
        for s in pendientes:
            s["whatsapp_normalizado"] = normalizar_numero_whatsapp(s.get("whatsapp"))
            s["posible_duplicado"] = db.hay_duplicado_del_mes(s["hardware_id"], s["id"])
        return pendientes

    def listar_solicitudes_rechazadas_licencia(self):
        rechazadas = db.listar_solicitudes_rechazadas()
        for s in rechazadas:
            s["whatsapp_normalizado"] = normalizar_numero_whatsapp(s.get("whatsapp"))
        return rechazadas

    def rechazar_solicitud_licencia(self, solicitud_id, motivo):
        motivo = (motivo or "").strip()
        if not motivo:
            return {"ok": False, "error": "Escribe el motivo del rechazo para poder retomarlo después."}
        db.rechazar_solicitud(solicitud_id, motivo)
        return {
            "ok": True,
            "pendientes": self.listar_solicitudes_pendientes_licencia(),
            "rechazadas": self.listar_solicitudes_rechazadas_licencia(),
        }

    def reactivar_solicitud_licencia(self, solicitud_id):
        db.reactivar_solicitud(solicitud_id)
        return {
            "ok": True,
            "pendientes": self.listar_solicitudes_pendientes_licencia(),
            "rechazadas": self.listar_solicitudes_rechazadas_licencia(),
        }

    def abrir_whatsapp_solicitud(self, solicitud_id):
        """Abre WhatsApp Web directo con el contacto de una solicitud --
        para aclarar dudas, avisar un rechazo, o cualquier trato
        personalizado antes/después de procesarla. Reutiliza el mismo
        mecanismo que abrir_whatsapp_contacto (mismo perfil de Chrome del
        motor de envío)."""
        solicitud = db.obtener_solicitud(solicitud_id)
        if not solicitud:
            return {"ok": False, "error": "Solicitud no encontrada"}
        return self.abrir_whatsapp_contacto(solicitud.get("whatsapp"))

    def generar_codigo_solicitud(self, solicitud_id):
        solicitud = db.obtener_solicitud(solicitud_id)
        if not solicitud:
            return {"ok": False, "error": "Solicitud no encontrada"}
        dias = db.dias_del_plan(solicitud["plan"])
        codigo = licencias.generar_codigo(solicitud["hardware_id"], dias)
        db.guardar_codigo_generado(solicitud_id, codigo)
        return {"ok": True, "solicitudes": self.listar_solicitudes_pendientes_licencia()}

    def enviar_codigos_licencia(self, ids, mensaje_plantilla):
        if self.corriendo:
            return {"ok": False, "error": "Hay una campaña en curso -- espera a que termine antes de enviar códigos de licencia."}

        solicitudes = [db.obtener_solicitud(i) for i in ids]
        solicitudes = [s for s in solicitudes if s and s.get("codigo_generado")]
        if not solicitudes:
            return {"ok": False, "error": "No hay códigos generados todavía para enviar"}

        self.corriendo = True
        hilo = threading.Thread(
            target=self._enviar_codigos_licencia_hilo, args=(solicitudes, mensaje_plantilla), daemon=True
        )
        hilo.start()
        return {"ok": True, "total": len(solicitudes)}

    def _enviar_codigos_licencia_hilo(self, solicitudes, mensaje_plantilla):
        inicio = time.time()
        engine = CampaignEngine(velocidad="Normal", log_callback=lambda t: self._js("appLicenciaLog", t))
        ids_enviados = []
        try:
            engine.iniciar_navegador()
            for s in solicitudes:
                mensaje = (
                    mensaje_plantilla
                    .replace("{Nombre}", s.get("nombres") or "")
                    .replace("{Apellido}", s.get("apellidos") or "")
                    .replace("{Codigo}", s.get("codigo_generado") or "")
                )
                try:
                    engine.abrir_chat(s["whatsapp"])
                    engine.enviar_texto_en_chat(mensaje)
                    ids_enviados.append(s["id"])
                    self._js("appLicenciaLog", f"✅ Código enviado a {s.get('nombres','')} {s.get('apellidos','')}")
                except Exception as e:
                    self._js("appLicenciaLog", f"❌ Error enviando a {s.get('nombres','')}: {e}")
        except Exception as e:
            logging.error(f"Error en el envío de códigos de licencia: {e}", exc_info=True)
            self._js("appLicenciaLog", f"❌ Error inesperado, no se pudo continuar: {e}")
        finally:
            try:
                engine.cerrar_navegador()
            except Exception:
                pass
            if ids_enviados:
                db.marcar_solicitudes_enviadas(ids_enviados)
            self.corriendo = False
            segundos = int(time.time() - inicio)
            self._js("appCodigosLicenciaTerminado", len(ids_enviados), segundos)

    def dashboard_licencias(self, anio_mes=None):
        return db.resumen_licencias_mes(anio_mes)

    def dashboard_licencias_general(self):
        return {
            "usuarios_totales": db.usuarios_totales_licencias(),
            "usuarios_activos": db.usuarios_activos_licencias(),
            "clientes_perdidos": db.clientes_perdidos(),
            "comparativa_planes": db.comparativa_planes_licencias(),
        }

    def historial_licencias(self):
        return db.historial_mensual_licencias()

    # ---- Tarjetas por mes (Activación) ----
    def meses_disponibles_licencias(self):
        return db.meses_disponibles_licencias()

    def solicitudes_del_mes_licencia(self, anio_mes):
        solicitudes = db.solicitudes_del_mes(anio_mes)
        for s in solicitudes:
            s["whatsapp_normalizado"] = normalizar_numero_whatsapp(s.get("whatsapp"))
        return solicitudes

    def exportar_solicitudes_mes_licencia(self, anio_mes):
        solicitudes = db.solicitudes_del_mes(anio_mes)
        if not solicitudes:
            return {"ok": False, "error": "No hay licencias otorgadas ese mes para exportar"}
        return self._exportar_licencias_a_excel(solicitudes, f"activaciones_{anio_mes}.xlsx")

    def exportar_licencias_rango(self, mes_inicio, mes_fin):
        if not mes_inicio or not mes_fin:
            return {"ok": False, "error": "Elige el mes de inicio y el mes final"}
        if mes_inicio > mes_fin:
            mes_inicio, mes_fin = mes_fin, mes_inicio
        solicitudes = db.solicitudes_rango_meses(mes_inicio, mes_fin)
        if not solicitudes:
            return {"ok": False, "error": "No hay licencias otorgadas en ese rango de meses"}
        return self._exportar_licencias_a_excel(solicitudes, f"activaciones_{mes_inicio}_a_{mes_fin}.xlsx")

    def _exportar_licencias_a_excel(self, solicitudes, nombre_archivo):
        carpeta = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        if not carpeta:
            return {"ok": False}
        carpeta = carpeta[0]

        filas = []
        for s in solicitudes:
            filas.append({
                "Nombres": s.get("nombres", ""),
                "Apellidos": s.get("apellidos", ""),
                "WhatsApp": normalizar_numero_whatsapp(s.get("whatsapp")),
                "Plan": s.get("plan", ""),
                "Banco": s.get("banco", ""),
                "N° transacción": s.get("num_transaccion", ""),
                "Monto esperado": s.get("monto_esperado", ""),
                "Es renovación": "Sí" if s.get("es_renovacion") else "No",
                "Activaciones históricas del cliente": s.get("total_licencias_cliente", ""),
                "Fecha de solicitud": s.get("fecha_solicitud", ""),
                "Fecha de envío": s.get("fecha_enviado", "") or "",
            })

        ruta = os.path.join(carpeta, nombre_archivo)
        try:
            pd.DataFrame(filas).to_excel(ruta, index=False)
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True, "ruta": ruta}

    # =========================================================
    # Plantillas por rubro (descargadas desde GitHub)
    # =========================================================
    def listar_rubros_disponibles(self):
        datos, error = _fetch_json(f"{GITHUB_RAW_BASE}/plantillas/rubros/indice.json")
        if error:
            return {"ok": False, "error": error}
        return {"ok": True, "rubros": datos.get("rubros", [])}

    def instalar_rubro(self, rubro_id):
        datos, error = _fetch_json(f"{GITHUB_RAW_BASE}/plantillas/rubros/{rubro_id}.json")
        if error:
            return {"ok": False, "error": error}

        plantillas_nuevas = datos.get("plantillas", [])
        existentes = db.listar_plantillas()
        ya_instaladas = {(p["nombre"], p["contenido"]) for p in existentes}

        instaladas = 0
        omitidas = 0
        for p in plantillas_nuevas:
            clave = (p.get("nombre", ""), p.get("contenido", ""))
            if clave in ya_instaladas or not clave[0] or not clave[1]:
                omitidas += 1
                continue
            db.crear_plantilla(p["nombre"], p["contenido"])
            instaladas += 1

        return {
            "ok": True,
            "rubro": datos.get("rubro", rubro_id),
            "instaladas": instaladas,
            "omitidas": omitidas,
        }

    # =========================================================
    # Actualizaciones (GitHub Releases)
    # =========================================================
    def verificar_actualizacion(self):
        datos, error = _fetch_json(GITHUB_RELEASES_API)
        if error:
            return {"ok": False, "error": error}

        tag = (datos.get("tag_name") or "").lstrip("vV")
        url_descarga = datos.get("html_url", "")
        notas = datos.get("body", "")

        def version_a_tupla(v):
            partes = []
            for parte in v.split("."):
                digitos = "".join(c for c in parte if c.isdigit())
                partes.append(int(digitos) if digitos else 0)
            return tuple(partes)

        hay_actualizacion = False
        try:
            hay_actualizacion = version_a_tupla(tag) > version_a_tupla(APP_VERSION)
        except Exception:
            pass

        return {
            "ok": True,
            "version_actual": APP_VERSION,
            "version_disponible": tag,
            "hay_actualizacion": hay_actualizacion,
            "url_descarga": url_descarga,
            "notas": notas,
        }


# Envuelve automáticamente cada método público de Api con el registro de
# errores -- así, cualquier excepción en cualquier método (sin tener que
# acordarse de agregarlo uno por uno) queda guardada en errores.log antes
# de propagarse. Esto es justo lo que nos hubiera ahorrado horas de
# depuración a ciegas con el bug de Nuitka de hace un rato.
for _nombre_metodo in dir(Api):
    if not _nombre_metodo.startswith("_"):
        _atributo = getattr(Api, _nombre_metodo)
        if callable(_atributo):
            setattr(Api, _nombre_metodo, _con_registro_errores(_atributo))


def _generar_pdf(envios, ruta, campana_nombre, fecha_desde, fecha_hasta):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

    doc = SimpleDocTemplate(ruta, pagesize=letter)
    estilos = getSampleStyleSheet()
    elementos = []

    rango_txt = f"{fecha_desde or 'inicio'} — {fecha_hasta or 'hoy'}"
    titulo = f"Reporte de envíos — {campana_nombre} — {rango_txt}"
    elementos.append(Paragraph(titulo, estilos["Title"]))
    elementos.append(Spacer(1, 12))

    datos = [["Fecha", "Campaña", "Segmento", "Nombre", "Número", "Estado", "Error"]]
    for e in envios:
        datos.append([
            e["fecha"][:16], e.get("campana", ""), e.get("segmento", ""),
            e["nombre"], e["numero"], e["estado"], e.get("error", "")[:35]
        ])

    tabla = Table(datos, repeatRows=1)
    tabla.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#7c3aed")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f0fa")]),
    ]))
    elementos.append(tabla)
    doc.build(elementos)


def _a_js(valor):
    return json.dumps(valor)


def ruta_recurso(rel_path):
    """
    Resuelve rutas a archivos empaquetados (como la carpeta ui/), sin
    importar si el programa corre en modo desarrollo, compilado con
    PyInstaller, o compilado con Nuitka -- cada uno expone la ubicación
    de los datos empaquetados de una forma distinta:
      - PyInstaller: variable especial sys._MEIPASS
      - Nuitka: los datos quedan junto al ejecutable compilado
      - Desarrollo (python app.py): junto a este mismo archivo .py
    """
    if hasattr(sys, "_MEIPASS"):
        base = sys._MEIPASS
    elif "__compiled__" in globals():
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel_path)


def _hilo_recordatorios(api, intervalo_segundos=30):
    """
    Corre en segundo plano mientras el programa está abierto. Cada cierto
    tiempo revisa si algún recordatorio ya llegó a su fecha/hora y, si es
    así, dispara una notificación nativa de Windows con sonido.

    Limitación conocida (y aceptada): esto SOLO funciona si el programa
    está abierto en el momento exacto del recordatorio. Si estaba cerrado,
    el recordatorio queda pendiente y se avisa igual la próxima vez que se
    abra el programa (ver listar_recordatorios_pendientes en el Inicio).
    """
    import time as _time

    while True:
        try:
            pendientes = db.recordatorios_pendientes_de_disparar()
            for r in pendientes:
                titulo = f"⏰ {r['campana_nombre']}"
                mensaje = r["texto"]

                # Sonido de alerta -- más notorio que solo el aviso silencioso
                # de la notificación. winsound es nativo de Windows (no
                # requiere instalar nada) y no rompe el programa si por
                # alguna razón no está disponible.
                try:
                    import winsound
                    for _ in range(3):
                        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                        _time.sleep(0.4)
                except Exception:
                    pass

                try:
                    from plyer import notification
                    notification.notify(title=titulo, message=mensaje, timeout=15)
                except Exception:
                    # Si plyer no está disponible o falla en esta PC, no se
                    # rompe el programa -- el recordatorio se marca disparado
                    # igual, y queda visible en el Inicio.
                    pass
                db.marcar_recordatorio_disparado(r["id"])
                api._js("appNuevoRecordatorio", titulo, mensaje)
        except Exception as e:
            logging.error(f"Error en el hilo de recordatorios: {e}", exc_info=True)
        _time.sleep(intervalo_segundos)


def _aplicar_estilo_ventana_windows(titulo_ventana):
    """
    Le da un toque de marca a la barra de título NATIVA de Windows (fondo
    morado oscuro, texto e íconos claros) usando la API de DWM del
    sistema -- sin quitar la barra nativa (eso sería "modo sin marco",
    un cambio de más riesgo e innecesario aquí). Si algo falla (Windows
    más viejo que no soporta esto, u otra razón), no rompe nada -- el
    programa sigue con la barra normal de Windows, solo sin el detalle
    de color.
    """
    try:
        import ctypes
        hwnd = ctypes.windll.user32.FindWindowW(None, titulo_ventana)
        if not hwnd:
            return

        dwmapi = ctypes.windll.dwmapi

        # Modo oscuro inmerso -- deja los íconos de minimizar/maximizar/
        # cerrar en blanco automáticamente (disponible desde Windows 10
        # versión 1809 en adelante).
        DWMWA_USE_IMMERSIVE_DARK_MODE = 20
        valor = ctypes.c_int(1)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, ctypes.byref(valor), ctypes.sizeof(valor))

        # Color morado de marca en el fondo de la barra -- esto solo
        # funciona en Windows 11 (compilación 22000 en adelante). En
        # Windows 10 simplemente no hace nada, sin generar error.
        DWMWA_CAPTION_COLOR = 35
        DWMWA_TEXT_COLOR = 36
        # DWM espera el color en formato 0x00BBGGRR (al revés de como
        # normalmente escribimos hex de colores RRGGBB).
        color_morado_marca = 0x00733F4A  # equivale a #4A3F73
        color_texto_blanco = 0x00FFFFFF

        valor_color = ctypes.c_int(color_morado_marca)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ctypes.byref(valor_color), ctypes.sizeof(valor_color))

        valor_texto = ctypes.c_int(color_texto_blanco)
        dwmapi.DwmSetWindowAttribute(hwnd, DWMWA_TEXT_COLOR, ctypes.byref(valor_texto), ctypes.sizeof(valor_texto))
    except Exception as e:
        logging.error(f"No se pudo personalizar la barra de título (no crítico): {e}", exc_info=True)

    # Ícono de la ventana/barra de tareas -- se extrae directamente del
    # propio .exe compilado (que ya lleva el ícono de marca gracias a
    # --icon en build.bat), así no hace falta empaquetar el .ico aparte
    # ni mantener dos copias sincronizadas. En modo desarrollo
    # (python app.py) esto no encuentra nada y simplemente no hace nada.
    try:
        WM_SETICON = 0x0080
        ICON_SMALL = 0
        ICON_BIG = 1
        hicon_grande = ctypes.c_void_p()
        hicon_chico = ctypes.c_void_p()
        ctypes.windll.shell32.ExtractIconExW(
            sys.executable, 0, ctypes.byref(hicon_grande), ctypes.byref(hicon_chico), 1
        )
        if hicon_chico.value:
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_SMALL, hicon_chico.value)
        if hicon_grande.value:
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, ICON_BIG, hicon_grande.value)
    except Exception as e:
        logging.error(f"No se pudo asignar el ícono de la ventana (no crítico): {e}", exc_info=True)


def main():
    print("[1] Configurando logging...", flush=True)
    configurar_logging()
    try:
        print("[2] Inicializando base de datos...", flush=True)
        db.inicializar()
        print("[3] Base de datos lista. Creando instancia de Api...", flush=True)
        try:
            creadas = db.generar_tareas_reconexion(dias_umbral=20)
            if creadas:
                print(f"[3b] {creadas} tarea(s) de reconexión creada(s) automáticamente.", flush=True)
        except Exception as e:
            logging.error(f"No se pudieron generar las tareas de reconexión (no crítico): {e}", exc_info=True)
        api = Api()

        print("[4] Creando ventana de pywebview (esto carga ui/index.html)...", flush=True)
        window = webview.create_window(
            "Ola",
            ruta_recurso(os.path.join("ui", "index.html")),
            js_api=api,
            width=1250,
            height=800,
            min_size=(1050, 680),
        )
        print("[5] Ventana creada. Asignando referencia a Api...", flush=True)
        api.set_window(window)
        window.events.shown += lambda: _aplicar_estilo_ventana_windows("Ola")

        print("[6] Iniciando hilo de recordatorios en segundo plano...", flush=True)
        hilo_recordatorios = threading.Thread(target=_hilo_recordatorios, args=(api,), daemon=True)
        hilo_recordatorios.start()

        print("[7] Todo listo. Llamando a webview.start() -- aquí es donde se abre la ventana de verdad...", flush=True)
        webview.start()
        print("[8] webview.start() terminó (esto solo se ve al CERRAR el programa normalmente).", flush=True)
    except Exception as e:
        print(f"[ERROR] Excepción capturada: {e}", flush=True)
        logging.error(f"Fallo catastrófico al iniciar el programa: {e}", exc_info=True)
        # Aviso visible incluso si la ventana principal nunca llegó a abrir
        # (tkinter es parte de Python, no depende de que pywebview haya
        # arrancado bien -- por eso sirve como respaldo aquí).
        try:
            import tkinter
            from tkinter import messagebox
            raiz = tkinter.Tk()
            raiz.withdraw()
            messagebox.showerror(
                "Ola",
                "El programa no pudo iniciar debido a un error inesperado.\n\n"
                f"Detalle guardado en:\n{_ruta_log_errores()}\n\n"
                "Comparte ese archivo con tu proveedor para recibir ayuda."
            )
        except Exception:
            pass


if __name__ == "__main__":
    main()
