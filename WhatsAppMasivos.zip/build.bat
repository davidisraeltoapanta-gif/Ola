@echo off
REM ===========================================
REM  BUILD - WhatsApp Masivos v3 (interfaz web embebida)
REM  Ejecutar en Windows, dentro de la carpeta del proyecto.
REM ===========================================

echo.
echo [1/4] Creando entorno virtual...
python -m venv venv
call venv\Scripts\activate.bat

echo.
echo [2/4] Instalando dependencias...
pip install --upgrade pip
pip install -r requirements.txt

echo.
echo [3/4] Compilando ejecutable con PyInstaller...
REM --onedir (no --onefile): queda una carpeta con el .exe y sus archivos
REM ya listos -- arranca casi instantaneo, en vez de tener que descomprimir
REM todo de nuevo cada vez que se abre (eso era lo que causaba la demora
REM larga al abrir y la sensacion de que se "colgaba").
REM --add-data "ui;ui"  incluye la carpeta de la interfaz web dentro del .exe
pyinstaller --noconfirm --onedir --windowed ^
  --name "WhatsAppMasivos" ^
  --icon "build_assets\ola.ico" ^
  --add-data "ui;ui" ^
  --hidden-import "selenium.webdriver.chrome.webdriver" ^
  --hidden-import "selenium.webdriver.chrome.service" ^
  --hidden-import "selenium.webdriver.chrome.options" ^
  --hidden-import "selenium.webdriver.common.service" ^
  --hidden-import "selenium.webdriver.support.expected_conditions" ^
  app.py

echo.
echo [4/4] Listo. La carpeta del programa esta en "dist\WhatsAppMasivos"
echo       dist\WhatsAppMasivos\WhatsAppMasivos.exe
echo.
echo NOTA: pywebview usa el motor Edge WebView2 en Windows 10/11
echo (normalmente ya viene instalado de fabrica). Si en alguna PC
echo no abre, puede necesitar el "WebView2 Runtime" de Microsoft.
echo.
pause
