@echo off
REM ===========================================
REM  BUILD DE DIAGNOSTICO - WhatsApp Masivos
REM  SOLO para encontrar el bug de la PC que se traba -- esto muestra una
REM  consola negra al lado de la ventana normal, con mensajes en tiempo
REM  real [1] [2] [3]... que dicen exactamente en que paso va el programa.
REM
REM  Cuando terminemos de diagnosticar, se vuelve a usar build.bat (el
REM  normal, sin consola) para la version que reciben los clientes.
REM ===========================================

echo.
echo [1/3] Activando entorno virtual...
call venv\Scripts\activate.bat

echo.
echo [2/3] Instalando dependencias (por si acaso)...
python -m pip install -r requirements.txt

echo.
echo [3/3] Compilando CON CONSOLA VISIBLE...
REM Nota: --console (no --windowed) es la unica diferencia real contra
REM build.bat -- todo lo demas queda igual.
pyinstaller --noconfirm --onedir --console ^
  --name "WhatsAppMasivosDiagnostico" ^
  --add-data "ui;ui" ^
  --hidden-import "selenium.webdriver.chrome.webdriver" ^
  --hidden-import "selenium.webdriver.chrome.service" ^
  --hidden-import "selenium.webdriver.chrome.options" ^
  --hidden-import "selenium.webdriver.common.service" ^
  --hidden-import "selenium.webdriver.support.expected_conditions" ^
  app.py

echo.
echo Listo. La carpeta de diagnostico esta en:
echo       dist\WhatsAppMasivosDiagnostico\
echo.
echo Comprime esa carpeta COMPLETA (botón derecho > Enviar a > Carpeta
echo comprimida) y pasala a la otra PC. Ahi, descomprimela y ejecuta
echo el .exe que esta adentro -- va a abrir DOS ventanas: la consola
echo negra con los mensajes [1] [2] [3]... y la ventana normal del
echo programa. Cuando se trabe, copia o fotografia todo el texto que
echo se alcance a ver en la consola negra.
echo.
pause
