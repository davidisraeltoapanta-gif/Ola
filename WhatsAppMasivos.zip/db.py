"""
db.py
Base de datos local (SQLite) para historial de campañas, notas de
seguimiento, plantillas reutilizables, Dashboard y Reportes.

Incluye migración segura: si ya existe una base de datos de una versión
anterior (sin las columnas/tablas nuevas), se agregan automáticamente sin
perder lo que ya había.
"""

import os
import re
import sqlite3
import json
from datetime import datetime, timedelta
import pandas as pd


def carpeta_datos_app():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    ruta = os.path.join(base, "WhatsAppMasivos")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def ruta_db():
    return os.path.join(carpeta_datos_app(), "datos.db")


def conectar():
    conn = sqlite3.connect(ruta_db())
    conn.row_factory = sqlite3.Row
    return conn


def _columnas(conn, tabla):
    cur = conn.execute(f"PRAGMA table_info({tabla})")
    return [f["name"] for f in cur.fetchall()]


def inicializar():
    conn = conectar()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS campanas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            fecha_creacion TEXT NOT NULL,
            fecha_fin TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS envios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            campana_id INTEGER,
            campana TEXT,
            segmento TEXT,
            nombre TEXT,
            numero TEXT,
            empresa TEXT,
            estado TEXT,
            error TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS notas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campana_id INTEGER NOT NULL,
            fecha TEXT NOT NULL,
            texto TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS plantillas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            contenido TEXT NOT NULL,
            fecha_creacion TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS pasos_campana (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campana_id INTEGER NOT NULL,
            orden INTEGER NOT NULL,
            titulo TEXT NOT NULL,
            completado INTEGER NOT NULL DEFAULT 0,
            fecha_completado TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS plantillas_campana (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            pasos_json TEXT NOT NULL,
            fecha_creacion TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS recordatorios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campana_id INTEGER NOT NULL,
            texto TEXT NOT NULL,
            fecha_hora TEXT NOT NULL,
            disparado INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS contactos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL UNIQUE,
            nombre TEXT,
            empresa TEXT,
            etapa TEXT NOT NULL DEFAULT 'Prospecto',
            fecha_primera_vez TEXT NOT NULL,
            fecha_ultima_actividad TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS notas_contacto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            fecha TEXT NOT NULL,
            texto TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS etiquetas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS contacto_etiquetas (
            numero TEXT NOT NULL,
            etiqueta_id INTEGER NOT NULL,
            PRIMARY KEY (numero, etiqueta_id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS columnas_kanban (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            campana_id INTEGER NOT NULL,
            nombre TEXT NOT NULL,
            orden INTEGER NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS contacto_campana_columna (
            campana_id INTEGER NOT NULL,
            numero TEXT NOT NULL,
            columna_id INTEGER NOT NULL,
            fecha_actualizacion TEXT NOT NULL,
            PRIMARY KEY (campana_id, numero)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS config_app (
            clave TEXT PRIMARY KEY,
            valor TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS solicitudes_licencia (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fila_hash TEXT NOT NULL UNIQUE,
            hardware_id TEXT NOT NULL,
            nombres TEXT,
            apellidos TEXT,
            whatsapp TEXT,
            plan TEXT NOT NULL,
            banco TEXT,
            num_transaccion TEXT,
            comprobante_url TEXT,
            monto_esperado REAL,
            fecha_solicitud TEXT NOT NULL,
            codigo_generado TEXT,
            fecha_generado TEXT,
            enviado INTEGER NOT NULL DEFAULT 0,
            fecha_enviado TEXT,
            es_renovacion INTEGER NOT NULL DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tareas_contacto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            titulo TEXT NOT NULL,
            completado INTEGER NOT NULL DEFAULT 0,
            fecha_creacion TEXT NOT NULL,
            fecha_completado TEXT,
            origen TEXT NOT NULL DEFAULT 'manual'
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS catalogo_productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS catalogo_quejas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL UNIQUE
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ventas_contacto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            producto_id INTEGER NOT NULL,
            fecha TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS quejas_contacto (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL,
            motivo_id INTEGER NOT NULL,
            fecha TEXT NOT NULL
        )
    """)
    conn.commit()

    # ---- Migración segura: columna "origen" en tareas_contacto (ya
    # existía de la Fase 4, esto es para bases de datos creadas antes de
    # la automatización de reconexión) ----
    cols_tareas = _columnas(conn, "tareas_contacto")
    if "origen" not in cols_tareas:
        conn.execute("ALTER TABLE tareas_contacto ADD COLUMN origen TEXT NOT NULL DEFAULT 'manual'")
    conn.commit()

    # ---- Migración segura: columnas nuevas en `contactos` (ficha) ----
    cols_contactos = _columnas(conn, "contactos")
    migraciones_contactos = {
        "correo": "ALTER TABLE contactos ADD COLUMN correo TEXT",
        "direccion": "ALTER TABLE contactos ADD COLUMN direccion TEXT",
        "ciudad": "ALTER TABLE contactos ADD COLUMN ciudad TEXT",
        "numero_completo": "ALTER TABLE contactos ADD COLUMN numero_completo TEXT",
    }
    for columna, sql in migraciones_contactos.items():
        if columna not in cols_contactos:
            conn.execute(sql)
    conn.commit()

    # ---- Migración segura de columnas nuevas en `campanas` ----
    cols = _columnas(conn, "campanas")
    migraciones = {
        "estado": "ALTER TABLE campanas ADD COLUMN estado TEXT DEFAULT 'Finalizada'",
        "ruta_excel": "ALTER TABLE campanas ADD COLUMN ruta_excel TEXT",
        "config_json": "ALTER TABLE campanas ADD COLUMN config_json TEXT",
        "total_contactos": "ALTER TABLE campanas ADD COLUMN total_contactos INTEGER DEFAULT 0",
    }
    for col, sql in migraciones.items():
        if col not in cols:
            conn.execute(sql)

    cols_envios = _columnas(conn, "envios")
    if "campana_id" not in cols_envios:
        conn.execute("ALTER TABLE envios ADD COLUMN campana_id INTEGER")

    cols_recordatorios = _columnas(conn, "recordatorios")
    if "visto" not in cols_recordatorios:
        conn.execute("ALTER TABLE recordatorios ADD COLUMN visto INTEGER DEFAULT 0")

    # ---- Migración segura: estado y motivo de rechazo en solicitudes_licencia ----
    # "estado" reemplaza el uso exclusivo de "enviado" (0/1): ahora puede ser
    # 'pendiente', 'rechazada' o 'enviada'. Las filas existentes se marcan
    # según su "enviado" actual para no perder el historial ya guardado.
    cols_solicitudes = _columnas(conn, "solicitudes_licencia")
    migraciones_solicitudes = {
        "estado": "ALTER TABLE solicitudes_licencia ADD COLUMN estado TEXT NOT NULL DEFAULT 'pendiente'",
        "motivo_rechazo": "ALTER TABLE solicitudes_licencia ADD COLUMN motivo_rechazo TEXT",
        "fecha_rechazo": "ALTER TABLE solicitudes_licencia ADD COLUMN fecha_rechazo TEXT",
    }
    for columna, sql in migraciones_solicitudes.items():
        if columna not in cols_solicitudes:
            conn.execute(sql)
    if "estado" not in cols_solicitudes:
        conn.execute("UPDATE solicitudes_licencia SET estado = 'enviada' WHERE enviado = 1")

    conn.commit()
    conn.close()


# =========================
# CAMPAÑAS
# =========================
def crear_campana(nombre, ruta_excel, config, total_contactos, estado="En curso"):
    conn = conectar()
    cur = conn.execute("""
        INSERT INTO campanas (nombre, fecha_creacion, estado, ruta_excel, config_json, total_contactos)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (nombre, datetime.now().isoformat(), estado, ruta_excel, json.dumps(config), total_contactos))
    conn.commit()
    campana_id = cur.lastrowid
    conn.close()
    return campana_id


def actualizar_estado_campana(campana_id, estado):
    conn = conectar()
    fecha_fin = datetime.now().isoformat() if estado == "Finalizada" else None
    if fecha_fin:
        conn.execute("UPDATE campanas SET estado = ?, fecha_fin = ? WHERE id = ?",
                     (estado, fecha_fin, campana_id))
    else:
        conn.execute("UPDATE campanas SET estado = ? WHERE id = ?", (estado, campana_id))
    conn.commit()
    conn.close()


def actualizar_config_campana(campana_id, config):
    conn = conectar()
    conn.execute("UPDATE campanas SET config_json = ? WHERE id = ?",
                (json.dumps(config), campana_id))
    conn.commit()
    conn.close()


def obtener_campana(campana_id):
    conn = conectar()
    fila = conn.execute("SELECT * FROM campanas WHERE id = ?", (campana_id,)).fetchone()
    conn.close()
    if not fila:
        return None
    d = dict(fila)
    try:
        d["config"] = json.loads(d["config_json"]) if d["config_json"] else None
    except Exception:
        d["config"] = None
    return d


def listar_campanas_home():
    conn = conectar()
    filas = conn.execute("""
        SELECT c.id, c.nombre, c.fecha_creacion, c.estado, c.total_contactos, c.ruta_excel,
               (SELECT COUNT(*) FROM envios e WHERE e.campana_id = c.id AND e.estado = 'Enviado') AS enviados
        FROM campanas c
        ORDER BY c.fecha_creacion DESC
    """).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def eliminar_campana(campana_id):
    conn = conectar()
    conn.execute("DELETE FROM envios WHERE campana_id = ?", (campana_id,))
    conn.execute("DELETE FROM notas WHERE campana_id = ?", (campana_id,))
    conn.execute("DELETE FROM pasos_campana WHERE campana_id = ?", (campana_id,))
    conn.execute("DELETE FROM recordatorios WHERE campana_id = ?", (campana_id,))
    conn.execute("DELETE FROM campanas WHERE id = ?", (campana_id,))
    conn.commit()
    conn.close()


def registrar_envio(campana_id, campana_nombre, segmento, nombre, numero, empresa, estado, error=""):
    conn = conectar()
    conn.execute("""
        INSERT INTO envios (fecha, campana_id, campana, segmento, nombre, numero, empresa, estado, error)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (datetime.now().isoformat(), campana_id, campana_nombre, segmento, nombre, numero, empresa, estado, error))
    conn.commit()
    conn.close()


# =========================
# NOTAS DE SEGUIMIENTO
# =========================
def agregar_nota(campana_id, texto):
    conn = conectar()
    conn.execute("INSERT INTO notas (campana_id, fecha, texto) VALUES (?, ?, ?)",
                (campana_id, datetime.now().isoformat(), texto))
    conn.commit()
    conn.close()


def listar_notas(campana_id):
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM notas WHERE campana_id = ? ORDER BY fecha DESC", (campana_id,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def editar_nota(nota_id, texto):
    conn = conectar()
    conn.execute("UPDATE notas SET texto = ? WHERE id = ?", (texto, nota_id))
    conn.commit()
    conn.close()


def eliminar_nota(nota_id):
    conn = conectar()
    conn.execute("DELETE FROM notas WHERE id = ?", (nota_id,))
    conn.commit()
    conn.close()


# =========================
# CHECKLIST DE PASOS (plantillas de campaña)
# =========================
def crear_pasos(campana_id, titulos):
    """Reemplaza el checklist completo de una campaña por una lista nueva de títulos."""
    conn = conectar()
    conn.execute("DELETE FROM pasos_campana WHERE campana_id = ?", (campana_id,))
    for i, titulo in enumerate(titulos):
        conn.execute(
            "INSERT INTO pasos_campana (campana_id, orden, titulo, completado) VALUES (?, ?, ?, 0)",
            (campana_id, i, titulo)
        )
    conn.commit()
    conn.close()


def agregar_paso(campana_id, titulo):
    conn = conectar()
    fila = conn.execute(
        "SELECT COALESCE(MAX(orden), -1) + 1 FROM pasos_campana WHERE campana_id = ?", (campana_id,)
    ).fetchone()
    siguiente_orden = fila[0]
    conn.execute(
        "INSERT INTO pasos_campana (campana_id, orden, titulo, completado) VALUES (?, ?, ?, 0)",
        (campana_id, siguiente_orden, titulo)
    )
    conn.commit()
    conn.close()


def listar_pasos(campana_id):
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM pasos_campana WHERE campana_id = ? ORDER BY orden ASC", (campana_id,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def marcar_paso(paso_id, completado):
    conn = conectar()
    fecha = datetime.now().isoformat() if completado else None
    conn.execute(
        "UPDATE pasos_campana SET completado = ?, fecha_completado = ? WHERE id = ?",
        (1 if completado else 0, fecha, paso_id)
    )
    conn.commit()
    conn.close()


def eliminar_paso(paso_id):
    conn = conectar()
    conn.execute("DELETE FROM pasos_campana WHERE id = ?", (paso_id,))
    conn.commit()
    conn.close()


def editar_paso(paso_id, nuevo_titulo):
    conn = conectar()
    conn.execute("UPDATE pasos_campana SET titulo = ? WHERE id = ?", (nuevo_titulo, paso_id))
    conn.commit()
    conn.close()


# =========================
# PLANTILLAS DE CAMPAÑA (instaladas localmente desde GitHub)
# =========================
def crear_plantilla_campana(nombre, descripcion, pasos):
    conn = conectar()
    cur = conn.execute(
        "INSERT INTO plantillas_campana (nombre, descripcion, pasos_json, fecha_creacion) VALUES (?, ?, ?, ?)",
        (nombre, descripcion, json.dumps(pasos), datetime.now().isoformat())
    )
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return pid


def listar_plantillas_campana():
    conn = conectar()
    filas = conn.execute("SELECT * FROM plantillas_campana ORDER BY nombre ASC").fetchall()
    conn.close()
    resultado = []
    for f in filas:
        d = dict(f)
        try:
            d["pasos"] = json.loads(d["pasos_json"])
        except Exception:
            d["pasos"] = []
        resultado.append(d)
    return resultado


def obtener_plantilla_campana(plantilla_id):
    conn = conectar()
    fila = conn.execute("SELECT * FROM plantillas_campana WHERE id = ?", (plantilla_id,)).fetchone()
    conn.close()
    if not fila:
        return None
    d = dict(fila)
    try:
        d["pasos"] = json.loads(d["pasos_json"])
    except Exception:
        d["pasos"] = []
    return d


# =========================
# RECORDATORIOS
# =========================
def crear_recordatorio(campana_id, texto, fecha_hora):
    conn = conectar()
    conn.execute(
        "INSERT INTO recordatorios (campana_id, texto, fecha_hora, disparado) VALUES (?, ?, ?, 0)",
        (campana_id, texto, fecha_hora)
    )
    conn.commit()
    conn.close()


def listar_recordatorios(campana_id):
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM recordatorios WHERE campana_id = ? ORDER BY fecha_hora ASC", (campana_id,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def editar_recordatorio(recordatorio_id, texto, fecha_hora):
    """Al editar, si ya se había disparado, se reactiva (vuelve a avisar
    en la nueva fecha) -- tiene más sentido que dejarlo marcado como
    'ya avisado' con una fecha distinta a la que realmente se avisó."""
    conn = conectar()
    conn.execute(
        "UPDATE recordatorios SET texto = ?, fecha_hora = ?, disparado = 0, visto = 0 WHERE id = ?",
        (texto, fecha_hora, recordatorio_id)
    )
    conn.commit()
    conn.close()


def eliminar_recordatorio(recordatorio_id):
    conn = conectar()
    conn.execute("DELETE FROM recordatorios WHERE id = ?", (recordatorio_id,))
    conn.commit()
    conn.close()


def recordatorios_pendientes_de_disparar():
    """Recordatorios cuya fecha/hora ya llegó y todavía no se avisaron."""
    conn = conectar()
    ahora = datetime.now().isoformat()
    filas = conn.execute("""
        SELECT r.*, c.nombre AS campana_nombre
        FROM recordatorios r
        JOIN campanas c ON c.id = r.campana_id
        WHERE r.disparado = 0 AND r.fecha_hora <= ?
        ORDER BY r.fecha_hora ASC
    """, (ahora,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def marcar_recordatorio_disparado(recordatorio_id):
    conn = conectar()
    conn.execute("UPDATE recordatorios SET disparado = 1 WHERE id = ?", (recordatorio_id,))
    conn.commit()
    conn.close()


def recordatorios_pendientes_visualizacion():
    """Recordatorios que YA se avisaron (sonó la notificación) pero el
    usuario todavía no los ha marcado como vistos -- para mostrarlos en
    el Inicio hasta que se atiendan."""
    conn = conectar()
    filas = conn.execute("""
        SELECT r.*, c.nombre AS campana_nombre
        FROM recordatorios r
        JOIN campanas c ON c.id = r.campana_id
        WHERE r.disparado = 1 AND r.visto = 0
        ORDER BY r.fecha_hora ASC
    """).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def marcar_recordatorio_visto(recordatorio_id):
    conn = conectar()
    conn.execute("UPDATE recordatorios SET visto = 1 WHERE id = ?", (recordatorio_id,))
    conn.commit()
    conn.close()


# =========================
# PLANTILLAS
# =========================
def crear_plantilla(nombre, contenido):
    conn = conectar()
    cur = conn.execute(
        "INSERT INTO plantillas (nombre, contenido, fecha_creacion) VALUES (?, ?, ?)",
        (nombre, contenido, datetime.now().isoformat())
    )
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return pid


def listar_plantillas():
    conn = conectar()
    filas = conn.execute("SELECT * FROM plantillas ORDER BY nombre ASC").fetchall()
    conn.close()
    return [dict(f) for f in filas]


def eliminar_plantilla(plantilla_id):
    conn = conectar()
    conn.execute("DELETE FROM plantillas WHERE id = ?", (plantilla_id,))
    conn.commit()
    conn.close()


def actualizar_plantilla(plantilla_id, nombre, contenido):
    conn = conectar()
    conn.execute(
        "UPDATE plantillas SET nombre = ?, contenido = ? WHERE id = ?",
        (nombre, contenido, plantilla_id)
    )
    conn.commit()
    conn.close()


# =========================
# DASHBOARD
# =========================
def stats_mes(anio_mes=None):
    """anio_mes en formato 'YYYY-MM'. Si es None, usa el mes actual."""
    mes = anio_mes or datetime.now().strftime("%Y-%m")
    conn = conectar()

    total_enviados = conn.execute(
        "SELECT COUNT(*) FROM envios WHERE estado='Enviado' AND strftime('%Y-%m', fecha) = ?",
        (mes,)
    ).fetchone()[0]

    total_intentos = conn.execute(
        "SELECT COUNT(*) FROM envios WHERE strftime('%Y-%m', fecha) = ?",
        (mes,)
    ).fetchone()[0]

    campanas_activas = conn.execute(
        "SELECT COUNT(*) FROM campanas WHERE estado IN ('En curso', 'Pausada')"
    ).fetchone()[0]

    contactos_totales = conn.execute(
        "SELECT COUNT(DISTINCT numero) FROM envios WHERE estado='Enviado'"
    ).fetchone()[0]

    conn.close()

    tasa = round((total_enviados / total_intentos) * 100, 1) if total_intentos else 0.0

    return {
        "mes": mes,
        "total_enviados_mes": total_enviados,
        "tasa_entrega": tasa,
        "campanas_activas": campanas_activas,
        "contactos_totales": contactos_totales,
    }


def meses_con_datos():
    """Lista de meses (YYYY-MM) que tienen al menos un envío registrado,
    del más reciente al más antiguo -- para llenar el selector del
    Dashboard sin mostrar meses vacíos."""
    conn = conectar()
    filas = conn.execute("""
        SELECT DISTINCT strftime('%Y-%m', fecha) AS mes FROM envios ORDER BY mes DESC
    """).fetchall()
    conn.close()
    return [f["mes"] for f in filas]


def historial_mensual(meses=6):
    conn = conectar()
    filas = conn.execute("""
        SELECT strftime('%Y-%m', fecha) AS mes,
               SUM(CASE WHEN estado='Enviado' THEN 1 ELSE 0 END) AS enviados,
               COUNT(*) AS total
        FROM envios
        GROUP BY mes
        ORDER BY mes DESC
        LIMIT ?
    """, (meses,)).fetchall()
    conn.close()
    return [dict(f) for f in reversed(filas)]


def top_contactos(limite=10):
    conn = conectar()
    filas = conn.execute("""
        SELECT numero, nombre, COUNT(*) AS total_mensajes,
               MAX(fecha) AS ultimo_envio
        FROM envios
        WHERE estado='Enviado'
        GROUP BY numero
        ORDER BY total_mensajes DESC
        LIMIT ?
    """, (limite,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


# =========================
# REPORTES
# =========================
def obtener_envios(campana_id=None, fecha_desde=None, fecha_hasta=None):
    conn = conectar()
    query = "SELECT * FROM envios WHERE 1=1"
    params = []
    if campana_id:
        query += " AND campana_id = ?"
        params.append(campana_id)
    if fecha_desde:
        query += " AND date(fecha) >= date(?)"
        params.append(fecha_desde)
    if fecha_hasta:
        query += " AND date(fecha) <= date(?)"
        params.append(fecha_hasta)
    query += " ORDER BY fecha ASC"
    filas = conn.execute(query, params).fetchall()
    conn.close()
    return [dict(f) for f in filas]


# =========================
# CONTACTOS (registro permanente, entre campañas)
# =========================
def normalizar_numero(numero):
    """
    Dos números que se ven distintos escritos (con espacios, guiones, o
    en formato local '0987654321' vs internacional '+593987654321') deben
    tratarse como la misma persona. Se comparan solo por sus dígitos, y
    de esos, solo los últimos 9 -- así el '0' inicial del formato local o
    el código de país del internacional no generan un contacto duplicado
    para el mismo número real.
    """
    solo_digitos = re.sub(r"\D", "", str(numero or ""))
    return solo_digitos[-9:] if len(solo_digitos) > 9 else solo_digitos


def upsert_contacto(numero, nombre=""):
    """
    Se llama justo cuando un envío le llega con éxito a alguien. Si es la
    primera vez que se ve ese número, se crea un registro permanente con
    etapa 'Contactado' (ya hubo contacto real). Si ya existía de una
    campaña anterior, se actualiza el nombre más reciente, pero se
    respeta la etapa en la que ya estaba.

    NOTA: ya NO toca el campo "empresa" -- esa columna del Excel es la
    empresa de QUIEN envía el mensaje (para la etiqueta {Empresa} del
    texto), no la empresa del contacto. La empresa real del contacto es
    un dato manual, que se edita desde la ficha (ver
    actualizar_datos_contacto).
    """
    numero_completo = str(numero or "").strip()
    numero = normalizar_numero(numero)
    if not numero:
        return

    conn = conectar()
    ahora = datetime.now().isoformat()
    existente = conn.execute("SELECT id FROM contactos WHERE numero = ?", (numero,)).fetchone()

    if existente:
        conn.execute(
            "UPDATE contactos SET nombre = ?, numero_completo = ?, fecha_ultima_actividad = ? WHERE numero = ?",
            (nombre, numero_completo, ahora, numero)
        )
    else:
        conn.execute(
            "INSERT INTO contactos (numero, numero_completo, nombre, empresa, etapa, fecha_primera_vez, fecha_ultima_actividad) "
            "VALUES (?, ?, ?, '', 'Contactado', ?, ?)",
            (numero, numero_completo, nombre, ahora, ahora)
        )
    conn.commit()
    conn.close()


def actualizar_datos_contacto(numero, empresa=None, correo=None, direccion=None, ciudad=None):
    """Campos editables a mano desde la ficha -- solo actualiza los que
    vengan con valor (no None), para poder llamarla con uno solo a la vez."""
    numero = normalizar_numero(numero)
    conn = conectar()
    campos, valores = [], []
    for campo, valor in [("empresa", empresa), ("correo", correo), ("direccion", direccion), ("ciudad", ciudad)]:
        if valor is not None:
            campos.append(f"{campo} = ?")
            valores.append(valor)
    if campos:
        valores.append(numero)
        conn.execute(f"UPDATE contactos SET {', '.join(campos)} WHERE numero = ?", valores)
        conn.commit()
    conn.close()


def listar_contactos():
    conn = conectar()
    filas = conn.execute("SELECT * FROM contactos ORDER BY fecha_ultima_actividad DESC").fetchall()
    conn.close()
    return [dict(f) for f in filas]


def obtener_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    fila = conn.execute("SELECT * FROM contactos WHERE numero = ?", (numero,)).fetchone()
    conn.close()
    return dict(fila) if fila else None


def actualizar_etapa_contacto(numero, etapa):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "UPDATE contactos SET etapa = ?, fecha_ultima_actividad = ? WHERE numero = ?",
        (etapa, datetime.now().isoformat(), numero)
    )
    conn.commit()
    conn.close()


def contactos_resumen():
    """Cuántos contactos hay en cada etapa -- lo que va a alimentar el
    tablero del Kanban en la siguiente fase, y por ahora sirve para
    confirmar que el registro se está llenando bien."""
    conn = conectar()
    filas = conn.execute("SELECT etapa, COUNT(*) AS total FROM contactos GROUP BY etapa").fetchall()
    conn.close()
    resumen = {"Prospecto": 0, "Contactado": 0, "Interesado": 0, "Cliente": 0, "Perdido": 0}
    for f in filas:
        resumen[f["etapa"]] = f["total"]
    resumen["total"] = sum(resumen.values())
    return resumen


# =========================
# NOTAS POR CONTACTO (bitácora de la persona, no de una campaña)
# =========================
def agregar_nota_contacto(numero, texto):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "INSERT INTO notas_contacto (numero, fecha, texto) VALUES (?, ?, ?)",
        (numero, datetime.now().isoformat(), texto)
    )
    conn.commit()
    conn.close()


def listar_notas_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM notas_contacto WHERE numero = ? ORDER BY fecha DESC", (numero,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def editar_nota_contacto(nota_id, texto):
    conn = conectar()
    conn.execute("UPDATE notas_contacto SET texto = ? WHERE id = ?", (texto, nota_id))
    conn.commit()
    conn.close()


def eliminar_nota_contacto(nota_id):
    conn = conectar()
    conn.execute("DELETE FROM notas_contacto WHERE id = ?", (nota_id,))
    conn.commit()
    conn.close()


# =========================
# ETIQUETAS (reutilizables, mismo patrón que las plantillas de mensaje)
# =========================
def listar_etiquetas():
    conn = conectar()
    filas = conn.execute("SELECT * FROM etiquetas ORDER BY nombre ASC").fetchall()
    conn.close()
    return [dict(f) for f in filas]


def etiquetas_de_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute("""
        SELECT e.id, e.nombre FROM etiquetas e
        JOIN contacto_etiquetas ce ON ce.etiqueta_id = e.id
        WHERE ce.numero = ?
        ORDER BY e.nombre ASC
    """, (numero,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def agregar_etiqueta_a_contacto(numero, nombre_etiqueta):
    numero = normalizar_numero(numero)
    nombre_etiqueta = nombre_etiqueta.strip()
    conn = conectar()

    fila = conn.execute("SELECT id FROM etiquetas WHERE nombre = ?", (nombre_etiqueta,)).fetchone()
    if fila:
        etiqueta_id = fila["id"]
    else:
        cur = conn.execute("INSERT INTO etiquetas (nombre) VALUES (?)", (nombre_etiqueta,))
        etiqueta_id = cur.lastrowid

    conn.execute(
        "INSERT OR IGNORE INTO contacto_etiquetas (numero, etiqueta_id) VALUES (?, ?)",
        (numero, etiqueta_id)
    )
    conn.commit()
    conn.close()
    return etiqueta_id


def quitar_etiqueta_de_contacto(numero, etiqueta_id):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "DELETE FROM contacto_etiquetas WHERE numero = ? AND etiqueta_id = ?",
        (numero, etiqueta_id)
    )
    conn.commit()
    conn.close()


def numeros_de_campana(campana_id):
    """Números (normalizados) de los contactos que recibieron algo en
    esa campaña -- para filtrar el tablero de Seguimiento por campaña."""
    conn = conectar()
    filas = conn.execute(
        "SELECT DISTINCT numero FROM envios WHERE campana_id = ? AND estado = 'Enviado'",
        (campana_id,)
    ).fetchall()
    conn.close()
    return [normalizar_numero(f["numero"]) for f in filas]


# =========================
# COLUMNAS DE KANBAN (editables, POR CAMPAÑA)
# =========================
COLUMNAS_DEFAULT = ["Prospecto", "Contactado", "Interesado", "Cliente", "Perdido"]


def asegurar_columnas_default(campana_id):
    """La primera vez que una campaña necesita su tablero, se le crea un
    juego de columnas de partida -- editable libremente después, no es
    una plantilla fija."""
    conn = conectar()
    existen = conn.execute(
        "SELECT COUNT(*) FROM columnas_kanban WHERE campana_id = ?", (campana_id,)
    ).fetchone()[0]
    if existen == 0:
        for i, nombre in enumerate(COLUMNAS_DEFAULT, start=1):
            conn.execute(
                "INSERT INTO columnas_kanban (campana_id, nombre, orden) VALUES (?, ?, ?)",
                (campana_id, nombre, i)
            )
        conn.commit()
    conn.close()


def columnas_de_campana(campana_id):
    asegurar_columnas_default(campana_id)
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM columnas_kanban WHERE campana_id = ? ORDER BY orden ASC", (campana_id,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def agregar_columna(campana_id, nombre):
    asegurar_columnas_default(campana_id)
    conn = conectar()
    maximo = conn.execute(
        "SELECT COALESCE(MAX(orden), 0) FROM columnas_kanban WHERE campana_id = ?", (campana_id,)
    ).fetchone()[0]
    cur = conn.execute(
        "INSERT INTO columnas_kanban (campana_id, nombre, orden) VALUES (?, ?, ?)",
        (campana_id, nombre, maximo + 1)
    )
    conn.commit()
    columna_id = cur.lastrowid
    conn.close()
    return columna_id


def editar_columna(columna_id, nombre):
    conn = conectar()
    conn.execute("UPDATE columnas_kanban SET nombre = ? WHERE id = ?", (nombre, columna_id))
    conn.commit()
    conn.close()


def contactos_en_columna(columna_id):
    conn = conectar()
    total = conn.execute(
        "SELECT COUNT(*) FROM contacto_campana_columna WHERE columna_id = ?", (columna_id,)
    ).fetchone()[0]
    conn.close()
    return total


def eliminar_columna(columna_id):
    conn = conectar()
    conn.execute("DELETE FROM columnas_kanban WHERE id = ?", (columna_id,))
    conn.commit()
    conn.close()


# =========================
# POSICIÓN DEL CONTACTO EN EL TABLERO DE CADA CAMPAÑA
# =========================
def asignar_contacto_a_columna(campana_id, numero, columna_id):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute("""
        INSERT INTO contacto_campana_columna (campana_id, numero, columna_id, fecha_actualizacion)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(campana_id, numero) DO UPDATE SET
            columna_id = excluded.columna_id,
            fecha_actualizacion = excluded.fecha_actualizacion
    """, (campana_id, numero, columna_id, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def asegurar_contacto_en_tablero(campana_id, numero):
    """Se llama justo cuando un envío llega con éxito. Si el contacto
    todavía no tiene posición en el tablero DE ESTA campaña, se le
    asigna la segunda columna (la de "ya se le escribió") -- sin asumir
    cómo se llama, porque ahora son editables."""
    numero = normalizar_numero(numero)
    columnas = columnas_de_campana(campana_id)
    if not columnas:
        return

    conn = conectar()
    existente = conn.execute(
        "SELECT 1 FROM contacto_campana_columna WHERE campana_id = ? AND numero = ?",
        (campana_id, numero)
    ).fetchone()
    conn.close()
    if existente:
        return

    columna_destino = columnas[1] if len(columnas) > 1 else columnas[0]
    asignar_contacto_a_columna(campana_id, numero, columna_destino["id"])


def contactos_de_campana_agrupados(campana_id):
    """Para pintar el tablero completo de una campaña: sus columnas, y
    qué contactos hay en cada una -- ya con etiquetas, la próxima tarea
    pendiente y la última observación incluidas, para que la tarjeta se
    pinte de un vistazo sin tener que pedir esos datos aparte, uno por uno."""
    columnas = columnas_de_campana(campana_id)
    conn = conectar()
    filas = conn.execute("""
        SELECT ccc.columna_id, c.numero, c.numero_completo, c.nombre, c.empresa, c.fecha_ultima_actividad
        FROM contacto_campana_columna ccc
        JOIN contactos c ON c.numero = ccc.numero
        WHERE ccc.campana_id = ?
    """, (campana_id,)).fetchall()
    conn.close()

    por_columna = {col["id"]: [] for col in columnas}
    for f in filas:
        if f["columna_id"] not in por_columna:
            continue
        contacto = dict(f)
        contacto["etiquetas"] = [e["nombre"] for e in etiquetas_de_contacto(f["numero"])]
        contacto["tareas"] = listar_tareas_contacto(f["numero"])

        notas = listar_notas_contacto(f["numero"])
        contacto["ultima_observacion"] = notas[0]["texto"] if notas else None

        contacto["salud"] = calcular_salud_contacto(
            f["fecha_ultima_actividad"], contacto["tareas"], contacto["etiquetas"]
        )
        contacto["producto_favorito"] = producto_favorito_contacto(f["numero"])

        por_columna[f["columna_id"]].append(contacto)

    return {"columnas": columnas, "por_columna": por_columna}


def campanas_de_contacto(numero):
    """En qué campañas ha aparecido este contacto, y en qué columna está
    en cada una -- esto es lo que evita que se duplique la ficha: la
    persona es una sola, pero puede tener una posición distinta en el
    tablero de cada campaña."""
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute("""
        SELECT e.campana_id, e.numero, e.estado, e.fecha, cmp.nombre AS campana_nombre
        FROM envios e
        JOIN campanas cmp ON cmp.id = e.campana_id
        ORDER BY e.fecha DESC
    """).fetchall()

    vistos = set()
    resultado = []
    for f in filas:
        if normalizar_numero(f["numero"]) != numero:
            continue
        if f["campana_id"] in vistos:
            continue
        vistos.add(f["campana_id"])

        fila_col = conn.execute("""
            SELECT ck.nombre FROM contacto_campana_columna ccc
            JOIN columnas_kanban ck ON ck.id = ccc.columna_id
            WHERE ccc.campana_id = ? AND ccc.numero = ?
        """, (f["campana_id"], numero)).fetchone()

        resultado.append({
            "campana_id": f["campana_id"],
            "campana_nombre": f["campana_nombre"],
            "estado_envio": f["estado"],
            "fecha": f["fecha"],
            "columna": fila_col["nombre"] if fila_col else None,
        })
    conn.close()
    return resultado


# =========================
# TAREAS POR CONTACTO (checklist, distinto de las observaciones libres)
# =========================
def agregar_tarea_contacto(numero, titulo):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "INSERT INTO tareas_contacto (numero, titulo, completado, fecha_creacion) VALUES (?, ?, 0, ?)",
        (numero, titulo, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()


def listar_tareas_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM tareas_contacto WHERE numero = ? ORDER BY completado ASC, fecha_creacion ASC",
        (numero,)
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def editar_tarea_contacto(tarea_id, titulo):
    conn = conectar()
    conn.execute("UPDATE tareas_contacto SET titulo = ? WHERE id = ?", (titulo, tarea_id))
    conn.commit()
    conn.close()


def marcar_tarea_contacto(tarea_id, completado):
    conn = conectar()
    fecha_completado = datetime.now().isoformat() if completado else None
    conn.execute(
        "UPDATE tareas_contacto SET completado = ?, fecha_completado = ? WHERE id = ?",
        (1 if completado else 0, fecha_completado, tarea_id)
    )
    conn.commit()
    conn.close()


def eliminar_tarea_contacto(tarea_id):
    conn = conectar()
    conn.execute("DELETE FROM tareas_contacto WHERE id = ?", (tarea_id,))
    conn.commit()
    conn.close()


def proxima_tarea_pendiente(numero):
    """Para la vista previa en la tarjeta del Kanban -- la tarea más
    antigua todavía sin completar."""
    numero = normalizar_numero(numero)
    conn = conectar()
    fila = conn.execute(
        "SELECT * FROM tareas_contacto WHERE numero = ? AND completado = 0 ORDER BY fecha_creacion ASC LIMIT 1",
        (numero,)
    ).fetchone()
    conn.close()
    return dict(fila) if fila else None


# =========================
# PANTALLA DE INICIO DE SEGUIMIENTO
# =========================
def resumen_general_seguimiento():
    conn = conectar()
    campanas_ejecutadas = conn.execute("SELECT COUNT(*) FROM campanas").fetchone()[0]
    contactos_totales = conn.execute("SELECT COUNT(*) FROM contactos").fetchone()[0]
    mensajes_enviados = conn.execute("SELECT COUNT(*) FROM envios WHERE estado = 'Enviado'").fetchone()[0]
    hace_30_dias = (datetime.now() - timedelta(days=30)).isoformat()
    contactos_activos = conn.execute(
        "SELECT COUNT(*) FROM contactos WHERE fecha_ultima_actividad >= ?", (hace_30_dias,)
    ).fetchone()[0]
    conn.close()
    return {
        "campanas_ejecutadas": campanas_ejecutadas,
        "contactos_totales": contactos_totales,
        "mensajes_enviados": mensajes_enviados,
        "contactos_activos": contactos_activos,
    }


def ultima_actividad_kanban():
    """El movimiento más reciente entre columnas, de cualquier campaña
    -- para el destacado de "esto está vivo" en la pantalla de inicio."""
    conn = conectar()
    fila = conn.execute("""
        SELECT ccc.numero, ccc.fecha_actualizacion, ck.nombre AS columna_nombre,
               cmp.nombre AS campana_nombre, c.nombre AS contacto_nombre
        FROM contacto_campana_columna ccc
        JOIN columnas_kanban ck ON ck.id = ccc.columna_id
        JOIN campanas cmp ON cmp.id = ccc.campana_id
        JOIN contactos c ON c.numero = ccc.numero
        ORDER BY ccc.fecha_actualizacion DESC
        LIMIT 1
    """).fetchone()
    conn.close()
    return dict(fila) if fila else None


def resumen_por_campana():
    """Para las tarjetas de campaña estilo Trello -- cuántos contactos
    tiene cada una y cómo se reparten en sus columnas."""
    conn = conectar()
    campanas = conn.execute(
        "SELECT id, nombre, fecha_creacion FROM campanas ORDER BY fecha_creacion DESC"
    ).fetchall()

    resultado = []
    for c in campanas:
        columnas = columnas_de_campana(c["id"])
        distribucion = []
        total = 0
        for col in columnas:
            n = conn.execute(
                "SELECT COUNT(*) FROM contacto_campana_columna WHERE campana_id = ? AND columna_id = ?",
                (c["id"], col["id"])
            ).fetchone()[0]
            distribucion.append({"columna": col["nombre"], "total": n})
            total += n

        ultima = conn.execute(
            "SELECT MAX(fecha_actualizacion) AS f FROM contacto_campana_columna WHERE campana_id = ?",
            (c["id"],)
        ).fetchone()

        resultado.append({
            "id": c["id"],
            "nombre": c["nombre"],
            "total_contactos": total,
            "distribucion": distribucion,
            "ultima_actividad": ultima["f"] if ultima else None,
        })
    conn.close()
    return resultado


def contactos_de_columna(columna_id):
    """Todos los datos de los contactos de una columna específica --
    para exportar a Excel o para armar una campaña nueva con ellos."""
    conn = conectar()
    filas = conn.execute("""
        SELECT c.* FROM contacto_campana_columna ccc
        JOIN contactos c ON c.numero = ccc.numero
        WHERE ccc.columna_id = ?
    """, (columna_id,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


# =========================
# CATÁLOGOS REUTILIZABLES (productos/servicios y motivos de queja)
# =========================
def _sugerir_similar(nombre_nuevo, nombres_existentes, umbral=0.82):
    """Compara el nombre nuevo contra el catálogo ya existente y sugiere
    el más parecido si supera el umbral de similitud -- para detectar
    cosas como 'aceite motor' vs 'Aceite de Motor' sin usar IA, solo
    comparación de texto (difflib, ya viene con Python)."""
    import difflib
    nombre_normalizado = nombre_nuevo.strip().lower()
    mejor_puntaje = 0
    mejor_match = None
    for existente in nombres_existentes:
        puntaje = difflib.SequenceMatcher(None, nombre_normalizado, existente.strip().lower()).ratio()
        if puntaje > mejor_puntaje:
            mejor_puntaje = puntaje
            mejor_match = existente
    if mejor_puntaje >= umbral and mejor_match.strip().lower() != nombre_normalizado:
        return mejor_match
    return None


def listar_catalogo_productos():
    conn = conectar()
    filas = conn.execute("SELECT * FROM catalogo_productos ORDER BY nombre ASC").fetchall()
    conn.close()
    return [dict(f) for f in filas]


def sugerir_producto_similar(nombre_nuevo):
    existentes = [p["nombre"] for p in listar_catalogo_productos()]
    return _sugerir_similar(nombre_nuevo, existentes)


def agregar_producto_catalogo(nombre):
    nombre = nombre.strip()
    conn = conectar()
    fila = conn.execute("SELECT id FROM catalogo_productos WHERE nombre = ?", (nombre,)).fetchone()
    if fila:
        conn.close()
        return fila["id"]
    cur = conn.execute("INSERT INTO catalogo_productos (nombre) VALUES (?)", (nombre,))
    conn.commit()
    producto_id = cur.lastrowid
    conn.close()
    return producto_id


def listar_catalogo_quejas():
    conn = conectar()
    filas = conn.execute("SELECT * FROM catalogo_quejas ORDER BY nombre ASC").fetchall()
    conn.close()
    return [dict(f) for f in filas]


def sugerir_motivo_queja_similar(nombre_nuevo):
    existentes = [m["nombre"] for m in listar_catalogo_quejas()]
    return _sugerir_similar(nombre_nuevo, existentes)


def agregar_motivo_queja_catalogo(nombre):
    nombre = nombre.strip()
    conn = conectar()
    fila = conn.execute("SELECT id FROM catalogo_quejas WHERE nombre = ?", (nombre,)).fetchone()
    if fila:
        conn.close()
        return fila["id"]
    cur = conn.execute("INSERT INTO catalogo_quejas (nombre) VALUES (?)", (nombre,))
    conn.commit()
    motivo_id = cur.lastrowid
    conn.close()
    return motivo_id


# =========================
# VENTAS Y QUEJAS POR CONTACTO
# =========================
def registrar_venta_contacto(numero, producto_id):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "INSERT INTO ventas_contacto (numero, producto_id, fecha) VALUES (?, ?, ?)",
        (numero, producto_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()


def listar_ventas_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute("""
        SELECT v.id, v.fecha, p.nombre AS producto
        FROM ventas_contacto v
        JOIN catalogo_productos p ON p.id = v.producto_id
        WHERE v.numero = ?
        ORDER BY v.fecha DESC
    """, (numero,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def eliminar_venta_contacto(venta_id):
    conn = conectar()
    conn.execute("DELETE FROM ventas_contacto WHERE id = ?", (venta_id,))
    conn.commit()
    conn.close()


def registrar_queja_contacto(numero, motivo_id):
    numero = normalizar_numero(numero)
    conn = conectar()
    conn.execute(
        "INSERT INTO quejas_contacto (numero, motivo_id, fecha) VALUES (?, ?, ?)",
        (numero, motivo_id, datetime.now().isoformat())
    )
    conn.commit()
    conn.close()


def listar_quejas_contacto(numero):
    numero = normalizar_numero(numero)
    conn = conectar()
    filas = conn.execute("""
        SELECT q.id, q.fecha, m.nombre AS motivo
        FROM quejas_contacto q
        JOIN catalogo_quejas m ON m.id = q.motivo_id
        WHERE q.numero = ?
        ORDER BY q.fecha DESC
    """, (numero,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def eliminar_queja_contacto(queja_id):
    conn = conectar()
    conn.execute("DELETE FROM quejas_contacto WHERE id = ?", (queja_id,))
    conn.commit()
    conn.close()


def producto_favorito_contacto(numero):
    """Si un contacto acumuló 3 o más compras del mismo producto, ese es
    su favorito -- se muestra solo, sin que nadie lo marque a mano."""
    numero = normalizar_numero(numero)
    conn = conectar()
    fila = conn.execute("""
        SELECT p.nombre, COUNT(*) AS total
        FROM ventas_contacto v
        JOIN catalogo_productos p ON p.id = v.producto_id
        WHERE v.numero = ?
        GROUP BY v.producto_id
        ORDER BY total DESC
        LIMIT 1
    """, (numero,)).fetchone()
    conn.close()
    if fila and fila["total"] >= 3:
        return {"producto": fila["nombre"], "veces": fila["total"]}
    return None


# =========================
# INTELIGENCIA COMERCIAL (Dashboard)
# =========================
def producto_mas_vendido():
    """Por UNIDAD DE VENTA -- cada venta cuenta, sin importar si fue al
    mismo contacto varias veces o a contactos distintos."""
    conn = conectar()
    fila = conn.execute("""
        SELECT p.nombre, COUNT(*) AS total
        FROM ventas_contacto v
        JOIN catalogo_productos p ON p.id = v.producto_id
        GROUP BY v.producto_id
        ORDER BY total DESC
        LIMIT 1
    """).fetchone()
    conn.close()
    return dict(fila) if fila else None


def motivo_queja_mas_comun():
    conn = conectar()
    fila = conn.execute("""
        SELECT m.nombre, COUNT(*) AS total
        FROM quejas_contacto q
        JOIN catalogo_quejas m ON m.id = q.motivo_id
        GROUP BY q.motivo_id
        ORDER BY total DESC
        LIMIT 1
    """).fetchone()
    conn.close()
    return dict(fila) if fila else None


def compradores_unicos():
    """Por PERSONA ÚNICA -- mismo número de celular = una sola persona,
    aunque haya comprado en varias campañas o varias veces."""
    conn = conectar()
    total = conn.execute("SELECT COUNT(DISTINCT numero) FROM ventas_contacto").fetchone()[0]
    conn.close()
    return total


# =========================
# AUTOMATIZACIÓN: tarea de reconexión cuando un contacto lleva mucho
# tiempo sin actividad (reutiliza el sistema de tareas ya existente,
# en vez de inventar un sistema de avisos aparte)
# =========================
def generar_tareas_reconexion(dias_umbral=20):
    """
    Revisa todos los contactos y, a los que llevan más de `dias_umbral`
    días sin actividad y todavía no tienen una tarea de reconexión
    pendiente (para no duplicar cada vez que se abre el programa), les
    crea una automáticamente. Se llama una vez al iniciar el programa.
    """
    conn = conectar()
    limite = (datetime.now() - timedelta(days=dias_umbral)).isoformat()
    inactivos = conn.execute(
        "SELECT numero, nombre FROM contactos WHERE fecha_ultima_actividad < ?", (limite,)
    ).fetchall()

    creadas = 0
    for c in inactivos:
        ya_existe = conn.execute("""
            SELECT 1 FROM tareas_contacto
            WHERE numero = ? AND origen = 'auto_reconexion' AND completado = 0
        """, (c["numero"],)).fetchone()
        if ya_existe:
            continue
        titulo = f"Retomar contacto -- lleva más de {dias_umbral} días sin actividad"
        conn.execute(
            "INSERT INTO tareas_contacto (numero, titulo, completado, fecha_creacion, origen) "
            "VALUES (?, ?, 0, ?, 'auto_reconexion')",
            (c["numero"], titulo, datetime.now().isoformat())
        )
        creadas += 1

    conn.commit()
    conn.close()
    return creadas


def calcular_salud_contacto(fecha_ultima_actividad, tareas, etiquetas):
    """
    Semáforo de salud, por reglas simples (sin IA):
    - Rojo: más de 30 días sin actividad.
    - Amarillo: entre 15 y 30 días sin actividad, o tiene una tarea
      pendiente creada hace más de 7 días.
    - Verde: todo lo demás.
    Un contacto VIP con salud "amarilla" sube a "rojo" -- perder a un
    cliente VIP cuesta más, merece más urgencia visual.
    """
    if not fecha_ultima_actividad:
        return "amarillo"

    dias_inactivo = (datetime.now() - datetime.fromisoformat(fecha_ultima_actividad)).days

    tarea_vieja_pendiente = False
    for t in (tareas or []):
        if not t.get("completado") and t.get("fecha_creacion"):
            dias_tarea = (datetime.now() - datetime.fromisoformat(t["fecha_creacion"])).days
            if dias_tarea > 7:
                tarea_vieja_pendiente = True
                break

    if dias_inactivo > 30:
        salud = "rojo"
    elif dias_inactivo >= 15 or tarea_vieja_pendiente:
        salud = "amarillo"
    else:
        salud = "verde"

    if salud == "amarillo" and "VIP" in (etiquetas or []):
        salud = "rojo"

    return salud


# =========================
# CONFIGURACIÓN GENERAL DE LA APP (clave-valor, ej. tema oscuro/claro)
# =========================
def obtener_config(clave, valor_default=None):
    conn = conectar()
    fila = conn.execute("SELECT valor FROM config_app WHERE clave = ?", (clave,)).fetchone()
    conn.close()
    return fila["valor"] if fila else valor_default


def guardar_config(clave, valor):
    conn = conectar()
    conn.execute(
        "INSERT INTO config_app (clave, valor) VALUES (?, ?) "
        "ON CONFLICT(clave) DO UPDATE SET valor = excluded.valor",
        (clave, valor)
    )
    conn.commit()
    conn.close()


# =========================
# SOLICITUDES DE LICENCIA (pantalla de Activación, solo para el dueño)
# =========================
def dias_del_plan(plan):
    if plan == "Trimestral":
        return 90
    if plan == "Prueba":
        return 15
    return 30


def precio_del_plan(plan):
    if plan == "Trimestral":
        return float(obtener_config("precio_trimestral", "38"))
    if plan == "Prueba":
        return 0.0
    return float(obtener_config("precio_mensual", "15"))


def guardar_solicitud_si_nueva(fila_hash, hardware_id, nombres, apellidos, whatsapp,
                                plan, banco, num_transaccion, comprobante_url, fecha_solicitud):
    """Importa una fila del formulario, solo si no se había importado antes
    (para poder leer la hoja de Google una y otra vez sin duplicar)."""
    conn = conectar()
    existe = conn.execute(
        "SELECT id FROM solicitudes_licencia WHERE fila_hash = ?", (fila_hash,)
    ).fetchone()
    if existe:
        conn.close()
        return None

    ya_fue_cliente = conn.execute(
        "SELECT 1 FROM solicitudes_licencia WHERE hardware_id = ? AND codigo_generado IS NOT NULL",
        (hardware_id,)
    ).fetchone()
    es_renovacion = 1 if ya_fue_cliente else 0

    monto = precio_del_plan(plan)

    cur = conn.execute("""
        INSERT INTO solicitudes_licencia
            (fila_hash, hardware_id, nombres, apellidos, whatsapp, plan, banco,
             num_transaccion, comprobante_url, monto_esperado, fecha_solicitud, es_renovacion)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (fila_hash, hardware_id, nombres, apellidos, whatsapp, plan, banco,
          num_transaccion, comprobante_url, monto, fecha_solicitud, es_renovacion))
    conn.commit()
    solicitud_id = cur.lastrowid
    conn.close()
    return solicitud_id


def listar_solicitudes_pendientes():
    """Las que todavía no se han enviado NI rechazado -- para la lista
    principal de "por procesar" en el Home de Activación."""
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM solicitudes_licencia WHERE estado = 'pendiente' ORDER BY fecha_solicitud ASC"
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def listar_solicitudes_rechazadas():
    """Rechazadas que siguen esperando una respuesta/resolución -- se
    muestran aparte en el Home, sin desaparecer del sistema."""
    conn = conectar()
    filas = conn.execute(
        "SELECT * FROM solicitudes_licencia WHERE estado = 'rechazada' ORDER BY fecha_rechazo DESC"
    ).fetchall()
    conn.close()
    return [dict(f) for f in filas]


def rechazar_solicitud(solicitud_id, motivo):
    conn = conectar()
    conn.execute(
        "UPDATE solicitudes_licencia SET estado = 'rechazada', motivo_rechazo = ?, fecha_rechazo = ? WHERE id = ?",
        (motivo, datetime.now().isoformat(), solicitud_id)
    )
    conn.commit()
    conn.close()


def reactivar_solicitud(solicitud_id):
    """Regresa una solicitud rechazada a 'pendiente' (ej. el cliente
    resolvió el problema y quieres volver a evaluarla)."""
    conn = conectar()
    conn.execute(
        "UPDATE solicitudes_licencia SET estado = 'pendiente', motivo_rechazo = NULL, fecha_rechazo = NULL WHERE id = ?",
        (solicitud_id,)
    )
    conn.commit()
    conn.close()


def hay_duplicado_del_mes(hardware_id, solicitud_id):
    """True si el mismo equipo tiene otra solicitud (de cualquier estado)
    dentro del mismo mes calendario que esta -- solo un aviso visual, no
    bloquea nada."""
    conn = conectar()
    fila = conn.execute(
        "SELECT strftime('%Y-%m', fecha_solicitud) AS mes FROM solicitudes_licencia WHERE id = ?",
        (solicitud_id,)
    ).fetchone()
    if not fila or not fila["mes"]:
        conn.close()
        return False
    otras = conn.execute(
        "SELECT COUNT(*) FROM solicitudes_licencia WHERE hardware_id = ? AND id != ? "
        "AND strftime('%Y-%m', fecha_solicitud) = ?",
        (hardware_id, solicitud_id, fila["mes"])
    ).fetchone()[0]
    conn.close()
    return otras > 0


def guardar_codigo_generado(solicitud_id, codigo):
    conn = conectar()
    conn.execute(
        "UPDATE solicitudes_licencia SET codigo_generado = ?, fecha_generado = ? WHERE id = ?",
        (codigo, datetime.now().isoformat(), solicitud_id)
    )
    conn.commit()
    conn.close()


def marcar_solicitudes_enviadas(ids):
    conn = conectar()
    ahora = datetime.now().isoformat()
    for solicitud_id in ids:
        conn.execute(
            "UPDATE solicitudes_licencia SET enviado = 1, estado = 'enviada', fecha_enviado = ? WHERE id = ?",
            (ahora, solicitud_id)
        )
    conn.commit()
    conn.close()


def obtener_solicitud(solicitud_id):
    conn = conectar()
    fila = conn.execute("SELECT * FROM solicitudes_licencia WHERE id = ?", (solicitud_id,)).fetchone()
    conn.close()
    return dict(fila) if fila else None


# ---- Reportes de licencias (Dashboard de Activación) ----
# Nota: el plan "Prueba" (testeo interno, costo $0) se excluye de todas las
# cifras de negocio de abajo (montos, nuevos/renovaciones, activos,
# perdidos, comparativa de planes) para no ensuciar las estadísticas
# reales. Sigue apareciendo normalmente en las listas/tarjetas de
# solicitudes para que puedas darle seguimiento.
def resumen_licencias_mes(anio_mes=None):
    """anio_mes en formato 'YYYY-MM'. Si es None, usa el mes actual."""
    mes = anio_mes or datetime.now().strftime("%Y-%m")
    conn = conectar()

    otorgadas = conn.execute(
        "SELECT COUNT(*) FROM solicitudes_licencia WHERE enviado = 1 AND plan != 'Prueba' "
        "AND strftime('%Y-%m', fecha_enviado) = ?",
        (mes,)
    ).fetchone()[0]

    monto = conn.execute(
        "SELECT COALESCE(SUM(monto_esperado), 0) FROM solicitudes_licencia "
        "WHERE enviado = 1 AND plan != 'Prueba' AND strftime('%Y-%m', fecha_enviado) = ?",
        (mes,)
    ).fetchone()[0]

    nuevos = conn.execute(
        "SELECT COUNT(*) FROM solicitudes_licencia WHERE enviado = 1 AND es_renovacion = 0 "
        "AND plan != 'Prueba' AND strftime('%Y-%m', fecha_enviado) = ?",
        (mes,)
    ).fetchone()[0]

    renovaciones = conn.execute(
        "SELECT COUNT(*) FROM solicitudes_licencia WHERE enviado = 1 AND es_renovacion = 1 "
        "AND plan != 'Prueba' AND strftime('%Y-%m', fecha_enviado) = ?",
        (mes,)
    ).fetchone()[0]

    conn.close()
    return {
        "mes": mes,
        "licencias_otorgadas": otorgadas,
        "monto_total": round(monto, 2),
        "clientes_nuevos": nuevos,
        "renovaciones": renovaciones,
    }


def usuarios_totales_licencias():
    conn = conectar()
    total = conn.execute(
        "SELECT COUNT(DISTINCT hardware_id) FROM solicitudes_licencia WHERE enviado = 1 AND plan != 'Prueba'"
    ).fetchone()[0]
    conn.close()
    return total


def usuarios_activos_licencias():
    """Cuenta equipos cuya última licencia enviada todavía no vence hoy
    (a diferencia de usuarios_totales_licencias, que cuenta el histórico
    completo). El plan "Prueba" no cuenta como usuario activo real."""
    conn = conectar()
    filas = conn.execute("""
        SELECT hardware_id, plan, fecha_generado
        FROM solicitudes_licencia
        WHERE enviado = 1 AND plan != 'Prueba'
        ORDER BY hardware_id, fecha_generado DESC
    """).fetchall()
    conn.close()

    ultima_por_equipo = {}
    for f in filas:
        if f["hardware_id"] not in ultima_por_equipo:
            ultima_por_equipo[f["hardware_id"]] = f

    hoy = datetime.now()
    activos = 0
    for f in ultima_por_equipo.values():
        if not f["fecha_generado"]:
            continue
        vencimiento = datetime.fromisoformat(f["fecha_generado"]) + timedelta(days=dias_del_plan(f["plan"]))
        if hoy <= vencimiento:
            activos += 1
    return activos


def clientes_perdidos(margen_dias=15):
    """Un cliente se considera perdido si su última licencia enviada ya
    venció hace más de `margen_dias` (para no marcarlo como perdido el
    mismo día que vence, dándole un margen natural de renovación)."""
    conn = conectar()
    filas = conn.execute("""
        SELECT hardware_id, plan, fecha_generado
        FROM solicitudes_licencia
        WHERE enviado = 1 AND plan != 'Prueba'
        ORDER BY hardware_id, fecha_generado DESC
    """).fetchall()
    conn.close()

    ultima_por_equipo = {}
    for f in filas:
        if f["hardware_id"] not in ultima_por_equipo:
            ultima_por_equipo[f["hardware_id"]] = f

    hoy = datetime.now()
    perdidos = 0
    for f in ultima_por_equipo.values():
        if not f["fecha_generado"]:
            continue
        vencimiento = datetime.fromisoformat(f["fecha_generado"]) + timedelta(days=dias_del_plan(f["plan"]))
        if (hoy - vencimiento).days > margen_dias:
            perdidos += 1
    return perdidos


def comparativa_planes_licencias():
    """Cuántos clientes activos hay por tipo de plan (mensual vs.
    trimestral), según la última licencia enviada de cada equipo."""
    conn = conectar()
    filas = conn.execute("""
        SELECT hardware_id, plan, fecha_generado
        FROM solicitudes_licencia
        WHERE enviado = 1 AND plan != 'Prueba'
        ORDER BY hardware_id, fecha_generado DESC
    """).fetchall()
    conn.close()

    ultima_por_equipo = {}
    for f in filas:
        if f["hardware_id"] not in ultima_por_equipo:
            ultima_por_equipo[f["hardware_id"]] = f

    hoy = datetime.now()
    conteo = {"Mensual": 0, "Trimestral": 0}
    for f in ultima_por_equipo.values():
        if not f["fecha_generado"]:
            continue
        vencimiento = datetime.fromisoformat(f["fecha_generado"]) + timedelta(days=dias_del_plan(f["plan"]))
        if hoy <= vencimiento:
            conteo[f["plan"]] = conteo.get(f["plan"], 0) + 1
    return conteo


def meses_disponibles_licencias():
    """Meses (YYYY-MM) que tienen al menos una licencia ENVIADA, ordenados
    del más reciente al más antiguo -- para las tarjetas de mes de
    Activación. Se basa en fecha_enviado (cuándo se otorgó de verdad),
    no en fecha_solicitud -- las tarjetas solo muestran casos ya
    resueltos positivamente; pendientes y rechazadas se quedan en el
    Home hasta que se procesen."""
    conn = conectar()
    filas = conn.execute("""
        SELECT DISTINCT strftime('%Y-%m', fecha_enviado) AS mes
        FROM solicitudes_licencia
        WHERE estado = 'enviada' AND fecha_enviado IS NOT NULL
        ORDER BY mes DESC
    """).fetchall()
    conn.close()
    return [f["mes"] for f in filas if f["mes"]]


def _con_total_licencias_cliente(conn, filas):
    resultado = []
    for f in filas:
        d = dict(f)
        d["total_licencias_cliente"] = conn.execute(
            "SELECT COUNT(*) FROM solicitudes_licencia WHERE hardware_id = ? AND enviado = 1 AND plan != 'Prueba'",
            (d["hardware_id"],)
        ).fetchone()[0]
        resultado.append(d)
    return resultado


def solicitudes_del_mes(anio_mes):
    """Todas las licencias ENVIADAS de un mes -- el contenido de la
    tarjeta de ese mes al abrirla. Agrupadas por fecha_enviado."""
    conn = conectar()
    filas = conn.execute("""
        SELECT * FROM solicitudes_licencia
        WHERE estado = 'enviada' AND strftime('%Y-%m', fecha_enviado) = ?
        ORDER BY fecha_enviado ASC
    """, (anio_mes,)).fetchall()
    resultado = _con_total_licencias_cliente(conn, filas)
    conn.close()
    return resultado


def solicitudes_rango_meses(mes_inicio, mes_fin):
    """Todas las licencias ENVIADAS entre dos meses (inclusive), para la
    descarga de un rango elegido libremente desde el Home (ej. enero a
    marzo) -- pensado para análisis y objetivos, no solo el mes actual."""
    conn = conectar()
    filas = conn.execute("""
        SELECT * FROM solicitudes_licencia
        WHERE estado = 'enviada'
          AND strftime('%Y-%m', fecha_enviado) BETWEEN ? AND ?
        ORDER BY fecha_enviado ASC
    """, (mes_inicio, mes_fin)).fetchall()
    resultado = _con_total_licencias_cliente(conn, filas)
    conn.close()
    return resultado


def historial_mensual_licencias(meses=6):
    conn = conectar()
    filas = conn.execute("""
        SELECT strftime('%Y-%m', fecha_enviado) AS mes,
               COUNT(*) AS otorgadas,
               COALESCE(SUM(monto_esperado), 0) AS monto
        FROM solicitudes_licencia
        WHERE enviado = 1 AND plan != 'Prueba'
        GROUP BY mes
        ORDER BY mes DESC
        LIMIT ?
    """, (meses,)).fetchall()
    conn.close()
    return [dict(f) for f in filas]
