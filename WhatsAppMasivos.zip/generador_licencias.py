"""
generador_licencias.py

*** ESTA HERRAMIENTA ES SOLO PARA TI (David) ***
NO la incluyas en el instalador que le entregas a tus clientes. Vive
aparte, en tu propia PC, junto al archivo licencias.py (la necesita para
firmar los códigos con la misma clave que el programa cliente usa para
verificarlos).

Cómo funciona el flujo completo:
  1. Tu cliente instala el programa y ve la pantalla de activación.
  2. Ahí le aparece su "código de equipo" (hardware_id) con un botón para
     copiarlo -- te lo manda por WhatsApp o correo.
  3. Tú corres este script, pegas ese código de equipo, indicas cuántos
     días de licencia le vendiste, y te genera el código de activación.
  4. Se lo mandas de vuelta, él lo pega en el programa, y queda activado
     por esa cantidad de días.

Uso:
    python generador_licencias.py
"""

import licencias


def main():
    print("=" * 60)
    print("  GENERADOR DE LICENCIAS - WhatsApp Masivos")
    print("=" * 60)
    print()
    print("(Este código NUNCA se comparte con clientes, es solo tuyo)")
    print()

    while True:
        print("-" * 60)
        cliente = input("Nombre del cliente (solo para tu referencia): ").strip()

        hw_id_cliente = input("Código de equipo que te mandó el cliente: ").strip()
        if not hw_id_cliente:
            print("⚠ El código de equipo no puede estar vacío.\n")
            continue

        dias_str = input("¿Cuántos días de licencia le vendes? (ej. 30): ").strip()
        try:
            dias = int(dias_str)
            if dias <= 0:
                raise ValueError
        except ValueError:
            print("⚠ Escribe un número de días válido (ej. 30, 90, 365).\n")
            continue

        codigo = licencias.generar_codigo(hw_id_cliente, dias)

        print()
        print("✅ Código de activación generado:")
        print()
        print(f"   {codigo}")
        print()
        print(f"   Cliente: {cliente or '(sin nombre)'}")
        print(f"   Días: {dias}")
        print()
        print("Copia el código de arriba y mándaselo a tu cliente.")
        print()

        otra = input("¿Generar otro código? (s/n): ").strip().lower()
        if otra != "s":
            break

    print("\nListo. Hasta la próxima.")


if __name__ == "__main__":
    main()
