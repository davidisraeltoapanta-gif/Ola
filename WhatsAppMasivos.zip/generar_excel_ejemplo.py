"""Genera un Excel de ejemplo con el formato correcto para pruebas de la v3."""
import pandas as pd

data = {
    "Numero":  [1, 2, 3, 4],
    "Nombre":  ["Juan Pérez", "María López", "Carlos Ruiz", "Ana Torres"],
    "Celular": ["593999999999", "593988888888", "593977777777", "593966666666"],
    "Empresa": ["Ferretería Central", "Panadería Ana", "Taller Ruiz", "Boutique Torres"],
    "Contacto": ["0999999999", "0988888888", "0977777777", "0966666666"],
}

df = pd.DataFrame(data)
df.to_excel("contactos_ejemplo.xlsx", index=False)
print("Generado: contactos_ejemplo.xlsx")
print("Sugerencia de segmentos para probar: Segmento A = Numero 1-2, Segmento B = Numero 3-4")
