#define MyAppName "Ola"
#define MyAppVersion "5.0.0"
#define MyAppPublisher "Ola Digital"
#define MyAppExeName "WhatsAppMasivos.exe"

[Setup]
AppId={{B6E6C7B0-8B2A-4B7E-9C7A-WHATSMASIVOSV3}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=installer_output
OutputBaseFilename=Ola_Setup
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
SetupIconFile=build_assets\ola.ico
; ---- Marca del instalador: imagen lateral morada + ícono superior,
; con los mismos colores del ícono de la app (ver build_assets\ola.ico).
WizardImageFile=build_assets\ola_wizard_large.bmp
WizardSmallImageFile=build_assets\ola_wizard_small.bmp
WizardImageStretch=no
WizardStyle=modern
; ---- Mensaje de bienvenida (antes de instalar) y de despedida (antes
; de abrir el programa, al terminar) -- texto plano, se ve dentro de
; una pantalla propia del asistente.
InfoBeforeFile=build_assets\bienvenida.txt
InfoAfterFile=build_assets\final.txt

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "Crear acceso directo en el Escritorio"; GroupDescription: "Accesos directos:"

[Files]
; build.bat ahora compila en modo --onedir (no --onefile): queda una
; carpeta completa en dist\WhatsAppMasivos, no un solo archivo. Hay que
; copiar TODO su contenido, no solo el .exe.
Source: "dist\WhatsAppMasivos\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Ejecutar {#MyAppName}"; Flags: nowait postinstall skipifsilent

