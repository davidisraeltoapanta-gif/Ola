"""
licencias.py
Módulo COMPARTIDO entre el programa del cliente (app.py) y la herramienta
de generación de códigos (generador_licencias.py, que solo tú usas).

Contiene la lógica de firma y verificación de licencias por días, atadas
al equipo donde se activan.

Nivel de protección: esto NO es criptografía de grado militar ni pretende
serlo -- es una barrera razonable para desalentar a la gran mayoría de la
gente que podría intentar copiar el programa sin pagar, sin ser tan
compleja que se vuelva difícil de mantener. Alguien con conocimientos
serios de ingeniería inversa eventualmente podría romperla; eso se acepta
como un riesgo de negocio conocido, no como una promesa de seguridad.
"""

import base64
import hashlib
import hmac
import platform
import uuid
from datetime import datetime, timedelta

# ---------------------------------------------------------------
# Clave secreta ofuscada (no aparece como texto plano en el código
# fuente ni en el binario compilado -- se reconstruye en tiempo de
# ejecución). Es la MISMA clave la que usa app.py para verificar y
# generador_licencias.py para firmar -- si la cambias, tiene que
# cambiar en ambos lados (por eso vive en este único archivo).
# ---------------------------------------------------------------
_CLAVE_OFUSCADA = [248, 59, 135, 148, 195, 57, 239, 44, 192, 99, 31, 36, 4, 240,
                    113, 98, 142, 53, 115, 35, 231, 7, 238, 5, 64, 7, 150, 210,
                    81, 111, 112, 76]
_CONSTANTE = 40


def _clave():
    return bytes(b ^ _CONSTANTE for b in _CLAVE_OFUSCADA)


# =========================================================
# Identificador de equipo
# =========================================================
def hardware_id():
    """
    Identificador razonablemente estable de esta PC (no requiere
    librerías externas). Combina el nombre del equipo con la dirección
    MAC de red. No es infalsificable, pero es suficiente para atar una
    licencia a "esta computadora" en la práctica.
    """
    base = f"{platform.node()}|{uuid.getnode()}"
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


def _hash_corto(hw_id):
    """Los primeros 8 caracteres del hash del hardware_id -- se usa DENTRO
    del código de activación para no alargarlo innecesariamente."""
    return hashlib.sha256(hw_id.encode("utf-8")).hexdigest()[:8]


# =========================================================
# Generar un código (lo usa generador_licencias.py)
# =========================================================
# Época fija para expresar la fecha como un número pequeño de días
# (en vez de escribir el año completo cada vez, lo que alarga el código).
_EPOCA = datetime(2026, 1, 1)


def generar_codigo(hardware_id_cliente, dias, fecha_generacion=None):
    fecha_generacion = fecha_generacion or datetime.now()
    dias_desde_epoca = (fecha_generacion - _EPOCA).days
    hash_hw = _hash_corto(hardware_id_cliente)

    payload = f"{hash_hw}.{dias}.{dias_desde_epoca}"
    firma = hmac.new(_clave(), payload.encode("utf-8"), hashlib.sha256).hexdigest()[:10]
    crudo = f"{payload}.{firma}"

    b32 = base64.b32encode(crudo.encode("utf-8")).decode("utf-8").rstrip("=")
    bloques = [b32[i:i + 5] for i in range(0, len(b32), 5)]
    return "-".join(bloques)


# =========================================================
# Validar un código (lo usa app.py)
# =========================================================
def validar_codigo(codigo, hardware_id_actual):
    """
    Devuelve dict:
      {"ok": True, "dias": int, "fecha_generacion": date, "fecha_expiracion": date}
      {"ok": False, "error": "..."}
    """
    try:
        crudo_b32 = codigo.replace("-", "").replace(" ", "").upper()
        padding = "=" * ((8 - len(crudo_b32) % 8) % 8)
        crudo = base64.b32decode(crudo_b32 + padding).decode("utf-8")

        partes = crudo.split(".")
        if len(partes) != 4:
            return {"ok": False, "error": "Código con formato inválido"}

        hash_hw, dias_str, dias_epoca_str, firma = partes
        payload = f"{hash_hw}.{dias_str}.{dias_epoca_str}"

        firma_esperada = hmac.new(_clave(), payload.encode("utf-8"), hashlib.sha256).hexdigest()[:10]
        if not hmac.compare_digest(firma, firma_esperada):
            return {"ok": False, "error": "Código inválido (no coincide la firma)"}

        if hash_hw != _hash_corto(hardware_id_actual):
            return {"ok": False, "error": "Este código no corresponde a este equipo"}

        dias = int(dias_str)
        fecha_generacion = _EPOCA + timedelta(days=int(dias_epoca_str))
        fecha_expiracion = fecha_generacion + timedelta(days=dias)

        return {
            "ok": True,
            "dias": dias,
            "fecha_generacion": fecha_generacion.date().isoformat(),
            "fecha_expiracion": fecha_expiracion.date().isoformat(),
        }
    except Exception:
        return {"ok": False, "error": "Código inválido o mal escrito"}
