"""
selectores_whatsapp.py

Todos los selectores (XPath / CSS) que el motor de envío usa para
"leer" la página de WhatsApp Web viven aquí, separados de la lógica en
whatsapp_core.py.

Por qué separado: WhatsApp cambia estos nombres internos sin avisar --
ya nos pasó una vez con la clase "message-out" y los íconos
"msg-check"/"msg-dblcheck", que un día simplemente dejaron de existir
en la página real. Cuando eso vuelva a pasar, el arreglo debería ser
"editar este archivo chico", no "salir a cazar por todo
whatsapp_core.py" como tocó hacer la primera vez.

Cada selector indica cuándo se confirmó contra el HTML real de
WhatsApp Web, para saber qué tan reciente (o vieja) es la evidencia
detrás de cada uno.
"""

# =========================================================
# Sesión / arranque (iniciar_navegador)
# =========================================================

# Confirma que la sesión ya cargó -- OJO: este contenedor puede aparecer
# en la página VACÍO, antes de que WhatsApp termine de llenarlo con los
# chats reales. Por eso no basta con esto solo (ver Fase 4 del
# documento de rediseño, todavía pendiente de un marcador más sólido
# con evidencia real de la pantalla de "cargando sesión").
ID_BARRA_LATERAL = "side"


# =========================================================
# Abrir un chat (abrir_chat / esperar_chat_o_error)
# =========================================================

XPATH_CAJA_TEXTO = '//div[@contenteditable="true"][@role="textbox"]'

# Confirmado con evidencia real (captura de pantalla, agosto 2026):
# WhatsApp muestra este texto exacto cuando el número no tiene cuenta
# asociada -- "El número +XXX no está en WhatsApp." A diferencia del
# selector genérico que se descartó antes (cualquier pop-up con botón,
# que confundía el aviso de carga normal con un error real), este
# busca el TEXTO específico, así que no debería coincidir con ningún
# otro diálogo por casualidad.
XPATH_AVISO_NUMERO_SIN_WHATSAPP = '//*[contains(text(), "no está en WhatsApp")]'

# DESCARTADO (agosto 2026): se usaba para detectar el aviso de "número
# inválido", pero se confirmó con evidencia real (captura de pantalla)
# que el diálogo normal de carga de WhatsApp ("Iniciando chat...", con
# botón "Cancelar") calza con este mismo selector genérico -- cualquier
# ventana emergente con un botón, sin ser un error de verdad. Causaba
# que números VÁLIDOS se descartaran como si no tuvieran WhatsApp. Se
# deja documentado para no repetir el mismo selector por error más
# adelante; no se usa en ningún lado del código actual.
XPATH_POPUP_ERROR_BOTON = '//div[@data-animate-modal-popup="true"]//button'


# =========================================================
# Verificación de envío -- confirmado con HTML real (agosto 2026)
# =========================================================
# Cada mensaje real de la conversación vive dentro de <div id="main">
# (el panel de la conversación abierta, separado de la lista de chats
# de la izquierda), como una fila con role="row" y un
# data-testid="conv-msg-XXXXX". El estado de envío vive en un bloque
# data-testid="msg-meta" dentro de esa fila, en un <span> con
# aria-label describiendo el estado EN TEXTO, en español.

XPATH_PANEL_CONVERSACION = '//div[@id="main"]'
# OJO: role="row" y data-testid="conv-msg-..." NO están en el mismo
# <div> -- están en dos divs distintos, uno adentro del otro (el de
# afuera tiene role="row", el de adentro tiene el data-testid). Un
# selector que pida los dos atributos en el mismo elemento nunca
# encuentra nada -- confirmado con evidencia real (HTML guardado de un
# fallo), no es una suposición.
XPATH_FILA_MENSAJE = XPATH_PANEL_CONVERSACION + '//div[starts-with(@data-testid,"conv-msg-")]'
XPATH_ULTIMA_FILA_MENSAJE = f'({XPATH_FILA_MENSAJE})[last()]'
XPATH_ESTADO_EN_FILA = './/div[@data-testid="msg-meta"]//span[@aria-label]'

# Cualquiera de estos 3 confirma que WhatsApp recibió y aceptó el envío
# -- no se exige específicamente "Enviado" (✓ simple), porque en la
# práctica WhatsApp puede pasar directo a "Entregado" o "Leído" tan
# rápido que el programa nunca alcanza a ver el estado intermedio.
ESTADOS_ENVIO_CONFIRMADO = ("Enviado", "Entregado", "Leído", "Leido")


# =========================================================
# Adjuntar archivo (enviar_adjunto)
# =========================================================

XPATH_BOTON_ADJUNTAR = '//button[@aria-label="Adjuntar"]'
CSS_CAMPO_ARCHIVO_OCULTO = 'input[type="file"]'
XPATH_BOTON_ENVIAR_ADJUNTO = '//div[@aria-label="Enviar 1 seleccionado"]'

# Respaldo por si el método principal (esperar el campo NUEVO que
# aparece justo después del clic) no encuentra nada -- coincide por
# atributos en vez de por "recién aparecido".
SELECTOR_INPUT_ARCHIVO_POR_TIPO = {
    "Fotos y videos": 'input[type="file"][accept*="image"]',
    "Documento": 'input[type="file"][accept="*"]',
    "Audio": 'input[type="file"][accept*="audio"]',
}


def xpath_boton_tipo_adjunto(label):
    """label: 'Fotos y videos' / 'Documento' / 'Audio' -- el botón del
    menú de "Adjuntar" que corresponde a ese tipo."""
    return f'//button[@aria-label="{label}"]'
