"""
test_licencias.py
Pruebas automatizadas para licencias.py -- la pieza más sensible del
programa (si se rompe, puede bloquear a un cliente que sí pagó, o dejar
pasar a alguien que no pagó).

Cómo correrlas:
    python -m unittest test_licencias.py -v

Se recomienda correrlas cada vez que se modifique licencias.py, antes de
compilar una versión nueva -- toma 1 segundo y evita sorpresas.
"""

import unittest
from datetime import datetime, timedelta

import licencias


class TestGenerarYValidarCodigo(unittest.TestCase):
    def setUp(self):
        self.hw = "hardware-de-prueba-1234567890"

    def test_codigo_valido_con_mismo_equipo(self):
        codigo = licencias.generar_codigo(self.hw, dias=30)
        resultado = licencias.validar_codigo(codigo, self.hw)
        self.assertTrue(resultado["ok"])
        self.assertEqual(resultado["dias"], 30)

    def test_codigo_calcula_bien_la_fecha_de_expiracion(self):
        fecha_gen = datetime(2026, 1, 1)
        codigo = licencias.generar_codigo(self.hw, dias=15, fecha_generacion=fecha_gen)
        resultado = licencias.validar_codigo(codigo, self.hw)
        self.assertEqual(resultado["fecha_generacion"], "2026-01-01")
        self.assertEqual(resultado["fecha_expiracion"], "2026-01-16")

    def test_codigo_rechazado_con_otro_equipo(self):
        codigo = licencias.generar_codigo(self.hw, dias=30)
        resultado = licencias.validar_codigo(codigo, "otro-equipo-completamente-distinto")
        self.assertFalse(resultado["ok"])

    def test_codigo_alterado_a_mano_es_rechazado(self):
        codigo = licencias.generar_codigo(self.hw, dias=30)
        # Se altera una posición del medio, no la última -- el último
        # carácter de un texto en Base32 a veces no afecta el contenido
        # decodificado (particularidad conocida de cómo Base32 rellena
        # cuando la cantidad de bits no es múltiplo exacto de 5), así que
        # alterar justo ahí no es una prueba representativa de manipulación.
        mitad = len(codigo) // 2
        caracter_mitad = codigo[mitad]
        alterado = codigo[:mitad] + ("Z" if caracter_mitad != "Z" else "A") + codigo[mitad + 1:]
        resultado = licencias.validar_codigo(alterado, self.hw)
        self.assertFalse(resultado["ok"])

    def test_texto_basura_no_rompe_el_programa(self):
        for basura in ["", "no-es-un-codigo", "1234", "🎉🎉🎉", "   ", None]:
            try:
                resultado = licencias.validar_codigo(basura or "", self.hw)
                self.assertFalse(resultado["ok"])
            except Exception as e:
                self.fail(f"validar_codigo no debe lanzar excepciones con entrada rara: {basura!r} -> {e}")

    def test_diferentes_equipos_dan_hardware_id_distinto(self):
        # No podemos simular dos PCs reales aquí, pero sí confirmamos que
        # el hash depende de la entrada (dos entradas distintas -> ids
        # distintos), que es la propiedad que realmente importa.
        id_a = licencias._hash_corto("equipo-A")
        id_b = licencias._hash_corto("equipo-B")
        self.assertNotEqual(id_a, id_b)

    def test_mismo_equipo_siempre_da_el_mismo_id(self):
        id_1 = licencias.hardware_id()
        id_2 = licencias.hardware_id()
        self.assertEqual(id_1, id_2)


class TestEscenariosDeVencimiento(unittest.TestCase):
    """
    licencias.py no decide por sí solo si una licencia venció -- eso lo
    hace app.py comparando fecha_expiracion contra hoy. Aquí probamos que
    el cálculo de la fecha (la parte que si se rompe, rompe todo lo demás)
    sea siempre correcto, incluyendo casos límite.
    """

    def test_licencia_de_un_dia(self):
        fecha_gen = datetime(2026, 6, 15)
        codigo = licencias.generar_codigo("equipo-x", dias=1, fecha_generacion=fecha_gen)
        resultado = licencias.validar_codigo(codigo, "equipo-x")
        self.assertEqual(resultado["fecha_expiracion"], "2026-06-16")

    def test_licencia_larga_un_anio(self):
        fecha_gen = datetime(2026, 1, 1)
        codigo = licencias.generar_codigo("equipo-x", dias=365, fecha_generacion=fecha_gen)
        resultado = licencias.validar_codigo(codigo, "equipo-x")
        self.assertEqual(resultado["fecha_expiracion"], "2027-01-01")

    def test_cruce_de_fin_de_anio(self):
        fecha_gen = datetime(2026, 12, 20)
        codigo = licencias.generar_codigo("equipo-x", dias=30, fecha_generacion=fecha_gen)
        resultado = licencias.validar_codigo(codigo, "equipo-x")
        self.assertEqual(resultado["fecha_expiracion"], "2027-01-19")


if __name__ == "__main__":
    unittest.main(verbosity=2)
