// =========================================================
// Estado global
// =========================================================
let segmentos = [];          // [{id, nombre, desde, hasta, modulos:[{id, tipo, contenido|ruta}]}]
let segmentoContador = 0;
let moduloContador = 0;
let excelCargado = null;     // {ruta, nombre_archivo, total, auto_segmentos, primer_contacto}
let dragInfo = null;         // {segmentoId, moduloId}

let estadoBoton = "inactivo";   // "inactivo" | "corriendo" | "pausado"
let campanaActualId = null;
let estadoDbActual = null;      // "Borrador" | "En curso" | "Pausada" | "Finalizada" | null
let hayHiloActivo = false;      // true solo si el motor está corriendo AHORA en este proceso
                                  // (si se retomó una campaña "Pausada" tras cerrar y abrir el
                                  // programa, no hay hilo vivo aunque la BD diga "Pausada")

let plantillasCache = [];
let chipsRefrescables = [];  // funciones para repintar chips de plantillas ya renderizadas

let modoCampana = null;      // "basica" | "avanzada" | null (todavía sin elegir)

function api() { return window.pywebview.api; }

// =========================================================
// Navegación entre páginas
// =========================================================
document.querySelectorAll(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => {
    if (btn.dataset.page === "crear" && modoCampana === null) {
      confirmarYAbrirSelectorModo();
    } else {
      irAPagina(btn.dataset.page);
    }
  });
});

function irAPagina(pageId) {
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelector(`.nav-item[data-page="${pageId}"]`).classList.add("active");
  document.getElementById("page-" + pageId).classList.add("active");

  if (pageId === "dashboard") cargarDashboard();
  if (pageId === "reportes") cargarReportes();
  if (pageId === "info") cargarInfo();
  if (pageId === "home") cargarHome();
  if (pageId === "seguimiento") cargarSeguimiento();
  if (pageId === "activacion") cargarActivacion();
}

// Llena cualquier elemento con data-icono="nombre" con el SVG
// correspondiente. Por defecto busca en todo el documento, pero se le
// puede pasar un elemento/fragmento específico -- necesario para el
// contenido que se copia desde un <template> (segmentos, módulos), ya
// que ese contenido vive fuera del documento normal hasta que se inserta,
// y buscar en "document" completo no lo encuentra.
function pintarIconosEstaticos(raiz) {
  (raiz || document).querySelectorAll("[data-icono]").forEach(el => {
    el.innerHTML = icono(el.dataset.icono, el.dataset.iconoTamano || 18);
  });
}
pintarIconosEstaticos();

window.addEventListener("pywebviewready", () => {
  verificarEstadoLicencia();

  cargarInfoBasica();
  cargarHome();
  cargarPlantillas();
  cargarTema();

  api().es_dueno().then(esDueno => {
    if (esDueno) document.getElementById("nav-activacion").style.display = "flex";
  });

  api().es_primera_vez().then(esPrimera => {
    if (esPrimera) abrirOnboarding();
  });
});

async function cargarTema() {
  const tema = await api().obtener_tema();
  aplicarTema(tema === "oscuro");
}

function aplicarTema(oscuro) {
  document.body.classList.toggle("tema-oscuro", oscuro);
  const btn = document.getElementById("btn-toggle-tema");
  btn.innerHTML = oscuro
    ? `${icono("sol", 14)} Modo claro`
    : `${icono("luna", 14)} Modo oscuro`;
  btn.title = oscuro ? "Cambiar a modo claro" : "Cambiar a modo oscuro";
}

document.getElementById("btn-toggle-tema").addEventListener("click", async () => {
  const oscuroActivo = document.body.classList.contains("tema-oscuro");
  const nuevoOscuro = !oscuroActivo;
  aplicarTema(nuevoOscuro);
  await api().guardar_tema(nuevoOscuro ? "oscuro" : "claro");
});

// =========================================================
// LICENCIA
// =========================================================
async function verificarEstadoLicencia() {
  const res = await api().verificar_licencia();
  const overlay = document.getElementById("overlay-licencia");
  const banner = document.getElementById("footer-licencia-vence");

  if (res.estado === "valida") {
    overlay.style.display = "none";
    if (res.dias_restantes <= 5) {
      banner.style.display = "block";
      banner.innerHTML = `${icono("alerta", 12)} Vence en ${res.dias_restantes} día(s)`;
    } else {
      banner.style.display = "none";
    }
    return true;
  }

  banner.style.display = "none";
  overlay.style.display = "flex";

  const titulo = document.getElementById("licencia-titulo");
  const mensaje = document.getElementById("licencia-mensaje");

  if (res.estado === "sin_activar") {
    titulo.textContent = "Activa tu licencia";
    mensaje.textContent = "Ingresa el código de activación que te dio tu proveedor para empezar a usar el programa.";
  } else if (res.estado === "vencida") {
    titulo.textContent = "Tu licencia venció";
    mensaje.textContent = "Contacta a tu proveedor para renovar tu suscripción y obtener un nuevo código de activación.";
  } else if (res.estado === "manipulada") {
    titulo.textContent = "No se pudo verificar la licencia";
    mensaje.textContent = "Se detectó un cambio inusual en la fecha del sistema. Verifica la fecha y hora de tu equipo, o contacta a tu proveedor.";
  }

  const hwId = await api().obtener_hardware_id();
  document.getElementById("licencia-hw-id").textContent = hwId;

  const urlSolicitud = await api().obtener_url_solicitud_licencia();
  const btnSolicitar = document.getElementById("btn-solicitar-licencia");
  if (urlSolicitud) {
    btnSolicitar.style.display = "inline-flex";
    btnSolicitar.onclick = () => window.open(urlSolicitud, "_blank");
  } else {
    btnSolicitar.style.display = "none";
  }

  return false;
}

document.getElementById("btn-copiar-hw").addEventListener("click", () => {
  const texto = document.getElementById("licencia-hw-id").textContent;
  navigator.clipboard.writeText(texto).then(() => {
    const btn = document.getElementById("btn-copiar-hw");
    const original = btn.textContent;
    btn.innerHTML = `${icono("check")} Copiado`;
    setTimeout(() => { btn.textContent = original; }, 1500);
  });
});

document.getElementById("btn-activar-licencia").addEventListener("click", async () => {
  const input = document.getElementById("input-codigo-activacion");
  const resultado = document.getElementById("licencia-resultado");
  const codigo = input.value.trim();
  if (!codigo) return;

  resultado.style.display = "block";
  resultado.textContent = "Verificando...";

  const res = await api().activar_licencia(codigo);
  if (!res.ok) {
    resultado.innerHTML = resultadoHTML(false, res.error);
    return;
  }

  resultado.innerHTML = resultadoHTML(true, `Licencia activada correctamente (${res.dias} días, vence el ${res.fecha_expiracion})`);
  setTimeout(verificarEstadoLicencia, 1200);
});

// Arma el texto de un mensaje de resultado (éxito/error) con su ícono de
// línea correspondiente, en vez de un emoji de color -- usar siempre con
// .innerHTML, no .textContent.
function resultadoHTML(ok, mensaje) {
  return `${icono(ok ? "check" : "alerta")} ${mensaje}`;
}

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s || "";
  return div.innerHTML;
}

function insertarEnTextarea(textarea, texto) {
  const inicio = textarea.selectionStart;
  const fin = textarea.selectionEnd;
  textarea.value = textarea.value.slice(0, inicio) + texto + textarea.value.slice(fin);
  const nuevaPosicion = inicio + texto.length;
  textarea.focus();
  textarea.setSelectionRange(nuevaPosicion, nuevaPosicion);
}

// =========================================================
// INICIO (HOME)
// =========================================================
async function cargarRecordatoriosPendientesHome() {
  const card = document.getElementById("card-recordatorios-pendientes");
  const contenedor = document.getElementById("lista-recordatorios-pendientes");
  const pendientes = await api().listar_recordatorios_pendientes_home();

  if (!pendientes || pendientes.length === 0) {
    card.style.display = "none";
    return;
  }

  card.style.display = "block";
  contenedor.innerHTML = "";
  pendientes.forEach(r => {
    const div = document.createElement("div");
    div.className = "recordatorio-item";
    const fecha = (r.fecha_hora || "").replace("T", " ");
    div.innerHTML = `
      <div>
        <div class="recordatorio-fecha">${escapeHtml(r.campana_nombre)} · ${fecha}</div>
        <div>${escapeHtml(r.texto)}</div>
      </div>
      <button class="btn btn-sm btn-outline btn-visto-recordatorio" data-id="${r.id}">${icono("check",14)} Visto</button>
    `;
    contenedor.appendChild(div);
  });

  document.querySelectorAll(".btn-visto-recordatorio").forEach(btn => {
    btn.addEventListener("click", async () => {
      const res = await api().marcar_recordatorio_visto(parseInt(btn.dataset.id));
      if (res.ok) {
        if (res.pendientes.length === 0) {
          card.style.display = "none";
        } else {
          cargarRecordatoriosPendientesHome();
        }
      }
    });
  });
}

async function cargarHome() {
  await cargarRecordatoriosPendientesHome();

  const campanas = await api().listar_campanas_home();
  const tbody = document.querySelector("#tabla-campanas tbody");
  tbody.innerHTML = "";
  const sinCampanas = document.getElementById("home-sin-campanas");
  const bannerPend = document.getElementById("banner-pendiente");
  const bannerPendTexto = document.getElementById("banner-pendiente-texto");

  if (!campanas || campanas.length === 0) {
    sinCampanas.style.display = "block";
    bannerPend.style.display = "none";
    return;
  }
  sinCampanas.style.display = "none";

  const pendientes = campanas.filter(c => c.estado === "Pausada" || c.estado === "En curso");
  if (pendientes.length > 0) {
    bannerPend.style.display = "block";
    bannerPendTexto.textContent = pendientes.map(c => c.nombre).join(", ") +
      " — usa \"Retomar\" en la tabla de abajo para continuar.";
  } else {
    bannerPend.style.display = "none";
  }

  campanas.forEach(c => {
    const tr = document.createElement("tr");
    const estadoClass = "estado-" + c.estado.replace(/ /g, "-");
    const progreso = `${c.enviados} / ${c.total_contactos}`;
    const fecha = (c.fecha_creacion || "").slice(0, 16).replace("T", " ");

    tr.innerHTML = `
      <td><b>${escapeHtml(c.nombre)}</b></td>
      <td>${fecha}</td>
      <td><span class="estado-badge ${estadoClass}">${c.estado}</span></td>
      <td>${progreso}</td>
      <td>
        <div class="acciones-fila">
          <button class="btn btn-outline btn-sm btn-retomar" data-id="${c.id}">${icono("retomar",14)} Retomar</button>
          <button class="btn btn-outline btn-sm btn-ver-notas" data-id="${c.id}" data-nombre="${escapeHtml(c.nombre)}">${icono("portapapeles",14)} Seguimiento</button>
          ${c.estado !== "Finalizada" ? `<button class="btn btn-outline btn-sm btn-finalizar" data-id="${c.id}">${icono("check",14)} Finalizar</button>` : ""}
          <button class="btn-icon btn-eliminar-campana" data-id="${c.id}" title="Eliminar">${icono("papelera",14)}</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  document.querySelectorAll(".btn-retomar").forEach(btn => {
    btn.addEventListener("click", () => retomarCampana(parseInt(btn.dataset.id)));
  });
  document.querySelectorAll(".btn-ver-notas").forEach(btn => {
    btn.addEventListener("click", () => abrirModalNotas(parseInt(btn.dataset.id), btn.dataset.nombre));
  });
  document.querySelectorAll(".btn-finalizar").forEach(btn => {
    btn.addEventListener("click", async () => {
      await api().marcar_finalizada(parseInt(btn.dataset.id));
      cargarHome();
    });
  });
  document.querySelectorAll(".btn-eliminar-campana").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (!confirm("¿Eliminar esta campaña y su historial? Esta acción no se puede deshacer.")) return;
      const res = await api().eliminar_campana(parseInt(btn.dataset.id));
      if (!res.ok) { alert(res.error); return; }
      cargarHome();
    });
  });
}

document.getElementById("btn-hero-crear").addEventListener("click", confirmarYAbrirSelectorModo);
document.getElementById("btn-nueva-campana").addEventListener("click", confirmarYAbrirSelectorModo);

async function confirmarYAbrirSelectorModo() {
  if (estadoBoton !== "inactivo") {
    if (!confirm("Hay una campaña en curso. Se pausará (tu progreso queda guardado, la puedes retomar después) para crear una nueva. ¿Continuar?")) return;
    await api().detener_campana();
  }
  document.getElementById("modal-modo-campana").style.display = "flex";
}

document.getElementById("btn-modo-cancelar").addEventListener("click", () => {
  document.getElementById("modal-modo-campana").style.display = "none";
});

document.getElementById("btn-modo-basica").addEventListener("click", () => manejarSeleccionModo("basica"));
document.getElementById("btn-modo-avanzada").addEventListener("click", () => manejarSeleccionModo("avanzada"));

async function manejarSeleccionModo(modo) {
  document.getElementById("modal-modo-campana").style.display = "none";

  if (columnaOrigenParaCampana) {
    const columnaId = columnaOrigenParaCampana.id;
    columnaOrigenParaCampana = null;

    await api().nueva_campana();
    reiniciarPantallaCrear();
    aplicarModoCampana(modo);

    const res = await api().crear_campana_desde_columna(columnaId, modo);
    if (!res.ok) {
      if (res.error) alert(res.error);
      return;
    }
    aplicarExcelCargado(res);
    irAPagina("crear");
    return;
  }

  await iniciarNuevaCampanaConModo(modo);
}

async function iniciarNuevaCampanaConModo(modo) {
  document.getElementById("modal-modo-campana").style.display = "none";
  await api().nueva_campana();
  reiniciarPantallaCrear();
  aplicarModoCampana(modo);
  irAPagina("crear");
}

function aplicarModoCampana(modo) {
  modoCampana = modo;
  document.body.classList.remove("modo-basica", "modo-avanzada");
  document.body.classList.add("modo-" + modo);
  document.getElementById("titulo-seccion-mensaje").textContent =
    modo === "basica" ? "Tu mensaje" : "Segmentación y Flow Builder";
}

function reiniciarPantallaCrear() {
  segmentos = [];
  segmentoContador = 0;
  moduloContador = 0;
  excelCargado = null;
  campanaActualId = null;
  estadoBoton = "inactivo";
  hayHiloActivo = false;
  modoCampana = null;
  document.body.classList.remove("modo-basica", "modo-avanzada");

  estadoDbActual = null;

  document.getElementById("segmentos-container").innerHTML = "";
  document.getElementById("excel-info").textContent = "Sube tu archivo con tus contactos";
  document.getElementById("excel-auto-msg").style.display = "none";
  document.getElementById("input-nombre-campana").value = "Campaña sin nombre";
  document.getElementById("lista-notas").innerHTML = "";
  document.getElementById("checklist-lista").innerHTML = "";
  document.getElementById("lista-recordatorios").innerHTML = "";
  document.getElementById("plantillas-campana-chips").innerHTML = "";
  document.getElementById("btn-sugerir-recordatorio").style.display = "none";
  recordatorioEditandoId = null;
  document.getElementById("btn-agregar-recordatorio").textContent = "+ Agregar";
  document.getElementById("btn-cancelar-edicion-recordatorio").style.display = "none";
  limpiarLog();
  actualizarResumen();
}

// =========================================================
// RETOMAR CAMPAÑA (desde Home)
// =========================================================
async function retomarCampana(campanaId) {
  const res = await api().retomar_campana(campanaId);
  if (!res.ok) { alert(res.error); return; }

  reiniciarPantallaCrear();
  aplicarModoCampana(res.campana.modo || "avanzada");

  campanaActualId = res.campana.id;
  excelCargado = res.excel;
  document.getElementById("excel-info").textContent =
    `${res.excel.nombre_archivo} — ${res.excel.total} contactos cargados`;
  document.getElementById("btn-editar-datos-excel").style.display = "inline-flex";
  document.getElementById("input-nombre-campana").value = res.campana.nombre;

  const config = res.campana.config;
  if (config && config.segmentos) {
    config.segmentos.forEach(segCfg => {
      segmentoContador++;
      const letra = String.fromCharCode(64 + segmentoContador);
      // segCfg.cantidad existe en campañas creadas con el sistema nuevo
      // (por nombre). Si no existe (campaña vieja, guardada con el
      // sistema de rangos por posición), se aproxima con hasta-desde+1
      // solo para mostrar un número en la tarjeta -- el envío real de
      // esa campaña sigue funcionando igual, por su método original.
      const cantidad = segCfg.cantidad != null
        ? segCfg.cantidad
        : (segCfg.desde != null && segCfg.hasta != null ? (segCfg.hasta - segCfg.desde + 1) : null);
      const seg = {
        id: "seg_" + segmentoContador, nombre: segCfg.nombre,
        desde: segCfg.desde, hasta: segCfg.hasta, cantidad,
        modulos: [],
      };
      segmentos.push(seg);
      const segEl = renderSegmento(seg, letra);
      (segCfg.modulos || []).forEach(modCfg => agregarModulo(seg, segEl, modCfg.tipo, modCfg));
    });
  }

  await cargarNotas(campanaActualId);
  await cargarChecklist(campanaActualId);
  await cargarRecordatorios(campanaActualId);
  actualizarResumen();
  await sincronizarEstadoBoton();
  irAPagina("crear");
}

// =========================================================
// CARGAR EXCEL (con detección automática de segmentos)
// =========================================================
document.getElementById("btn-cargar-excel").addEventListener("click", async () => {
  const esFinalizada = (estadoBoton === "inactivo" && campanaActualId !== null && estadoDbActual === "Finalizada");

  if (esFinalizada) {
    if (!confirm(
      "Vas a reemplazar el Excel de esta campaña (por ejemplo, para una segunda etapa o un " +
      "segundo paso del checklist). Los segmentos y mensajes se vuelven a armar desde cero " +
      "según lo que traiga el archivo nuevo -- el checklist, las observaciones y los " +
      "recordatorios NO se tocan, siguen siendo los de esta misma campaña. ¿Continuar?"
    )) return;

    const res = await api().actualizar_excel_campana();
    if (!res.ok) {
      if (res.error) alert(res.error);
      return;
    }
    aplicarExcelCargado(res);
    await sincronizarEstadoBoton();
    alert(`Listo -- ${res.total} contactos cargados desde el Excel nuevo, segmentos y mensajes reiniciados para esta etapa.`);
    return;
  }

  const res = await api().seleccionar_excel(modoCampana);
  if (!res || !res.ok) {
    if (res && res.error) alert("Error al leer el Excel: " + res.error);
    return;
  }
  aplicarExcelCargado(res);
});

document.getElementById("btn-descargar-modelo").addEventListener("click", async () => {
  const res = await api().descargar_modelo_excel(modoCampana || "avanzada");
  if (res && res.ok === false && res.error) {
    alert("No se pudo generar el modelo: " + res.error);
  }
});

function aplicarExcelCargado(res) {
  excelCargado = res;
  document.getElementById("excel-info").textContent = `${res.nombre_archivo} — ${res.total} contactos cargados`;
  document.getElementById("btn-editar-datos-excel").style.display = "inline-flex";

  const autoMsg = document.getElementById("excel-auto-msg");

  if (modoCampana === "basica") {
    // Modo Básico: un solo mensaje para todos, sin exponer el concepto
    // de segmentos al usuario (por dentro sigue siendo un segmento que
    // cubre a todos los contactos, la UI simplemente lo oculta). No
    // usa columna "Segmento", así que sigue necesitando desde/hasta
    // para que el motor de envío lo reconozca.
    autoMsg.style.display = "none";
    segmentos = [];
    document.getElementById("segmentos-container").innerHTML = "";
    segmentoContador = 1;
    const seg = { id: "seg_1", nombre: "Mensaje", desde: 1, hasta: res.total, cantidad: res.total, modulos: [] };
    segmentos.push(seg);
    renderSegmento(seg, "A");
  } else if (res.auto_segmentos && res.auto_segmentos.length > 0) {
    autoMsg.style.display = "block";
    autoMsg.innerHTML = `${icono("destacar")} Se detectaron ${res.auto_segmentos.length} segmento(s) automáticamente desde la columna "Segmento" de tu Excel. Solo agrega el mensaje/adjuntos de cada uno.`;

    segmentos = [];
    document.getElementById("segmentos-container").innerHTML = "";
    segmentoContador = 0;
    res.auto_segmentos.forEach(autoSeg => {
      segmentoContador++;
      const letra = String.fromCharCode(64 + segmentoContador);
      const seg = { id: "seg_" + segmentoContador, nombre: autoSeg.nombre, cantidad: autoSeg.cantidad, modulos: [] };
      segmentos.push(seg);
      renderSegmento(seg, letra);
    });
  } else {
    autoMsg.style.display = "none";
  }

  actualizarResumen();
}

// =========================================================
// EDITAR DATOS DEL EXCEL (dentro del programa) -- solo corrige
// valores de celdas, no agrega ni quita filas ni columnas. Puede
// abrirse con TODOS los contactos, o filtrado a un solo segmento
// (para detectar rápido a alguien que se filtró por error).
// =========================================================
let editorExcelColumnas = [];
let editorExcelIndices = null; // null = edición de todo el Excel; array = edición filtrada de un segmento

document.getElementById("btn-editar-datos-excel").addEventListener("click", async () => {
  await abrirEditorExcel(null);
});

async function abrirEditorExcel(segmentoFiltro) {
  const res = await api().obtener_datos_para_editar(segmentoFiltro || null);
  if (!res.ok) {
    alert(res.error || "No se pudo cargar la información para editar.");
    return;
  }
  editorExcelIndices = segmentoFiltro ? res.indices : null;
  document.getElementById("editor-excel-titulo").textContent =
    segmentoFiltro ? `Editar contactos -- segmento "${segmentoFiltro}"` : "Editar datos";
  construirTablaEditor(res.columnas, res.filas);
  document.getElementById("modal-editar-excel").style.display = "flex";
}

function construirTablaEditor(columnas, filas) {
  editorExcelColumnas = columnas;
  const tabla = document.getElementById("editor-excel-tabla");
  tabla.innerHTML = "";

  const thead = document.createElement("thead");
  const trHead = document.createElement("tr");
  columnas.forEach(col => {
    const th = document.createElement("th");
    th.textContent = col;
    trHead.appendChild(th);
  });
  thead.appendChild(trHead);
  tabla.appendChild(thead);

  const tbody = document.createElement("tbody");
  filas.forEach(fila => {
    const tr = document.createElement("tr");
    columnas.forEach(col => {
      const td = document.createElement("td");
      td.contentEditable = "true";
      td.textContent = fila[col] !== undefined ? fila[col] : "";
      td.className = "editor-excel-celda";
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  tabla.appendChild(tbody);
}

document.getElementById("btn-editor-excel-cancelar").addEventListener("click", () => {
  document.getElementById("modal-editar-excel").style.display = "none";
});

document.getElementById("btn-editor-excel-guardar").addEventListener("click", async () => {
  const tabla = document.getElementById("editor-excel-tabla");
  const filas = [];
  tabla.querySelectorAll("tbody tr").forEach(tr => {
    const fila = {};
    Array.from(tr.children).forEach((td, i) => {
      fila[editorExcelColumnas[i]] = td.textContent.trim();
    });
    filas.push(fila);
  });

  const res = await api().guardar_edicion_excel(editorExcelColumnas, filas, editorExcelIndices);
  if (!res.ok) {
    alert(res.error || "No se pudo guardar la edición.");
    return;
  }

  document.getElementById("modal-editar-excel").style.display = "none";
  if (excelCargado) {
    excelCargado.total = res.total;
    document.getElementById("excel-info").textContent = `${excelCargado.nombre_archivo} — ${res.total} contactos cargados`;
  }

  reconciliarSegmentosTrasEdicion(res.auto_segmentos || []);
  actualizarResumen();
  alert("Datos guardados -- los segmentos se actualizaron sin borrar los mensajes que ya tenías configurados.");
});

// Compara los segmentos recién detectados (por nombre real de la
// columna "Segmento", ya no por posición) contra los que ya estaban en
// pantalla: el que ya existía conserva su mensaje/adjuntos tal cual,
// solo se le actualiza el conteo de contactos; el que es nuevo aparece
// como tarjeta vacía; el que se quedó sin contactos se elimina junto
// con lo que tenía configurado.
function reconciliarSegmentosTrasEdicion(autoSegmentosNuevos) {
  if (modoCampana === "basica") {
    // En modo básico no hay concepto de "varios segmentos por nombre"
    // -- solo se actualiza el conteo del único segmento que cubre a
    // todos los contactos.
    if (segmentos.length > 0 && excelCargado) {
      segmentos[0].hasta = excelCargado.total;
      segmentos[0].cantidad = excelCargado.total;
      actualizarConteoEnTarjeta(segmentos[0].id, excelCargado.total);
    }
    return;
  }

  const nombresNuevos = new Set(autoSegmentosNuevos.map(s => s.nombre));

  // 1) Actualiza el conteo de los que ya existían (por nombre) --
  //    sus módulos/mensaje NO se tocan.
  segmentos.forEach(seg => {
    const actualizado = autoSegmentosNuevos.find(s => s.nombre === seg.nombre);
    if (actualizado) {
      seg.cantidad = actualizado.cantidad;
      actualizarConteoEnTarjeta(seg.id, seg.cantidad);
    }
  });

  // 2) Elimina los que se quedaron sin contactos -- junto con su
  //    mensaje ya configurado, como se confirmó.
  const idsAEliminar = segmentos.filter(seg => !nombresNuevos.has(seg.nombre)).map(seg => seg.id);
  segmentos = segmentos.filter(seg => nombresNuevos.has(seg.nombre));
  idsAEliminar.forEach(id => {
    const el = document.querySelector(`.segmento-card[data-id="${id}"]`);
    if (el) el.remove();
  });

  // 3) Agrega como tarjetas nuevas los nombres que no existían antes.
  const nombresExistentes = new Set(segmentos.map(s => s.nombre));
  autoSegmentosNuevos.forEach(autoSeg => {
    if (!nombresExistentes.has(autoSeg.nombre)) {
      segmentoContador++;
      const letra = String.fromCharCode(64 + segmentoContador);
      const seg = { id: "seg_" + segmentoContador, nombre: autoSeg.nombre, cantidad: autoSeg.cantidad, modulos: [] };
      segmentos.push(seg);
      renderSegmento(seg, letra);
    }
  });
}

function actualizarConteoEnTarjeta(segId, cantidad) {
  const el = document.querySelector(`.segmento-card[data-id="${segId}"] .segmento-conteo-numero`);
  if (el) el.textContent = cantidad;
}

// =========================================================
// Segmentos -- se detectan automáticamente por la columna "Segmento"
// del Excel, ya no se agregan manualmente.
// =========================================================
function renderSegmento(seg, letra) {
  const tpl = document.getElementById("tpl-segmento").content.cloneNode(true);
  const el = tpl.querySelector(".segmento-card");
  pintarIconosEstaticos(el);
  el.dataset.id = seg.id;

  el.querySelector(".segmento-badge").textContent = letra;
  el.querySelector(".segmento-nombre-label").textContent = seg.nombre;
  el.querySelector(".segmento-conteo-numero").textContent = seg.cantidad != null ? seg.cantidad : "?";

  el.querySelector(".btn-ver-contactos-segmento").addEventListener("click", () => {
    abrirEditorExcel(seg.nombre);
  });

  el.querySelector(".btn-eliminar-segmento").addEventListener("click", () => {
    segmentos = segmentos.filter(s => s.id !== seg.id);
    el.remove();
    actualizarResumen();
  });

  el.querySelector(".btn-add-texto").addEventListener("click", () => agregarModulo(seg, el, "texto"));
  el.querySelector(".btn-add-archivo").addEventListener("click", () => agregarModulo(seg, el, "archivo"));

  // Los escuchadores de arrastrar-y-soltar se registran UNA sola vez por
  // segmento (aquí), no una vez por cada módulo que se agregue después --
  // antes se registraban dentro de renderModulo() y se iban acumulando
  // copias duplicadas del mismo escuchador cada vez que se sumaba un
  // módulo nuevo.
  const contenedorModulos = el.querySelector(".modulos-container");
  contenedorModulos.addEventListener("dragover", (e) => {
    e.preventDefault();
    const despues = obtenerElementoDespuesDe(contenedorModulos, e.clientY);
    const arrastrado = contenedorModulos.querySelector(".dragging");
    if (!arrastrado) return;
    if (despues == null) {
      contenedorModulos.appendChild(arrastrado);
    } else {
      contenedorModulos.insertBefore(arrastrado, despues);
    }
  });
  contenedorModulos.addEventListener("drop", () => {
    if (!dragInfo || dragInfo.segmentoId !== seg.id) return;
    const nuevosIds = [...contenedorModulos.querySelectorAll(".modulo-card")].map(c => c.dataset.id);
    seg.modulos.sort((a, b) => nuevosIds.indexOf(a.id) - nuevosIds.indexOf(b.id));
    dragInfo = null;
  });

  document.getElementById("segmentos-container").appendChild(el);
  return el;
}

function agregarModulo(seg, segEl, tipo, datosIniciales) {
  moduloContador++;
  const modId = "mod_" + moduloContador;
  let modulo;
  if (tipo === "texto") {
    modulo = { id: modId, tipo: "texto", contenido: (datosIniciales && datosIniciales.contenido) || "" };
  } else {
    modulo = {
      id: modId, tipo: "archivo",
      ruta: (datosIniciales && datosIniciales.ruta) || "",
      nombre_archivo: (datosIniciales && datosIniciales.nombre_archivo) || ""
    };
  }

  seg.modulos.push(modulo);
  renderModulo(modulo, seg, segEl);
  actualizarResumen();
}

function renderModulo(modulo, seg, segEl) {
  const tplId = modulo.tipo === "texto" ? "tpl-modulo-texto" : "tpl-modulo-archivo";
  const tpl = document.getElementById(tplId).content.cloneNode(true);
  const el = tpl.querySelector(".modulo-card");
  el.dataset.id = modulo.id;
  pintarIconosEstaticos(el);

  if (modulo.tipo === "texto") {
    const textarea = el.querySelector(".modulo-textarea");
    textarea.value = modulo.contenido || "";
    textarea.addEventListener("input", () => {
      modulo.contenido = textarea.value;
      actualizarResumen();
      actualizarPreview(el, modulo);
    });

    el.querySelectorAll(".tag-btn[data-tag], .tag-btn-menu-item[data-tag]").forEach(btn => {
      btn.addEventListener("click", () => {
        insertarEnTextarea(textarea, btn.dataset.tag);
        modulo.contenido = textarea.value;
        actualizarResumen();
        actualizarPreview(el, modulo);
        // Si vino del menú desplegable de nombre, se cierra después de elegir
        const menu = btn.closest(".tag-btn-menu");
        if (menu) menu.style.display = "none";
      });
    });

    // ---- Menú desplegable "Insertar nombre" ----
    const btnNombreDesplegable = el.querySelector(".btn-nombre-desplegable");
    const menuNombre = el.querySelector(".tag-btn-menu");
    if (btnNombreDesplegable && menuNombre) {
      btnNombreDesplegable.addEventListener("click", (e) => {
        e.stopPropagation();
        const yaAbierto = menuNombre.style.display === "block";
        document.querySelectorAll(".tag-btn-menu").forEach(m => { m.style.display = "none"; });
        menuNombre.style.display = yaAbierto ? "none" : "block";
      });
    }

    // ---- Selector de emojis con buscador ----
    const emojiBtn = el.querySelector(".btn-emoji");
    const emojiPanel = el.querySelector(".emoji-panel");
    const emojiBuscador = el.querySelector(".emoji-buscador");
    const emojiGrid = el.querySelector(".emoji-grid");

    function pintarEmojis(filtro) {
      emojiGrid.innerHTML = "";
      const f = (filtro || "").toLowerCase().trim();
      const lista = !f
        ? EMOJIS_DB
        : EMOJIS_DB.filter(item => item.k.includes(f));

      if (lista.length === 0) {
        emojiGrid.innerHTML = `<div class="muted-sm" style="grid-column: 1 / -1; padding:8px;">Sin resultados para "${escapeHtml(filtro)}"</div>`;
        return;
      }

      lista.slice(0, 150).forEach(item => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "emoji-item";
        b.textContent = item.e;
        b.title = item.k.split(" ")[0];
        b.addEventListener("click", () => {
          insertarEnTextarea(textarea, item.e);
          modulo.contenido = textarea.value;
          actualizarResumen();
          actualizarPreview(el, modulo);
        });
        emojiGrid.appendChild(b);
      });
    }

    emojiBtn.addEventListener("click", () => {
      const visible = emojiPanel.style.display !== "none";
      emojiPanel.style.display = visible ? "none" : "block";
      if (!visible) {
        emojiBuscador.value = "";
        pintarEmojis("");
        emojiBuscador.focus();
      }
    });
    emojiBuscador.addEventListener("input", () => pintarEmojis(emojiBuscador.value));

    el.querySelector(".btn-guardar-plantilla").addEventListener("click", async () => {
      if (!textarea.value.trim()) {
        alert("Escribe un mensaje antes de guardarlo como plantilla.");
        return;
      }
      const nombre = prompt("Nombre para esta plantilla:");
      if (!nombre) return;
      const res = await api().guardar_plantilla(nombre, textarea.value);
      if (res.ok) {
        await cargarPlantillas();
        chipsRefrescables.forEach(fn => fn());
      } else {
        alert(res.error);
      }
    });

    const chipsContainer = el.querySelector(".plantillas-chips");
    const panelEdicionPlantilla = document.createElement("div");
    panelEdicionPlantilla.className = "plantilla-editor-inline";
    panelEdicionPlantilla.style.display = "none";
    el.querySelector(".plantillas-row").appendChild(panelEdicionPlantilla);

    function abrirEditorPlantilla(p) {
      panelEdicionPlantilla.innerHTML = `
        <input type="text" class="input-text plantilla-editor-nombre" placeholder="Nombre de la plantilla">
        <textarea class="input-text plantilla-editor-contenido" rows="3" placeholder="Contenido del mensaje"></textarea>
        <div class="plantilla-editor-botones">
          <button class="btn btn-sm btn-outline btn-cancelar-editar-plantilla">${icono("equis", 13)} Cancelar</button>
          <button class="btn btn-sm btn-primary btn-guardar-editar-plantilla">${icono("check", 13)} Guardar</button>
        </div>
      `;
      panelEdicionPlantilla.querySelector(".plantilla-editor-nombre").value = p.nombre;
      panelEdicionPlantilla.querySelector(".plantilla-editor-contenido").value = p.contenido;
      panelEdicionPlantilla.style.display = "block";

      panelEdicionPlantilla.querySelector(".btn-cancelar-editar-plantilla").addEventListener("click", () => {
        panelEdicionPlantilla.style.display = "none";
      });
      panelEdicionPlantilla.querySelector(".btn-guardar-editar-plantilla").addEventListener("click", async () => {
        const nuevoNombre = panelEdicionPlantilla.querySelector(".plantilla-editor-nombre").value.trim();
        const nuevoContenido = panelEdicionPlantilla.querySelector(".plantilla-editor-contenido").value.trim();
        if (!nuevoNombre || !nuevoContenido) return;
        const res = await api().editar_plantilla(p.id, nuevoNombre, nuevoContenido);
        if (res.ok) {
          panelEdicionPlantilla.style.display = "none";
          await cargarPlantillas();
          chipsRefrescables.forEach(fn => fn());
        } else {
          alert(res.error);
        }
      });
    }

    function pintarChips() {
      chipsContainer.innerHTML = "";
      plantillasCache.forEach(p => {
        const grupo = document.createElement("span");
        grupo.className = "plantilla-chip-grupo";

        const chip = document.createElement("button");
        chip.className = "plantilla-chip";
        chip.textContent = p.nombre;
        chip.title = "Click para usar esta plantilla";
        chip.addEventListener("click", () => {
          textarea.value = p.contenido;
          modulo.contenido = p.contenido;
          actualizarResumen();
          actualizarPreview(el, modulo);
        });

        const btnEditar = document.createElement("button");
        btnEditar.className = "plantilla-chip-accion";
        btnEditar.innerHTML = icono("lapiz", 12);
        btnEditar.title = "Editar esta plantilla";
        btnEditar.addEventListener("click", (e) => {
          e.stopPropagation();
          abrirEditorPlantilla(p);
        });

        const btnEliminar = document.createElement("button");
        btnEliminar.className = "plantilla-chip-accion";
        btnEliminar.innerHTML = icono("equis", 10);
        btnEliminar.title = "Eliminar esta plantilla";
        btnEliminar.addEventListener("click", async (e) => {
          e.stopPropagation();
          await api().eliminar_plantilla(p.id);
          await cargarPlantillas();
          chipsRefrescables.forEach(fn => fn());
        });

        grupo.appendChild(chip);
        grupo.appendChild(btnEditar);
        grupo.appendChild(btnEliminar);
        chipsContainer.appendChild(grupo);
      });
    }
    pintarChips();
    chipsRefrescables.push(pintarChips);

    el.querySelector(".btn-toggle-preview").addEventListener("click", () => {
      const previewDiv = el.querySelector(".preview-whatsapp");
      const visible = previewDiv.style.display !== "none";
      previewDiv.style.display = visible ? "none" : "block";
      if (!visible) actualizarPreview(el, modulo);
    });

  } else {
    const infoDiv = el.querySelector(".archivo-info");
    if (modulo.ruta) {
      infoDiv.innerHTML = `${icono("clip",14)} ${modulo.nombre_archivo}`;
    }
    el.querySelector(".btn-seleccionar-archivo").addEventListener("click", async () => {
      const res = await api().seleccionar_archivo_adjunto();
      if (res && res.ok) {
        modulo.ruta = res.ruta;
        modulo.nombre_archivo = res.nombre_archivo;
        infoDiv.innerHTML = `${icono("clip",14)} ${res.nombre_archivo} (${res.tipo})`;
        actualizarResumen();
      }
    });
  }

  el.querySelector(".btn-eliminar-modulo").addEventListener("click", () => {
    seg.modulos = seg.modulos.filter(m => m.id !== modulo.id);
    el.remove();
    actualizarResumen();
  });

  // Drag and drop para reordenar -- solo el icono ⠿ inicia el arrastre
  // (antes toda la tarjeta era arrastrable, lo que interfería con los
  // clics en los botones de editar/eliminar dentro de ella).
  el.querySelector(".modulo-drag").addEventListener("dragstart", () => {
    dragInfo = { segmentoId: seg.id, moduloId: modulo.id };
    el.classList.add("dragging");
  });
  el.querySelector(".modulo-drag").addEventListener("dragend", () => el.classList.remove("dragging"));

  const contenedor = segEl.querySelector(".modulos-container");
  contenedor.appendChild(el);
}

function obtenerElementoDespuesDe(contenedor, y) {
  const elementos = [...contenedor.querySelectorAll(".modulo-card:not(.dragging)")];
  return elementos.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) {
      return { offset, element: child };
    } else {
      return closest;
    }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function actualizarPreview(moduloEl, modulo) {
  const previewDiv = moduloEl.querySelector(".preview-whatsapp");
  if (!previewDiv || previewDiv.style.display === "none") return;
  const contacto = (excelCargado && excelCargado.primer_contacto) || {};
  let texto = modulo.contenido || "";
  texto = texto.split("{Nombre}").join(contacto.Nombre || "Juan Pérez");
  texto = texto.split("{Empresa}").join(contacto.Empresa || "Tu Empresa");
  texto = texto.split("{Teléfono}").join(contacto.Contacto || "0999999999");
  texto = texto.split("{Telefono}").join(contacto.Contacto || "0999999999");
  previewDiv.textContent = texto || "(mensaje vacío)";
}

// =========================================================
// Plantillas
// =========================================================
async function cargarPlantillas() {
  plantillasCache = await api().listar_plantillas();
}

// Antes, agregar una nota/paso/recordatorio exigía haber dado clic en
// "Iniciar Campaña" primero -- lo cual no tenía sentido si todavía estás
// configurando. Ahora, la primera vez que se necesita, se crea un
// "Borrador" en segundo plano (silencioso), sin que el usuario tenga que
// hacer nada extra. Requiere que el Excel ya esté cargado (para poder
// calcular el total de contactos).
async function asegurarCampanaBorrador() {
  if (campanaActualId) return true;

  if (!excelCargado) {
    alert("Primero carga un archivo Excel de contactos.");
    return false;
  }

  const nombre = document.getElementById("input-nombre-campana").value || "Campaña sin nombre";
  const res = await api().crear_borrador(nombre);
  if (!res.ok) {
    alert(res.error);
    return false;
  }
  campanaActualId = res.campana_id;
  await sincronizarEstadoBoton();
  return true;
}

// =========================================================
// Notas de seguimiento
// =========================================================
document.getElementById("btn-agregar-nota").addEventListener("click", async () => {
  if (!(await asegurarCampanaBorrador())) return;
  const textarea = document.getElementById("input-nueva-nota");
  const texto = textarea.value.trim();
  if (!texto) return;
  const res = await api().agregar_nota(campanaActualId, texto);
  if (res.ok) {
    textarea.value = "";
    pintarNotas(document.getElementById("lista-notas"), res.notas);
  }
});

async function cargarNotas(campanaId) {
  if (!campanaId) {
    document.getElementById("lista-notas").innerHTML = "";
    return;
  }
  const notas = await api().listar_notas(campanaId);
  pintarNotas(document.getElementById("lista-notas"), notas);
}

function pintarNotas(container, notas, permitirEditar) {
  if (permitirEditar === undefined) permitirEditar = true;
  container.innerHTML = "";
  if (!notas || notas.length === 0) {
    container.innerHTML = `<div class="sin-notas">Sin notas todavía.</div>`;
    return;
  }
  notas.forEach(n => {
    const div = document.createElement("div");
    div.className = "nota-item";
    const fecha = (n.fecha || "").slice(0, 16).replace("T", " ");
    const acciones = permitirEditar
      ? `<div class="nota-acciones">
           <button class="btn-icon btn-editar-nota" title="Editar">${icono("lapiz", 13)}</button>
           <button class="btn-icon btn-eliminar-nota" title="Eliminar">${icono("papelera", 13)}</button>
         </div>`
      : "";
    div.innerHTML = `
      <div class="nota-fecha-fila">
        <span class="nota-fecha">${fecha}</span>
        ${acciones}
      </div>
      <div class="nota-texto">${escapeHtml(n.texto)}</div>
    `;

    if (permitirEditar) {
      div.querySelector(".btn-editar-nota").addEventListener("click", () => {
        const textoDiv = div.querySelector(".nota-texto");
        const btnEditar = div.querySelector(".btn-editar-nota");
        const valorActual = n.texto;

        const textarea = document.createElement("textarea");
        textarea.className = "input-text nota-textarea-edicion";
        textarea.value = valorActual;
        textoDiv.replaceWith(textarea);
        textarea.focus();

        btnEditar.innerHTML = icono("check", 13);
        btnEditar.title = "Guardar";

        const guardar = async () => {
          const res = await api().editar_nota(n.id, textarea.value.trim(), campanaActualId);
          if (res.ok) {
            pintarNotas(container, res.notas, true);
          } else {
            alert(res.error);
          }
        };
        btnEditar.replaceWith(btnEditar.cloneNode(true)); // limpia el listener viejo
        const nuevoBtnEditar = div.querySelector(".btn-editar-nota");
        nuevoBtnEditar.addEventListener("click", guardar);
        textarea.addEventListener("keydown", (e) => {
          if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); guardar(); }
        });
      });

      div.querySelector(".btn-eliminar-nota").addEventListener("click", async () => {
        const res = await api().eliminar_nota(n.id, campanaActualId);
        if (res.ok) pintarNotas(container, res.notas, true);
      });
    }

    container.appendChild(div);
  });
}

async function abrirModalNotas(campanaId, nombre) {
  document.getElementById("modal-notas-titulo").textContent = `Seguimiento — ${nombre}`;
  const datos = await api().datos_seguimiento_campana(campanaId);
  pintarNotas(document.getElementById("modal-notas-lista"), datos.notas, false);
  pintarChecklist(document.getElementById("modal-checklist-lista"), datos.pasos, campanaId, false);
  document.getElementById("modal-notas").style.display = "flex";
}
document.getElementById("btn-modal-notas-cerrar").addEventListener("click", () => {
  document.getElementById("modal-notas").style.display = "none";
});

// =========================================================
// Pestañas: Observaciones / Checklist
// =========================================================
document.querySelectorAll(".tab-seguimiento-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-seguimiento-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-seguimiento-contenido").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "checklist") cargarChipsPlantillasCampana();
  });
});

// =========================================================
// Checklist de pasos (dentro de "Crear Campaña")
// =========================================================
async function cargarChecklist(campanaId) {
  const contenedor = document.getElementById("checklist-lista");
  cargarChipsPlantillasCampana();
  if (!campanaId) {
    contenedor.innerHTML = "";
    return;
  }
  const pasos = await api().listar_pasos(campanaId);
  pintarChecklist(contenedor, pasos, campanaId, true);
  actualizarBotonSugerirRecordatorio(pasos);
}

// permitirEditar=true habilita el checkbox interactivo (pantalla de Crear Campaña);
// false lo deja de solo lectura (popup del Inicio).
function pintarChecklist(container, pasos, campanaId, permitirEditar) {
  container.innerHTML = "";
  if (!pasos || pasos.length === 0) {
    container.innerHTML = `<div class="sin-checklist">Sin pasos configurados todavía. Instala una plantilla de campaña o agrega pasos manuales.</div>`;
    return;
  }
  pasos.forEach(p => {
    const div = document.createElement("div");
    div.className = "checklist-item" + (p.completado ? " completado" : "");
    const fecha = p.fecha_completado ? `<span class="checklist-item-fecha">${p.fecha_completado.slice(0, 16).replace("T", " ")}</span>` : "";
    const acciones = permitirEditar
      ? `<button class="btn-icon btn-editar-paso" title="Editar">${icono("lapiz",14)}</button>
         <button class="btn-icon btn-eliminar-paso" title="Eliminar">${icono("papelera",14)}</button>`
      : "";
    div.innerHTML = `
      <input type="checkbox" ${p.completado ? "checked" : ""} ${permitirEditar ? "" : "disabled"}>
      <span class="checklist-item-titulo">${escapeHtml(p.titulo)}</span>
      ${fecha}
      ${acciones}
    `;
    if (permitirEditar) {
      div.querySelector("input[type=checkbox]").addEventListener("change", async (e) => {
        await api().marcar_paso(p.id, e.target.checked);
        cargarChecklist(campanaId);
      });

      div.querySelector(".btn-editar-paso").addEventListener("click", () => {
        const tituloSpan = div.querySelector(".checklist-item-titulo");
        const btnEditar = div.querySelector(".btn-editar-paso");

        const input = document.createElement("input");
        input.type = "text";
        input.className = "input-text checklist-input-edicion";
        input.value = p.titulo;
        tituloSpan.replaceWith(input);
        input.focus();
        input.select();

        btnEditar.innerHTML = icono("check", 14);
        btnEditar.title = "Guardar";

        const guardar = async () => {
          if (!input.value.trim()) return;
          const res = await api().editar_paso(p.id, input.value.trim(), campanaId);
          if (res.ok) pintarChecklist(container, res.pasos, campanaId, true);
          else alert(res.error);
        };
        const nuevoBtn = btnEditar.cloneNode(true);
        btnEditar.replaceWith(nuevoBtn);
        nuevoBtn.addEventListener("click", guardar);
        input.addEventListener("keydown", (e) => {
          if (e.key === "Enter") { e.preventDefault(); guardar(); }
        });
      });

      div.querySelector(".btn-eliminar-paso").addEventListener("click", async () => {
        if (!confirm(`¿Eliminar el paso "${p.titulo}"?`)) return;
        const res = await api().eliminar_paso(p.id, campanaId);
        if (res.ok) {
          pintarChecklist(container, res.pasos, campanaId, true);
          actualizarBotonSugerirRecordatorio(res.pasos);
        }
      });
    }
    container.appendChild(div);
  });
}

document.getElementById("btn-agregar-paso").addEventListener("click", async () => {
  if (!(await asegurarCampanaBorrador())) return;
  const input = document.getElementById("input-nuevo-paso");
  const titulo = input.value.trim();
  if (!titulo) return;
  const res = await api().agregar_paso(campanaActualId, titulo);
  if (res.ok) {
    input.value = "";
    pintarChecklist(document.getElementById("checklist-lista"), res.pasos, campanaActualId, true);
    actualizarBotonSugerirRecordatorio(res.pasos);
  }
});

// ---- Chips de plantillas de campaña ya instaladas (se instalan desde Información) ----
async function cargarChipsPlantillasCampana() {
  const contenedor = document.getElementById("plantillas-campana-chips");
  const plantillas = await api().listar_plantillas_campana_instaladas();

  contenedor.innerHTML = "";
  if (!plantillas || plantillas.length === 0) {
    contenedor.innerHTML = `<span class="muted-sm">Ninguna instalada todavía — ve a Información para instalar una.</span>`;
    return;
  }

  plantillas.forEach(p => {
    const chip = document.createElement("button");
    chip.className = "plantilla-chip";
    chip.textContent = p.nombre;
    chip.title = `${p.pasos.length} paso(s) — clic para aplicar`;
    chip.addEventListener("click", async () => {
      if (!(await asegurarCampanaBorrador())) return;

      const hayPasosPrevios = !document.querySelector("#checklist-lista .sin-checklist") &&
        document.getElementById("checklist-lista").children.length > 0;
      if (hayPasosPrevios && !confirm(`Esto reemplaza el checklist actual por el de "${p.nombre}". ¿Continuar?`)) {
        return;
      }

      const res = await api().aplicar_plantilla_campana(campanaActualId, p.id);
      if (!res.ok) { alert(res.error); return; }
      pintarChecklist(document.getElementById("checklist-lista"), res.pasos, campanaActualId, true);
      actualizarBotonSugerirRecordatorio(res.pasos);
    });
    contenedor.appendChild(chip);
  });
}

// =========================================================
// Recordatorios
// =========================================================
async function cargarRecordatorios(campanaId) {
  const contenedor = document.getElementById("lista-recordatorios");
  if (!campanaId) {
    contenedor.innerHTML = "";
    return;
  }
  const recordatorios = await api().listar_recordatorios(campanaId);
  pintarRecordatorios(recordatorios);
}

let recordatorioEditandoId = null;

function pintarRecordatorios(recordatorios) {
  const contenedor = document.getElementById("lista-recordatorios");
  contenedor.innerHTML = "";
  if (!recordatorios || recordatorios.length === 0) {
    contenedor.innerHTML = `<div class="sin-recordatorios">Sin recordatorios configurados.</div>`;
    return;
  }
  recordatorios.forEach(r => {
    const div = document.createElement("div");
    div.className = "recordatorio-item" + (r.disparado ? " disparado" : "");
    const fecha = (r.fecha_hora || "").replace("T", " ");
    div.innerHTML = `
      <div>
        <div class="recordatorio-fecha">${fecha}${r.disparado ? " · ya avisado" : ""}</div>
        <div>${escapeHtml(r.texto)}</div>
      </div>
      <div class="acciones-fila">
        <button class="btn-icon btn-editar-recordatorio" data-id="${r.id}" data-texto="${escapeHtml(r.texto)}" data-fecha="${r.fecha_hora}" title="Editar">${icono("lapiz",14)}</button>
        <button class="btn-icon btn-eliminar-recordatorio" data-id="${r.id}" title="Eliminar">${icono("papelera",14)}</button>
      </div>
    `;
    contenedor.appendChild(div);
  });

  document.querySelectorAll(".btn-eliminar-recordatorio").forEach(btn => {
    btn.addEventListener("click", async () => {
      const res = await api().eliminar_recordatorio(parseInt(btn.dataset.id), campanaActualId);
      if (res.ok) pintarRecordatorios(res.recordatorios);
    });
  });

  document.querySelectorAll(".btn-editar-recordatorio").forEach(btn => {
    btn.addEventListener("click", () => {
      recordatorioEditandoId = parseInt(btn.dataset.id);
      document.getElementById("input-recordatorio-texto").value = btn.dataset.texto;
      document.getElementById("input-recordatorio-fecha").value = btn.dataset.fecha;
      const btnAgregar = document.getElementById("btn-agregar-recordatorio");
      btnAgregar.innerHTML = `${icono("guardar",14)} Guardar cambios`;
      document.getElementById("btn-cancelar-edicion-recordatorio").style.display = "inline-flex";
      document.getElementById("input-recordatorio-texto").scrollIntoView({ behavior: "smooth", block: "center" });
    });
  });
}

function cancelarEdicionRecordatorio() {
  recordatorioEditandoId = null;
  document.getElementById("input-recordatorio-texto").value = "";
  document.getElementById("input-recordatorio-fecha").value = "";
  document.getElementById("btn-agregar-recordatorio").textContent = "+ Agregar";
  document.getElementById("btn-cancelar-edicion-recordatorio").style.display = "none";
}
document.getElementById("btn-cancelar-edicion-recordatorio").addEventListener("click", cancelarEdicionRecordatorio);

document.getElementById("btn-agregar-recordatorio").addEventListener("click", async () => {
  const inputTexto = document.getElementById("input-recordatorio-texto");
  const inputFecha = document.getElementById("input-recordatorio-fecha");
  if (!inputTexto.value.trim() || !inputFecha.value) {
    alert("Completa el texto y la fecha/hora del recordatorio.");
    return;
  }
  if (!(await asegurarCampanaBorrador())) return;

  const res = recordatorioEditandoId
    ? await api().editar_recordatorio(recordatorioEditandoId, inputTexto.value.trim(), inputFecha.value, campanaActualId)
    : await api().agregar_recordatorio(campanaActualId, inputTexto.value.trim(), inputFecha.value);

  if (res.ok) {
    cancelarEdicionRecordatorio();
    pintarRecordatorios(res.recordatorios);
  } else if (res.error) {
    alert(res.error);
  }
});

function actualizarBotonSugerirRecordatorio(pasos) {
  const btn = document.getElementById("btn-sugerir-recordatorio");
  const siguientePendiente = (pasos || []).find(p => !p.completado);
  if (!siguientePendiente) {
    btn.style.display = "none";
    return;
  }
  btn.style.display = "inline-flex";
  btn.onclick = () => {
    document.getElementById("input-recordatorio-texto").value = `Continuar: ${siguientePendiente.titulo}`;
    document.getElementById("input-recordatorio-fecha").focus();
  };
}

// Llamado desde Python cuando el hilo de fondo dispara un recordatorio.
// La notificación nativa de Windows ya se mostró desde Python; esto solo
// refresca la pantalla si corresponde (ej. si estás viendo el Inicio).
function appNuevoRecordatorio(titulo, mensaje) {
  const paginaHome = document.getElementById("page-home");
  if (paginaHome.classList.contains("active")) {
    cargarHome();
  }
  if (campanaActualId) {
    cargarRecordatorios(campanaActualId);
  }
}

// =========================================================
// Resumen / validación
// =========================================================
function calcularListo() {
  const segmentosValidos = segmentos.length > 0 &&
    segmentos.every(s => s.modulos.length > 0 &&
      s.modulos.every(m => m.tipo === "texto" ? m.contenido.trim() !== "" : m.ruta !== ""));
  return !!(excelCargado && segmentosValidos);
}

function actualizarResumen() {
  const totalSegmentos = segmentos.length;
  const totalContactos = excelCargado ? excelCargado.total : 0;

  document.getElementById("crear-subtitulo").textContent =
    `${totalSegmentos} segmento(s) · ${totalContactos} contactos en total`;

  const banner = document.getElementById("banner-listo");
  const bannerSub = document.getElementById("banner-sub");
  const bannerTitulo = banner.querySelector(".banner-titulo");

  const listo = calcularListo();

  if (listo) {
    banner.classList.remove("no-listo");
    bannerTitulo.textContent = "Listo para iniciar";
    bannerSub.textContent = `Se procesarán ${totalContactos} contactos en ${totalSegmentos} segmento(s).`;
  } else {
    banner.classList.add("no-listo");
    bannerTitulo.textContent = "Configura al menos un segmento para iniciar";
    bannerSub.textContent = !excelCargado
      ? "Falta cargar el Excel de contactos."
      : "Cada segmento necesita al menos un módulo completo (texto o archivo).";
  }

  actualizarBotonesEstado();
}

// =========================================================
// Botones: Iniciar / Pausar / Reanudar / Detener / Nueva / Reenviar errores
// =========================================================
function actualizarBotonesEstado() {
  const principales = [document.getElementById("btn-principal-top"), document.getElementById("btn-principal-bottom")];
  const finalizar = [document.getElementById("btn-detener-top"), document.getElementById("btn-detener-bottom")];

  const esFinalizada = (estadoBoton === "inactivo" && campanaActualId !== null && estadoDbActual === "Finalizada");

  let htmlBoton, habilitado;
  if (estadoBoton === "inactivo" && esFinalizada) {
    htmlBoton = `${icono("refrescar")} Reiniciar envíos`;
    habilitado = true;
  } else if (estadoBoton === "inactivo") {
    htmlBoton = `${icono("reproducir")} Iniciar Campaña`;
    habilitado = calcularListo();
  } else if (estadoBoton === "corriendo") {
    htmlBoton = `${icono("pausar")} Pausar`;
    habilitado = true;
  } else {
    htmlBoton = `${icono("reproducir")} Reanudar`;
    habilitado = true;
  }
  principales.forEach(b => { b.innerHTML = htmlBoton; b.disabled = !habilitado; });

  // "Finalizar" es fijo -- nunca cambia de texto, solo aparece mientras
  // hay algo enviando o pausado, y desaparece en Borrador/Finalizada.
  const puedeFinalizar = (estadoBoton === "corriendo" || estadoBoton === "pausado");
  finalizar.forEach(b => { b.style.display = puedeFinalizar ? "inline-flex" : "none"; });

  document.getElementById("btn-reenviar-errores").disabled = !esFinalizada;

  // "Cargar Excel" muta a "Actualizar Excel" cuando la campaña ya
  // terminó -- mismo botón, sin duplicar uno aparte.
  const btnExcel = document.getElementById("btn-cargar-excel");
  const avisoExcel = document.getElementById("excel-auto-msg");
  if (esFinalizada) {
    btnExcel.innerHTML = `${icono("documento")} Actualizar Excel`;
    avisoExcel.style.display = "block";
    avisoExcel.innerHTML =
      `${icono("alerta")} Si actualizas el Excel, la configuración de tu campaña se resetea ` +
      `(segmentos y mensajes se rearman desde cero), pero se mantiene toda la información de ` +
      `seguimiento (observaciones, checklist y recordatorios) -- para crear una segunda campaña ` +
      `anclada a la primera.`;
  } else {
    btnExcel.innerHTML = `${icono("documento")} Cargar Excel`;
    if (avisoExcel.dataset.modoFinalizada) {
      avisoExcel.style.display = "none";
      avisoExcel.innerHTML = "";
    }
  }
  avisoExcel.dataset.modoFinalizada = esFinalizada ? "1" : "";
}

// Consulta al backend la verdad sobre el estado de la campaña actual y
// ajusta estadoBoton en consecuencia. Se llama siempre que se carga o
// retoma una campaña, y cuando el hilo de envío termina -- nunca se asume
// el estado localmente, porque eso fue justamente el bug del botón que
// decía "Iniciar" en vez de "Reanudar".
async function sincronizarEstadoBoton() {
  if (!campanaActualId) {
    estadoBoton = "inactivo";
    hayHiloActivo = false;
    estadoDbActual = null;
    actualizarBotonesEstado();
    return;
  }

  const est = await api().estado_actual();
  hayHiloActivo = !!est.hay_hilo_activo;
  estadoDbActual = est.estado_db;

  if (est.hay_hilo_activo) {
    estadoBoton = est.pausado_activo ? "pausado" : "corriendo";
  } else if (est.es_reanudable) {
    // Quedó "Pausada" o "En curso" en la base de datos, pero no hay hilo
    // vivo en este proceso (se cerró el programa, o se detuvo del todo).
    // Se muestra "Reanudar" igual -- al hacer clic, se reutiliza el mismo
    // flujo de "Iniciar", que internamente continúa la misma campaña
    // porque campanaActualId ya está asignado.
    estadoBoton = "pausado";
  } else {
    // "Borrador" (todavía no se ha enviado nada) o "Finalizada".
    estadoBoton = "inactivo";
  }

  actualizarBotonesEstado();
}

function construirConfig() {
  const nombreCampana = document.getElementById("input-nombre-campana").value || "Campaña sin nombre";
  return {
    nombre_campana: nombreCampana,
    velocidad: "Normal",
    modo: modoCampana || "avanzada",
    segmentos: segmentos.map(s => ({
      nombre: s.nombre,
      desde: s.desde,
      hasta: s.hasta,
      cantidad: s.cantidad,
      modulos: s.modulos.map(m => m.tipo === "texto"
        ? { tipo: "texto", contenido: m.contenido }
        : { tipo: "archivo", ruta: m.ruta })
    }))
  };
}

async function onClickPrincipal() {
  const esFinalizada = (estadoBoton === "inactivo" && campanaActualId !== null && estadoDbActual === "Finalizada");

  if (esFinalizada) {
    await reiniciarEnvios();
  } else if (estadoBoton === "inactivo") {
    await manejarIniciar();
  } else if (estadoBoton === "corriendo") {
    await api().pausar_campana();
    estadoBoton = "pausado";
    actualizarBotonesEstado();
    detenerTramoTimerCampana();
    appLog("⏸ Pausada por el usuario. Puedes editar los segmentos y luego reanudar.");
    await refrescarResumenEnvios();
  } else if (estadoBoton === "pausado") {
    if (hayHiloActivo) {
      // Pausa real, dentro de la misma sesión: el motor sigue vivo en
      // memoria esperando, solo hay que avisarle que continúe.
      const config = construirConfig();
      const res = await api().reanudar_campana(config);
      if (!res.ok) { alert(res.error); return; }
      hayHiloActivo = true;
      estadoBoton = "corriendo";
      actualizarBotonesEstado();
      iniciarOReanudarTimerCampana();
    } else {
      // No hay hilo vivo (se cerró el programa, o se detuvo del todo).
      // Se usa el mismo flujo de "Iniciar", que continúa la misma
      // campaña porque campanaActualId ya está asignado.
      await manejarIniciar();
    }
  }
}

async function manejarIniciar() {
  const config = construirConfig();
  const chequeo = await api().chequeo_previo(config.segmentos);

  if (chequeo.ok) {
    mostrarModalChequeo(chequeo, () => lanzarCampana(config));
  } else {
    await lanzarCampana(config);
  }
}

async function lanzarCampana(config) {
  limpiarLog();
  const res = await api().iniciar_campana(config);
  if (!res.ok) {
    alert(res.error || "No se pudo iniciar la campaña");
    return;
  }
  campanaActualId = res.campana_id;
  hayHiloActivo = true;
  estadoBoton = "corriendo";
  actualizarBotonesEstado();
  iniciarOReanudarTimerCampana();
  cargarNotas(campanaActualId);
  cargarChecklist(campanaActualId);
  cargarRecordatorios(campanaActualId);
}

[document.getElementById("btn-principal-top"), document.getElementById("btn-principal-bottom")]
  .forEach(btn => btn.addEventListener("click", onClickPrincipal));

// ---- Ventana de diagnóstico técnico (aparte, para depurar el motor de envío) ----
let diagnosticoAbierto = false;
document.getElementById("btn-diagnostico-toggle").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  if (!diagnosticoAbierto) {
    btn.disabled = true;
    const res = await api().abrir_ventana_diagnostico();
    btn.disabled = false;
    if (!res.ok) {
      alert("No se pudo abrir la ventana de diagnóstico.");
      return;
    }
    diagnosticoAbierto = true;
    btn.textContent = "🔧 Cerrar diagnóstico";
    btn.title = res.ruta_log ? `Se está guardando en: ${res.ruta_log}` : "";
  } else {
    await api().cerrar_ventana_diagnostico();
    diagnosticoAbierto = false;
    btn.textContent = "🔧 Diagnóstico";
    btn.title = "Ventana técnica en vivo, para depurar el motor de envío";
  }
});

[document.getElementById("btn-detener-top"), document.getElementById("btn-detener-bottom")]
  .forEach(btn => btn.addEventListener("click", async () => {
    if (!confirm(
      "Esto termina la campaña de forma definitiva. Los contactos que todavía no hayan " +
      "recibido el mensaje se quedarán sin mandarles nada. ¿Confirmas que quieres finalizar?"
    )) return;
    const res = await api().finalizar_campana();
    if (!res.ok) { alert(res.error); return; }
    appLog("⏹ Campaña finalizada por el usuario.");
    await sincronizarEstadoBoton();
    await refrescarResumenEnvios();
  }));

document.getElementById("btn-reenviar-errores").addEventListener("click", manejarIniciar);

async function reiniciarEnvios() {
  if (!confirm(
    "Esto vuelve a marcar TODOS los contactos de este Excel como pendientes " +
    "(no se toca el texto de los mensajes ni los segmentos que ya configuraste). " +
    "¿Continuar?"
  )) return;

  const res = await api().reiniciar_envios_campana();
  if (!res.ok) {
    alert(res.error);
    return;
  }
  await sincronizarEstadoBoton();
  actualizarResumen();
  alert("Listo -- todos los contactos quedaron pendientes de nuevo. Ya puedes darle 'Iniciar Campaña'.");
}

// Llamado desde Python cuando el hilo de la campaña termina
// (ya sea porque acabó de forma natural o porque se detuvo)
async function appCampanaFinalizada() {
  // No se asume "inactivo" a ciegas: se pregunta al backend si terminó
  // de verdad (Finalizada) o si quedó interrumpida (Pausada, por ejemplo
  // si se usó "Detener"), para mostrar el botón correcto sin salir de la
  // pantalla.
  detenerTramoTimerCampana();
  await sincronizarEstadoBoton();
  await refrescarResumenEnvios();
  cargarHome();
}

// Vuelve a leer de la base de datos cuántos quedaron Enviado/Error/Sin
// confirmar para ESTA campaña -- se usa para que el contador en
// pantalla quede al día apenas el hilo termina (por cualquier motivo),
// sin tener que salir a Home y volver para que se note.
async function refrescarResumenEnvios() {
  if (!campanaActualId) return;
  const res = await api().resumen_envios_actual();
  if (!res.ok) return;

  // Se reusa el total que ya estaba en pantalla (puesto ahí en vivo por
  // appProgreso durante el envío) -- solo se corrige el numerador con
  // el conteo real de la base de datos, que es la fuente de verdad.
  const textoActual = document.getElementById("progreso-texto").textContent || "0 / 0";
  const total = parseInt(textoActual.split("/")[1]) || res.total_procesados;

  const pct = total > 0 ? Math.round((res.total_procesados / total) * 100) : 0;
  document.getElementById("progreso-fill").style.width = pct + "%";
  document.getElementById("progreso-texto").textContent = `${res.total_procesados} / ${total}`;
  appLog(`📊 Resumen actualizado -- Enviados: ${res.Enviado} · Errores: ${res.Error} · Sin confirmar: ${res["Sin confirmar"]}`);
}

// =========================================================
// Modal: chequeo previo
// =========================================================
function mostrarModalChequeo(chequeo, onContinuar) {
  const contenido = document.getElementById("modal-chequeo-contenido");
  contenido.innerHTML = "";

  const filas = [
    { label: "Total de contactos en el Excel", valor: chequeo.total, alerta: false },
    { label: "Pendientes por enviar", valor: chequeo.pendientes, alerta: false },
    { label: "Ya marcados como enviados (se omiten)", valor: chequeo.ya_enviados, alerta: false },
    { label: "Números inválidos (se omitirán)", valor: chequeo.invalidos, alerta: chequeo.invalidos > 0 },
    { label: "Números duplicados en el Excel", valor: chequeo.duplicados, alerta: chequeo.duplicados > 0 },
    { label: "Sin segmento asignado (se omitirán)", valor: chequeo.sin_segmento, alerta: chequeo.sin_segmento > 0 },
  ];
  filas.forEach(f => {
    const div = document.createElement("div");
    div.className = "chequeo-item" + (f.alerta ? " chequeo-alerta" : "");
    div.innerHTML = `<span>${f.label}</span><b>${f.valor}</b>`;
    contenido.appendChild(div);
  });

  document.getElementById("modal-chequeo").style.display = "flex";

  const btnContinuarViejo = document.getElementById("btn-chequeo-continuar");
  const btnCancelarViejo = document.getElementById("btn-chequeo-cancelar");
  const btnContinuar = btnContinuarViejo.cloneNode(true);
  const btnCancelar = btnCancelarViejo.cloneNode(true);
  btnContinuarViejo.parentNode.replaceChild(btnContinuar, btnContinuarViejo);
  btnCancelarViejo.parentNode.replaceChild(btnCancelar, btnCancelarViejo);

  const cerrar = () => { document.getElementById("modal-chequeo").style.display = "none"; };
  btnContinuar.addEventListener("click", () => { cerrar(); onContinuar(); });
  btnCancelar.addEventListener("click", cerrar);
}

// =========================================================
// Log y progreso (llamados desde Python)
// =========================================================
function limpiarLog() {
  document.getElementById("log-box").innerHTML = "";
  document.getElementById("progreso-fill").style.width = "0%";
  document.getElementById("progreso-texto").textContent = "0 / 0";
  reiniciarTimerCampana();
}

function appLog(texto) {
  const box = document.getElementById("log-box");
  const linea = document.createElement("div");

  let html = texto.replace(/\*\*(.*?)\*\*/g, "<b>$1</b>");
  if (texto.includes("❌")) linea.classList.add("log-line-error");
  if (texto.includes("✅") || texto.includes("🎉")) linea.classList.add("log-line-ok");

  linea.innerHTML = html;
  box.appendChild(linea);
  box.scrollTop = box.scrollHeight;
}

function appProgreso(actual, total) {
  const pct = total > 0 ? Math.round((actual / total) * 100) : 0;
  document.getElementById("progreso-fill").style.width = pct + "%";
  document.getElementById("progreso-texto").textContent = `${actual} / ${total}`;
}

// ---- Cronómetro de la campaña (tiempo total que toma el envío) ----
// Acumula por tramos porque una campaña puede pausarse y reanudarse
// varias veces -- el reloj se detiene mientras está en pausa y sigue
// sumando cuando se reanuda, en vez de reiniciarse.
let campTimerInterval = null;
let campTimerInicioTramo = null;
let campTimerAcumulado = 0;

function reiniciarTimerCampana() {
  detenerTramoTimerCampana();
  campTimerAcumulado = 0;
  document.getElementById("progreso-tiempo").textContent = "00:00";
}

function iniciarOReanudarTimerCampana() {
  if (campTimerInterval) return; // ya está corriendo
  campTimerInicioTramo = Date.now();
  campTimerInterval = setInterval(() => {
    const total = campTimerAcumulado + Math.floor((Date.now() - campTimerInicioTramo) / 1000);
    document.getElementById("progreso-tiempo").textContent = formatearDuracion(total);
  }, 1000);
}

function detenerTramoTimerCampana() {
  if (campTimerInterval) {
    campTimerAcumulado += Math.floor((Date.now() - campTimerInicioTramo) / 1000);
    clearInterval(campTimerInterval);
    campTimerInterval = null;
  }
}
// (formatearDuracion ya está definida más abajo, junto al cronómetro de licencias)

// =========================================================
// DASHBOARD
// =========================================================
const NOMBRES_MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio",
  "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];

function formatearMes(mesStr) {
  const [anio, mes] = mesStr.split("-");
  return `${NOMBRES_MESES[parseInt(mes) - 1]} ${anio}`;
}

async function cargarDashboard() {
  const selectMes = document.getElementById("filtro-dashboard-mes");
  const mesActual = new Date().toISOString().slice(0, 7);

  // Solo se llena la lista de meses una vez (si ya tiene opciones, no se
  // vuelve a pedir -- evita perder la selección del usuario al refrescar).
  if (selectMes.options.length === 0) {
    let meses = await api().dashboard_meses_disponibles();
    if (!meses.includes(mesActual)) meses = [mesActual, ...meses];
    selectMes.innerHTML = meses.map(m => `<option value="${m}">${formatearMes(m)}</option>`).join("");
    selectMes.value = mesActual;
    selectMes.addEventListener("change", cargarDashboard);
  }

  const mesSeleccionado = selectMes.value || mesActual;
  const esMesActual = mesSeleccionado === mesActual;

  document.getElementById("dashboard-subtitulo").textContent = esMesActual
    ? "Resumen general de tus campañas"
    : `Viendo el resumen de ${formatearMes(mesSeleccionado)}`;
  document.getElementById("label-stat-enviados").textContent =
    "TOTAL ENVIADOS" + (esMesActual ? " (MES)" : ` (${formatearMes(mesSeleccionado).toUpperCase()})`);

  const stats = await api().dashboard_stats(mesSeleccionado);
  document.getElementById("stat-enviados").textContent = stats.total_enviados_mes;
  document.getElementById("stat-tasa").textContent = stats.tasa_entrega + "%";
  document.getElementById("stat-campanas").textContent = stats.campanas_activas;
  document.getElementById("stat-contactos").textContent = stats.contactos_totales;

  const resumenContactos = await api().contactos_resumen();
  document.getElementById("stat-contactos-seguimiento").textContent = resumenContactos.total;
  document.getElementById("stat-contactos-desglose").textContent =
    `${resumenContactos.Contactado} contactados · ${resumenContactos.Interesado} interesados · ` +
    `${resumenContactos.Cliente} clientes · ${resumenContactos.Perdido} perdidos`;

  const ic = await api().dashboard_inteligencia_comercial();
  document.getElementById("ic-producto-top").textContent = ic.producto_mas_vendido
    ? `${ic.producto_mas_vendido.nombre} (${ic.producto_mas_vendido.total} ventas)` : "Sin datos aún";
  document.getElementById("ic-queja-top").textContent = ic.motivo_queja_mas_comun
    ? `${ic.motivo_queja_mas_comun.nombre} (${ic.motivo_queja_mas_comun.total})` : "Sin datos aún";
  document.getElementById("ic-compradores").textContent = ic.compradores_unicos;

  const historial = await api().dashboard_historial();
  const tbodyHist = document.querySelector("#tabla-historial tbody");
  tbodyHist.innerHTML = "";
  if (historial.length === 0) {
    tbodyHist.innerHTML = `<tr><td colspan="3" class="muted">Sin datos aún</td></tr>`;
  } else {
    historial.forEach(h => {
      tbodyHist.innerHTML += `<tr><td>${formatearMes(h.mes)}</td><td>${h.enviados}</td><td>${h.total}</td></tr>`;
    });
  }

  const top = await api().dashboard_top_contactos();
  const tbodyTop = document.querySelector("#tabla-top tbody");
  tbodyTop.innerHTML = "";
  if (top.length === 0) {
    tbodyTop.innerHTML = `<tr><td colspan="4" class="muted">Sin datos aún</td></tr>`;
  } else {
    top.forEach(t => {
      tbodyTop.innerHTML += `<tr><td><b>${escapeHtml(t.nombre)}</b></td><td>${t.numero}</td><td>${t.total_mensajes}</td><td>${(t.ultimo_envio || "").slice(0, 16)}</td></tr>`;
    });
  }
}

// =========================================================
// DASHBOARD: comparativo de 2 meses
// =========================================================
document.getElementById("btn-abrir-comparativo").addEventListener("click", async () => {
  const mesActual = new Date().toISOString().slice(0, 7);
  let meses = await api().dashboard_meses_disponibles();
  if (!meses.includes(mesActual)) meses = [mesActual, ...meses];

  const opciones = meses.map(m => `<option value="${m}">${formatearMes(m)}</option>`).join("");
  const selectA = document.getElementById("comparativo-mes-a");
  const selectB = document.getElementById("comparativo-mes-b");
  selectA.innerHTML = opciones;
  selectB.innerHTML = opciones;
  selectA.value = meses[1] || meses[0];
  selectB.value = meses[0];

  document.getElementById("comparativo-resultado").style.display = "none";
  document.getElementById("modal-comparativo").style.display = "flex";
});

document.getElementById("btn-cerrar-comparativo").addEventListener("click", () => {
  document.getElementById("modal-comparativo").style.display = "none";
});

document.getElementById("btn-generar-comparativo").addEventListener("click", async () => {
  const mesA = document.getElementById("comparativo-mes-a").value;
  const mesB = document.getElementById("comparativo-mes-b").value;

  const [statsA, statsB] = await Promise.all([
    api().dashboard_stats(mesA),
    api().dashboard_stats(mesB),
  ]);

  document.getElementById("comparativo-th-a").textContent = formatearMes(mesA);
  document.getElementById("comparativo-th-b").textContent = formatearMes(mesB);

  const filas = [
    { etiqueta: "Total enviados", a: statsA.total_enviados_mes, b: statsB.total_enviados_mes },
    { etiqueta: "Tasa de entrega", a: statsA.tasa_entrega + "%", b: statsB.tasa_entrega + "%" },
    { etiqueta: "Contactos totales", a: statsA.contactos_totales, b: statsB.contactos_totales },
  ];

  const tbody = document.querySelector("#comparativo-tabla tbody");
  tbody.innerHTML = filas.map(f => `<tr><td>${f.etiqueta}</td><td><b>${f.a}</b></td><td><b>${f.b}</b></td></tr>`).join("");

  // Gráfico simple de barras horizontales, comparando los mismos 3 valores
  const grafico = document.getElementById("comparativo-grafico");
  const metricas = [
    { etiqueta: "Enviados", a: statsA.total_enviados_mes, b: statsB.total_enviados_mes },
    { etiqueta: "Tasa entrega %", a: statsA.tasa_entrega, b: statsB.tasa_entrega },
    { etiqueta: "Contactos", a: statsA.contactos_totales, b: statsB.contactos_totales },
  ];
  const maximo = Math.max(1, ...metricas.map(m => Math.max(m.a, m.b)));

  grafico.innerHTML = metricas.map(m => `
    <div class="comparativo-barra-fila">
      <span class="comparativo-barra-etiqueta">${m.etiqueta}</span>
      <div class="comparativo-barra-pista">
        <div class="comparativo-barra-relleno comparativo-barra-a" style="width:${(m.a / maximo) * 100}%">${m.a}</div>
      </div>
    </div>
    <div class="comparativo-barra-fila">
      <span class="comparativo-barra-etiqueta"></span>
      <div class="comparativo-barra-pista">
        <div class="comparativo-barra-relleno comparativo-barra-b" style="width:${(m.b / maximo) * 100}%">${m.b}</div>
      </div>
    </div>
  `).join("");

  document.getElementById("comparativo-resultado").style.display = "block";
});

// =========================================================
// SEGUIMIENTO -- pantalla de inicio + tablero por campaña
// =========================================================
let fichaNumeroActual = null;
let campanaTableroActualId = null;
let columnaOrigenParaCampana = null; // {id, nombre} cuando el selector de modo se abrió desde el menú de una columna

document.addEventListener("click", () => {
  document.querySelectorAll(".kanban-columna-menu.abierto").forEach(m => m.classList.remove("abierto"));
  document.querySelectorAll(".tag-btn-menu").forEach(m => { m.style.display = "none"; });
});

// ---- Pantalla de inicio: resumen general + selector de campañas ----
async function cargarSeguimiento() {
  document.getElementById("seguimiento-tablero").style.display = "none";
  document.getElementById("seguimiento-inicio").style.display = "block";

  const resumen = await api().resumen_general_seguimiento();
  document.getElementById("stat-seg-campanas").textContent = resumen.campanas_ejecutadas;
  document.getElementById("stat-seg-contactos").textContent = resumen.contactos_totales;
  document.getElementById("stat-seg-mensajes").textContent = resumen.mensajes_enviados;
  document.getElementById("stat-seg-activos").textContent = resumen.contactos_activos;

  const hora = new Date().getHours();
  const saludo = hora < 12 ? "Buenos días" : (hora < 19 ? "Buenas tardes" : "Buenas noches");
  document.getElementById("seguimiento-saludo").textContent = saludo;

  const destacado = document.getElementById("seguimiento-destacado");
  const ultima = await api().ultima_actividad_kanban();
  if (ultima) {
    destacado.style.display = "flex";
    const fecha = new Date(ultima.fecha_actualizacion);
    const horasDesde = Math.max(0, Math.round((Date.now() - fecha.getTime()) / 3600000));
    const cuando = horasDesde < 1 ? "hace unos minutos" : (horasDesde < 24 ? `hace ${horasDesde} hora(s)` : `hace ${Math.round(horasDesde / 24)} día(s)`);
    destacado.innerHTML = `${icono("destacar", 16)} Última actividad: <b>${escapeHtml(ultima.contacto_nombre || ultima.numero)}</b> pasó a ` +
      `<b>${escapeHtml(ultima.columna_nombre)}</b> ${cuando}, en la campaña "${escapeHtml(ultima.campana_nombre)}".`;
  } else {
    destacado.style.display = "none";
  }

  const tarjetas = await api().resumen_por_campana();
  const grid = document.getElementById("seguimiento-campanas-grid");
  grid.innerHTML = "";
  if (tarjetas.length === 0) {
    grid.innerHTML = `<div class="muted" style="margin-left:0;">Todavía no has enviado ninguna campaña.</div>`;
    return;
  }

  const coloresBarra = ["#888780", "#378ADD", "#EF9F27", "#639922", "#E24B4A", "#D4537E", "#7F77DD"];
  tarjetas.forEach(t => {
    const card = document.createElement("div");
    card.className = "seguimiento-campana-card";
    const barras = t.distribucion.map((d, i) => {
      const pct = t.total_contactos > 0 ? (d.total / t.total_contactos) * 100 : 0;
      if (pct === 0) return "";
      const color = coloresBarra[i % coloresBarra.length];
      return `<div style="width:${pct}%; background:${color};" title="${escapeHtml(d.columna)}: ${d.total}"></div>`;
    }).join("");

    let cuando = "sin actividad todavía";
    if (t.ultima_actividad) {
      const horas = Math.max(0, Math.round((Date.now() - new Date(t.ultima_actividad).getTime()) / 3600000));
      cuando = horas < 24 ? `hace ${horas} hora(s)` : `hace ${Math.round(horas / 24)} día(s)`;
    }

    card.innerHTML = `
      <div class="seguimiento-campana-nombre">${escapeHtml(t.nombre)}</div>
      <div class="seguimiento-campana-meta">${t.total_contactos} contacto(s) · ${cuando}</div>
      <div class="seguimiento-campana-barra">${barras}</div>
    `;
    card.addEventListener("click", () => abrirTableroCampana(t.id, t.nombre));
    grid.appendChild(card);
  });
}

document.getElementById("btn-volver-seguimiento").addEventListener("click", cargarSeguimiento);

// ---- Tablero de una campaña específica (columnas editables) ----
async function abrirTableroCampana(campanaId, nombreCampana) {
  campanaTableroActualId = campanaId;
  document.getElementById("seguimiento-inicio").style.display = "none";
  document.getElementById("seguimiento-tablero").style.display = "block";
  document.getElementById("seguimiento-tablero-titulo").textContent = nombreCampana;

  const selector = document.getElementById("selector-campana-tablero");
  if (selector.options.length === 0) {
    const campanas = await api().listar_campanas_home();
    selector.innerHTML = campanas.map(c => `<option value="${c.id}">${escapeHtml(c.nombre)}</option>`).join("");
    selector.addEventListener("change", () => {
      const opt = selector.options[selector.selectedIndex];
      abrirTableroCampana(parseInt(selector.value), opt.textContent);
    });
  }
  selector.value = campanaId;

  await renderTableroCampana();
}

async function renderTableroCampana() {
  const datos = await api().contactos_de_campana_agrupados(campanaTableroActualId);
  const contenedor = document.getElementById("kanban-board-container");
  contenedor.innerHTML = "";

  datos.columnas.forEach(columna => {
    const contactosDeEstaCol = datos.por_columna[columna.id] || [];

    const div = document.createElement("div");
    div.className = "kanban-columna";
    div.dataset.columnaId = columna.id;

    const header = document.createElement("div");
    header.className = "kanban-columna-header";
    header.innerHTML = `
      <div class="kanban-columna-header-izq">
        <span class="kanban-columna-nombre">${escapeHtml(columna.nombre)}</span>
        <button class="btn-icon btn-editar-columna" title="Renombrar">${icono("lapiz", 12)}</button>
        <button class="btn-icon btn-eliminar-columna" title="Eliminar">${icono("papelera", 12)}</button>
        <div class="kanban-columna-menu-wrap">
          <button class="btn-icon btn-menu-columna" title="Más opciones">${icono("masOpciones", 13)}</button>
          <div class="kanban-columna-menu">
            <button class="kanban-columna-menu-item btn-exportar-columna">${icono("descargar", 13)} Exportar Excel de esta columna</button>
            <button class="kanban-columna-menu-item btn-crear-campana-columna">${icono("mensaje", 13)} Crear campaña con estos contactos</button>
          </div>
        </div>
      </div>
      <span class="kanban-columna-contador">${contactosDeEstaCol.length}</span>
    `;

    const menu = header.querySelector(".kanban-columna-menu");
    header.querySelector(".btn-menu-columna").addEventListener("click", (e) => {
      e.stopPropagation();
      const yaAbierto = menu.classList.contains("abierto");
      document.querySelectorAll(".kanban-columna-menu.abierto").forEach(m => m.classList.remove("abierto"));
      if (!yaAbierto) menu.classList.add("abierto");
    });

    header.querySelector(".btn-exportar-columna").addEventListener("click", async (e) => {
      e.stopPropagation();
      menu.classList.remove("abierto");
      const res = await api().exportar_columna_excel(columna.id, columna.nombre);
      if (!res.ok) {
        if (res.error) alert(res.error);
        return;
      }
      alert(`Listo -- Excel con ${res.total} contacto(s) guardado en:\n${res.ruta}`);
    });

    header.querySelector(".btn-crear-campana-columna").addEventListener("click", (e) => {
      e.stopPropagation();
      menu.classList.remove("abierto");
      columnaOrigenParaCampana = { id: columna.id, nombre: columna.nombre };
      document.getElementById("modal-modo-campana").style.display = "flex";
    });

    header.querySelector(".btn-editar-columna").addEventListener("click", () => {
      const nombreSpan = header.querySelector(".kanban-columna-nombre");
      const btnEditar = header.querySelector(".btn-editar-columna");
      const input = document.createElement("input");
      input.type = "text";
      input.className = "kanban-columna-nombre-input";
      input.value = columna.nombre;
      nombreSpan.replaceWith(input);
      input.focus();
      input.select();
      btnEditar.innerHTML = icono("check", 12);

      const guardar = async () => {
        if (!input.value.trim()) return;
        await api().editar_columna_kanban(columna.id, input.value.trim(), campanaTableroActualId);
        renderTableroCampana();
      };
      const nuevoBtn = btnEditar.cloneNode(true);
      btnEditar.replaceWith(nuevoBtn);
      nuevoBtn.addEventListener("click", guardar);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); guardar(); } });
    });

    header.querySelector(".btn-eliminar-columna").addEventListener("click", async () => {
      if (!confirm(`¿Eliminar la columna "${columna.nombre}"?`)) return;
      const res = await api().eliminar_columna_kanban(columna.id, campanaTableroActualId);
      if (!res.ok) { alert(res.error); return; }
      renderTableroCampana();
    });

    const lista = document.createElement("div");
    lista.className = "kanban-columna-lista";

    if (contactosDeEstaCol.length === 0) {
      lista.innerHTML = `<div class="kanban-columna-vacia">Sin contactos aquí</div>`;
    } else {
      contactosDeEstaCol.forEach(c => lista.appendChild(crearTarjetaContacto(c)));
    }

    lista.addEventListener("dragover", (e) => {
      e.preventDefault();
      lista.classList.add("arrastrando-encima");
    });
    lista.addEventListener("dragleave", () => lista.classList.remove("arrastrando-encima"));
    lista.addEventListener("drop", async (e) => {
      e.preventDefault();
      lista.classList.remove("arrastrando-encima");
      const numero = e.dataTransfer.getData("text/plain");
      if (!numero) return;
      await api().mover_contacto_columna(campanaTableroActualId, numero, columna.id);
      renderTableroCampana();
    });

    div.appendChild(header);
    div.appendChild(lista);
    contenedor.appendChild(div);
  });
}

document.getElementById("btn-agregar-columna").addEventListener("click", async () => {
  const nombre = prompt("Nombre de la columna nueva:");
  if (!nombre || !nombre.trim()) return;
  await api().agregar_columna_kanban(campanaTableroActualId, nombre.trim());
  renderTableroCampana();
});

function crearTarjetaContacto(c) {
  const div = document.createElement("div");
  div.className = "kanban-card";
  div.draggable = true;

  const fecha = (c.fecha_ultima_actividad || "").slice(0, 10);
  const etiquetasHtml = (c.etiquetas && c.etiquetas.length > 0)
    ? `<div class="kanban-card-etiquetas">${c.etiquetas.map(e => `<span class="kanban-card-etiqueta">${escapeHtml(e)}</span>`).join("")}</div>`
    : "";

  div.innerHTML = `
    <div class="kanban-card-header">
      <div>
        <div class="kanban-card-nombre">${escapeHtml(c.nombre || c.numero)}</div>
        <div class="kanban-card-numero">${c.numero}</div>
      </div>
      <div style="display:flex; align-items:center; gap:6px;">
        <span class="kanban-card-salud ${c.salud || "verde"}" title="Salud del contacto: ${c.salud || "verde"}"></span>
        <button class="btn-icon kanban-card-whatsapp" title="Abrir WhatsApp">${icono("mensaje", 15)}</button>
      </div>
    </div>
    ${c.empresa ? `<div class="kanban-card-empresa">${escapeHtml(c.empresa)}</div>` : ""}
    ${etiquetasHtml}
    ${c.producto_favorito ? `<div class="kanban-card-favorito">${icono("destacar", 11)} Favorito: ${escapeHtml(c.producto_favorito.producto)}</div>` : ""}
    <div class="kanban-card-tarea-zona"></div>
    <div class="kanban-card-obs-zona"></div>
    <div class="kanban-card-fecha">Últ. actividad: ${fecha}</div>
  `;

  div.querySelector(".kanban-card-whatsapp").addEventListener("click", async (e) => {
    e.stopPropagation();
    const btn = e.currentTarget;
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = "…";
    const res = await api().abrir_whatsapp_contacto(c.numero_completo || c.numero);
    btn.disabled = false;
    btn.innerHTML = original;
    if (!res.ok) alert(res.error);
    else if (res.aviso) alert(res.aviso);
  });

  pintarTareasEnTarjeta(div.querySelector(".kanban-card-tarea-zona"), c);

  const zonaObs = div.querySelector(".kanban-card-obs-zona");
  if (c.ultima_observacion) {
    zonaObs.innerHTML = `<div class="kanban-card-obs-preview">${icono("lapiz", 11)} <span>${escapeHtml(c.ultima_observacion)}</span></div>`;
  }

  div.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/plain", c.numero);
    div.classList.add("dragging");
  });
  div.addEventListener("dragend", () => div.classList.remove("dragging"));
  div.addEventListener("click", () => abrirFichaContacto(c.numero));

  return div;
}

// Se muestran TODAS las tareas (pendientes y ya completadas) -- así
// nunca "desaparece" el rastro de lo que ya se hizo. Marcar una
// pendiente se puede hacer directo aquí (a propósito, rápido); una vez
// marcada, la casilla queda deshabilitada -- para desmarcarla hay que
// entrar a la ficha completa, así no se deshace nada por accidente.
function pintarTareasEnTarjeta(zona, c) {
  const tareas = c.tareas || [];
  if (tareas.length === 0) {
    zona.innerHTML = "";
    return;
  }

  zona.innerHTML = tareas.map(t => `
    <div class="kanban-card-tarea ${t.completado ? "completada" : ""}" data-tarea-id="${t.id}">
      <input type="checkbox" ${t.completado ? "checked disabled" : ""}>
      <span>${escapeHtml(t.titulo)}</span>
    </div>
  `).join("");

  zona.querySelectorAll(".kanban-card-tarea input[type=checkbox]:not(:disabled)").forEach(checkbox => {
    checkbox.addEventListener("click", (e) => e.stopPropagation());
    checkbox.addEventListener("change", async (e) => {
      if (!e.target.checked) return;
      const fila = e.target.closest(".kanban-card-tarea");
      fila.classList.add("completada");
      e.target.disabled = true;
      const tareaId = parseInt(fila.dataset.tareaId);
      await api().marcar_tarea_contacto(tareaId, true, c.numero);

      // En vez de abrir la ficha completa, se ofrece dejar una observación
      // rápida ahí mismo -- va al mismo bloque de Observaciones de la
      // ficha, no es un sistema aparte.
      const cajaObs = document.createElement("div");
      cajaObs.className = "kanban-card-obs-rapida";
      cajaObs.innerHTML = `
        <textarea rows="2" placeholder="¿Cómo te fue? (opcional)"></textarea>
        <button class="btn btn-sm btn-outline">Guardar</button>
      `;
      cajaObs.querySelector("textarea").addEventListener("click", (ev) => ev.stopPropagation());
      cajaObs.querySelector("textarea").addEventListener("mousedown", (ev) => ev.stopPropagation());
      cajaObs.querySelector("button").addEventListener("click", async (ev) => {
        ev.stopPropagation();
        const texto = cajaObs.querySelector("textarea").value.trim();
        if (texto) await api().agregar_nota_contacto(c.numero, texto);
        renderTableroCampana();
      });
      fila.after(cajaObs);
    });
  });
}

// ---- Ficha de contacto ----
let fichaNumeroCompletoActual = null;

async function abrirFichaContacto(numero) {
  const c = await api().obtener_contacto(numero);
  if (!c) return;
  fichaNumeroActual = c.numero;
  fichaNumeroCompletoActual = c.numero_completo || c.numero;

  document.getElementById("ficha-nombre").textContent = c.nombre || "(sin nombre)";
  document.getElementById("ficha-numero").textContent = c.numero;
  document.getElementById("ficha-input-empresa").value = c.empresa || "";
  document.getElementById("ficha-input-correo").value = c.correo || "";
  document.getElementById("ficha-input-direccion").value = c.direccion || "";
  document.getElementById("ficha-input-ciudad").value = c.ciudad || "";
  document.getElementById("ficha-datos-guardado").style.display = "none";

  const todasEtiquetas = await api().listar_etiquetas();
  document.getElementById("lista-etiquetas-existentes").innerHTML =
    todasEtiquetas.map(e => `<option value="${escapeHtml(e.nombre)}">`).join("");

  const catalogoProductos = await api().listar_catalogo_productos();
  document.getElementById("lista-productos-catalogo").innerHTML =
    catalogoProductos.map(p => `<option value="${escapeHtml(p.nombre)}">`).join("");

  const catalogoQuejas = await api().listar_catalogo_quejas();
  document.getElementById("lista-quejas-catalogo").innerHTML =
    catalogoQuejas.map(m => `<option value="${escapeHtml(m.nombre)}">`).join("");

  await pintarEtiquetasFicha();
  await pintarCampanasFicha();
  await pintarTareasFicha();
  await pintarVentasFicha();
  await pintarQuejasFicha();
  await pintarNotasFicha();

  document.getElementById("modal-ficha-contacto").style.display = "flex";
}

document.getElementById("btn-ficha-whatsapp").addEventListener("click", async (e) => {
  const btn = e.currentTarget;
  const original = btn.textContent;
  btn.disabled = true;
  btn.textContent = "Abriendo...";
  const res = await api().abrir_whatsapp_contacto(fichaNumeroCompletoActual);
  btn.disabled = false;
  btn.textContent = original;
  if (!res.ok) alert(res.error);
  else if (res.aviso) alert(res.aviso);
});

document.getElementById("btn-cerrar-ficha-contacto").addEventListener("click", () => {
  document.getElementById("modal-ficha-contacto").style.display = "none";
  if (campanaTableroActualId) renderTableroCampana();
});

document.getElementById("btn-guardar-datos-ficha").addEventListener("click", async () => {
  await api().actualizar_datos_contacto(
    fichaNumeroActual,
    document.getElementById("ficha-input-empresa").value.trim(),
    document.getElementById("ficha-input-correo").value.trim(),
    document.getElementById("ficha-input-direccion").value.trim(),
    document.getElementById("ficha-input-ciudad").value.trim(),
  );
  const aviso = document.getElementById("ficha-datos-guardado");
  aviso.style.display = "inline";
  setTimeout(() => aviso.style.display = "none", 2000);
});

async function pintarEtiquetasFicha() {
  const etiquetas = await api().etiquetas_de_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-etiquetas-chips");
  contenedor.innerHTML = "";
  if (etiquetas.length === 0) {
    contenedor.innerHTML = `<span class="muted" style="margin-left:0; font-size:12px;">Sin etiquetas todavía</span>`;
  }
  etiquetas.forEach(et => {
    const chip = document.createElement("span");
    chip.className = "plantilla-chip-grupo";
    chip.innerHTML =
      `<span class="plantilla-chip" style="cursor:default;">${escapeHtml(et.nombre)}</span>` +
      `<button class="plantilla-chip-accion" title="Quitar">${icono("equis", 10)}</button>`;
    chip.querySelector(".plantilla-chip-accion").addEventListener("click", async () => {
      await api().quitar_etiqueta_de_contacto(fichaNumeroActual, et.id);
      pintarEtiquetasFicha();
    });
    contenedor.appendChild(chip);
  });
}

document.getElementById("btn-agregar-etiqueta").addEventListener("click", async () => {
  const input = document.getElementById("input-nueva-etiqueta");
  if (!input.value.trim()) return;
  await api().agregar_etiqueta_a_contacto(fichaNumeroActual, input.value.trim());
  input.value = "";
  pintarEtiquetasFicha();
});

async function pintarCampanasFicha() {
  const campanas = await api().campanas_de_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-campanas-lista");
  contenedor.innerHTML = "";
  if (campanas.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0; font-size:12.5px;">Sin campañas registradas.</div>`;
    return;
  }
  campanas.forEach(c => {
    const div = document.createElement("div");
    div.className = "ficha-campana-item";
    div.innerHTML = `
      <span>${escapeHtml(c.campana_nombre)}</span>
      <span class="ficha-campana-item-columna">${escapeHtml(c.columna || c.estado_envio)}</span>
    `;
    contenedor.appendChild(div);
  });
}

// ---- Tareas de la ficha ----
async function pintarTareasFicha() {
  const tareas = await api().listar_tareas_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-tareas-lista");
  contenedor.innerHTML = "";
  if (tareas.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0; font-size:12.5px;">Sin tareas todavía.</div>`;
    return;
  }
  tareas.forEach(t => {
    const div = document.createElement("div");
    div.className = "tarea-item" + (t.completado ? " completada" : "");
    div.innerHTML = `
      <input type="checkbox" ${t.completado ? "checked" : ""}>
      <span class="tarea-item-titulo">${escapeHtml(t.titulo)}</span>
      <button class="btn-icon btn-editar-tarea" title="Editar">${icono("lapiz", 13)}</button>
      <button class="btn-icon btn-eliminar-tarea" title="Eliminar">${icono("papelera", 13)}</button>
    `;

    div.querySelector("input[type=checkbox]").addEventListener("change", async (e) => {
      await api().marcar_tarea_contacto(t.id, e.target.checked, fichaNumeroActual);
      pintarTareasFicha();
    });

    div.querySelector(".btn-editar-tarea").addEventListener("click", () => {
      const tituloSpan = div.querySelector(".tarea-item-titulo");
      const btnEditar = div.querySelector(".btn-editar-tarea");
      const input = document.createElement("input");
      input.type = "text";
      input.className = "tarea-input-edicion";
      input.value = t.titulo;
      tituloSpan.replaceWith(input);
      input.focus();
      input.select();
      btnEditar.innerHTML = icono("check", 13);

      const guardar = async () => {
        if (!input.value.trim()) return;
        await api().editar_tarea_contacto(t.id, input.value.trim(), fichaNumeroActual);
        pintarTareasFicha();
      };
      const nuevoBtn = btnEditar.cloneNode(true);
      btnEditar.replaceWith(nuevoBtn);
      nuevoBtn.addEventListener("click", guardar);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); guardar(); } });
    });

    div.querySelector(".btn-eliminar-tarea").addEventListener("click", async () => {
      await api().eliminar_tarea_contacto(t.id, fichaNumeroActual);
      pintarTareasFicha();
    });

    contenedor.appendChild(div);
  });
}

document.getElementById("btn-agregar-tarea-contacto").addEventListener("click", async () => {
  const input = document.getElementById("input-tarea-contacto");
  if (!input.value.trim()) return;
  await api().agregar_tarea_contacto(fichaNumeroActual, input.value.trim());
  input.value = "";
  pintarTareasFicha();
});

// ---- Ventas (catálogo reutilizable de productos/servicios) ----
async function pintarVentasFicha() {
  const ventas = await api().listar_ventas_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-ventas-lista");
  contenedor.innerHTML = "";
  if (ventas.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0; font-size:12.5px;">Sin ventas registradas.</div>`;
  } else {
    ventas.forEach(v => {
      const div = document.createElement("div");
      div.className = "registro-item";
      div.innerHTML = `
        <span><span class="registro-item-fecha">${(v.fecha || "").slice(0, 10)}</span>${escapeHtml(v.producto)}</span>
        <button class="btn-icon btn-eliminar-venta" title="Eliminar">${icono("papelera", 12)}</button>
      `;
      div.querySelector(".btn-eliminar-venta").addEventListener("click", async () => {
        await api().eliminar_venta_contacto(v.id, fichaNumeroActual);
        pintarVentasFicha();
      });
      contenedor.appendChild(div);
    });
  }

  const favorito = await api().obtener_contacto(fichaNumeroActual);
  const badge = document.getElementById("ficha-producto-favorito");
  const favoritoInfo = ventas.length > 0 ? await calcularFavoritoLocal(ventas) : null;
  if (favoritoInfo) {
    badge.style.display = "inline";
    badge.textContent = `★ Favorito: ${favoritoInfo.producto} (${favoritoInfo.veces}x)`;
  } else {
    badge.style.display = "none";
  }
}

// Se calcula aquí mismo con lo que ya se pidió (la lista de ventas), en
// vez de pedirle al backend un dato aparte para lo mismo.
async function calcularFavoritoLocal(ventas) {
  const conteo = {};
  ventas.forEach(v => { conteo[v.producto] = (conteo[v.producto] || 0) + 1; });
  let top = null;
  for (const [producto, veces] of Object.entries(conteo)) {
    if (veces >= 3 && (!top || veces > top.veces)) top = { producto, veces };
  }
  return top;
}

document.getElementById("btn-registrar-venta").addEventListener("click", async () => {
  const input = document.getElementById("input-venta-producto");
  const nombre = input.value.trim();
  if (!nombre) return;

  const sugerencia = await api().sugerir_producto_similar(nombre);
  let nombreFinal = nombre;
  if (sugerencia) {
    const usarSugerido = confirm(`¿Quisiste decir "${sugerencia}"? Aceptar para usar ese (recomendado), Cancelar para crear "${nombre}" como uno nuevo.`);
    if (usarSugerido) nombreFinal = sugerencia;
  }

  const res = await api().agregar_producto_catalogo(nombreFinal);
  if (!res.ok) { alert(res.error); return; }
  await api().registrar_venta_contacto(fichaNumeroActual, res.id);
  input.value = "";
  document.getElementById("lista-productos-catalogo").innerHTML =
    res.catalogo.map(p => `<option value="${escapeHtml(p.nombre)}">`).join("");
  pintarVentasFicha();
});

// ---- Quejas (catálogo reutilizable de motivos) ----
async function pintarQuejasFicha() {
  const quejas = await api().listar_quejas_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-quejas-lista");
  contenedor.innerHTML = "";
  if (quejas.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0; font-size:12.5px;">Sin quejas registradas.</div>`;
    return;
  }
  quejas.forEach(q => {
    const div = document.createElement("div");
    div.className = "registro-item";
    div.innerHTML = `
      <span><span class="registro-item-fecha">${(q.fecha || "").slice(0, 10)}</span>${escapeHtml(q.motivo)}</span>
      <button class="btn-icon btn-eliminar-queja" title="Eliminar">${icono("papelera", 12)}</button>
    `;
    div.querySelector(".btn-eliminar-queja").addEventListener("click", async () => {
      await api().eliminar_queja_contacto(q.id, fichaNumeroActual);
      pintarQuejasFicha();
    });
    contenedor.appendChild(div);
  });
}

document.getElementById("btn-registrar-queja").addEventListener("click", async () => {
  const input = document.getElementById("input-queja-motivo");
  const nombre = input.value.trim();
  if (!nombre) return;

  const sugerencia = await api().sugerir_motivo_queja_similar(nombre);
  let nombreFinal = nombre;
  if (sugerencia) {
    const usarSugerido = confirm(`¿Quisiste decir "${sugerencia}"? Aceptar para usar ese (recomendado), Cancelar para crear "${nombre}" como uno nuevo.`);
    if (usarSugerido) nombreFinal = sugerencia;
  }

  const res = await api().agregar_motivo_queja_catalogo(nombreFinal);
  if (!res.ok) { alert(res.error); return; }
  await api().registrar_queja_contacto(fichaNumeroActual, res.id);
  input.value = "";
  document.getElementById("lista-quejas-catalogo").innerHTML =
    res.catalogo.map(m => `<option value="${escapeHtml(m.nombre)}">`).join("");
  pintarQuejasFicha();
});

// ---- Observaciones de la ficha (texto libre, distinto de las tareas) ----
async function pintarNotasFicha() {
  const notas = await api().listar_notas_contacto(fichaNumeroActual);
  const contenedor = document.getElementById("ficha-notas-lista");
  contenedor.innerHTML = "";
  if (notas.length === 0) {
    contenedor.innerHTML = `<div class="sin-notas">Sin observaciones todavía.</div>`;
    return;
  }
  notas.forEach(n => {
    const div = document.createElement("div");
    div.className = "nota-item";
    const fecha = (n.fecha || "").slice(0, 16).replace("T", " ");
    div.innerHTML = `
      <div class="nota-fecha-fila">
        <span class="nota-fecha">${fecha}</span>
        <div class="nota-acciones">
          <button class="btn-icon btn-editar-nota-contacto" title="Editar">${icono("lapiz", 13)}</button>
          <button class="btn-icon btn-eliminar-nota-contacto" title="Eliminar">${icono("papelera", 13)}</button>
        </div>
      </div>
      <div class="nota-texto">${escapeHtml(n.texto)}</div>
    `;

    div.querySelector(".btn-editar-nota-contacto").addEventListener("click", () => {
      const textoDiv = div.querySelector(".nota-texto");
      const btnEditar = div.querySelector(".btn-editar-nota-contacto");
      const textarea = document.createElement("textarea");
      textarea.className = "input-text nota-textarea-edicion";
      textarea.value = n.texto;
      textoDiv.replaceWith(textarea);
      textarea.focus();
      btnEditar.innerHTML = icono("check", 13);

      const guardar = async () => {
        await api().editar_nota_contacto(n.id, textarea.value.trim(), fichaNumeroActual);
        pintarNotasFicha();
      };
      const nuevoBtn = btnEditar.cloneNode(true);
      btnEditar.replaceWith(nuevoBtn);
      nuevoBtn.addEventListener("click", guardar);
      textarea.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); guardar(); }
      });
    });

    div.querySelector(".btn-eliminar-nota-contacto").addEventListener("click", async () => {
      await api().eliminar_nota_contacto(n.id, fichaNumeroActual);
      pintarNotasFicha();
    });

    contenedor.appendChild(div);
  });
}

document.getElementById("btn-agregar-nota-contacto").addEventListener("click", async () => {
  const input = document.getElementById("input-nota-contacto");
  if (!input.value.trim()) return;
  await api().agregar_nota_contacto(fichaNumeroActual, input.value.trim());
  input.value = "";
  pintarNotasFicha();
});

// =========================================================
// REPORTES
// =========================================================
async function cargarReportes() {
  const campanas = await api().listar_campanas_reporte();
  const select = document.getElementById("filtro-campana");
  select.innerHTML = `<option value="">Todas</option>`;
  campanas.forEach(c => {
    select.innerHTML += `<option value="${c.id}">${escapeHtml(c.nombre)}</option>`;
  });
}

document.querySelectorAll(".export-buttons .btn").forEach(btn => {
  btn.addEventListener("click", async () => {
    const formato = btn.dataset.formato;
    const campanaIdRaw = document.getElementById("filtro-campana").value;
    const campanaId = campanaIdRaw ? parseInt(campanaIdRaw) : null;
    const desde = document.getElementById("filtro-fecha-desde").value || null;
    const hasta = document.getElementById("filtro-fecha-hasta").value || null;
    const resultado = document.getElementById("reporte-resultado");

    resultado.textContent = "Generando reporte...";
    const res = await api().exportar_reporte(formato, campanaId, desde, hasta);
    if (res.ok) {
      if (res.paginas && res.paginas > 1) {
        resultado.innerHTML = resultadoHTML(true, `El historial era grande, se dividió en ${res.paginas} archivos (500 filas cada uno) en la carpeta que elegiste.`);
      } else {
        resultado.innerHTML = resultadoHTML(true, "Reporte guardado en: " + res.ruta);
      }
    } else {
      resultado.innerHTML = resultadoHTML(false, res.error || "No se pudo generar el reporte");
    }
  });
});

// =========================================================
// INFORMACIÓN
// =========================================================
// Parte rápida y 100% local -- segura de llamar al arrancar el programa,
// nunca espera a internet. Actualiza el pie del menú lateral, que se ve
// en cualquier pantalla, no solo en Información.
async function cargarInfoBasica() {
  const info = await api().info_app();
  document.getElementById("info-version").textContent = info.version;
  document.getElementById("info-licencia").textContent = info.licencia;
  document.getElementById("info-version-actual").textContent = info.version;
  document.getElementById("footer-version").textContent = "Ola v" + info.version;

  const disponible = await api().reporte_disponible();
  document.getElementById("reportar-seccion").style.display = disponible ? "block" : "none";
}

// Parte completa -- incluye consultas a internet (GitHub) para traer
// rubros y plantillas de campaña disponibles. Antes se llamaba también
// al arrancar el programa, lo cual congelaba la ventana varios segundos
// en cada apertura si la conexión estaba lenta -- ahora SOLO se llama
// cuando el usuario realmente entra a la pantalla de Información.
async function cargarInfo() {
  await cargarInfoBasica();
  cargarRubrosDisponibles();
  cargarPlantillasCampanaInfo();
  api().obtener_hardware_id().then(id => {
    document.getElementById("info-hardware-id").textContent = id;
  });
}

async function enviarReporte(contextoPrellenado) {
  const inputContexto = document.getElementById("input-reportar-contexto");
  if (contextoPrellenado) inputContexto.value = contextoPrellenado;

  const resultado = document.getElementById("reportar-resultado");
  resultado.style.display = "block";
  resultado.textContent = "Enviando...";

  const res = await api().enviar_reporte_error(inputContexto.value.trim());
  resultado.textContent = res.ok
    ? resultadoHTML(true, "Reporte enviado, gracias por ayudarnos a mejorar.")
    : resultadoHTML(false, res.error || "No se pudo enviar el reporte.");
}

document.getElementById("btn-enviar-reporte").addEventListener("click", () => enviarReporte());

document.getElementById("btn-banner-reportar").addEventListener("click", async () => {
  document.getElementById("banner-error-critico").style.display = "none";
  irAPagina("info");
  document.getElementById("reportar-seccion").scrollIntoView({ behavior: "smooth" });
});
document.getElementById("btn-banner-error-cerrar").addEventListener("click", () => {
  document.getElementById("banner-error-critico").style.display = "none";
});

// Llamado desde Python cuando una campaña falla con un error inesperado
function appErrorCritico(mensaje) {
  document.getElementById("banner-error-texto").textContent =
    "Ocurrió un error inesperado durante el envío: " + mensaje;
  document.getElementById("banner-error-critico").style.display = "flex";
}

document.getElementById("btn-buscar-actualizacion").addEventListener("click", async () => {
  const resultado = document.getElementById("actualizacion-resultado");
  resultado.style.display = "block";
  resultado.textContent = "Buscando actualizaciones...";

  const res = await api().verificar_actualizacion();

  if (!res.ok) {
    resultado.innerHTML = resultadoHTML(false, res.error);
    return;
  }

  if (res.hay_actualizacion) {
    resultado.innerHTML = `${icono("destacar")} Hay una nueva versión disponible: <b>v${res.version_disponible}</b> (tienes v${res.version_actual}).<br>` +
      `<a href="${res.url_descarga}" target="_blank" style="color:var(--morado-oscuro); font-weight:700;">Descargar actualización ${icono("flechaDer",14)}</a>`;
  } else {
    resultado.innerHTML = resultadoHTML(true, `Ya tienes la versión más reciente (v${res.version_actual}).`);
  }
});

async function cargarRubrosDisponibles() {
  const contenedor = document.getElementById("rubros-lista");
  contenedor.innerHTML = `<p class="muted" style="margin-left:0;">Cargando rubros disponibles...</p>`;

  const res = await api().listar_rubros_disponibles();
  if (!res.ok) {
    contenedor.innerHTML = `<p class="muted" style="margin-left:0;">${icono("alerta")} No se pudo conectar: ${escapeHtml(res.error)}</p>`;
    return;
  }

  if (!res.rubros || res.rubros.length === 0) {
    contenedor.innerHTML = `<p class="muted" style="margin-left:0;">Aún no hay rubros publicados.</p>`;
    return;
  }

  contenedor.innerHTML = "";
  res.rubros.forEach(r => {
    const div = document.createElement("div");
    div.className = "rubro-item";
    div.innerHTML = `
      <div>
        <div class="rubro-nombre">${escapeHtml(r.nombre)}</div>
        <div class="rubro-estado" data-estado-de="${r.id}">Disponible para instalar</div>
      </div>
      <button class="btn btn-outline btn-sm btn-instalar-rubro" data-id="${r.id}">${icono("descargar",14)} Instalar</button>
    `;
    contenedor.appendChild(div);
  });

  document.querySelectorAll(".btn-instalar-rubro").forEach(btn => {
    btn.addEventListener("click", async () => {
      const rubroId = btn.dataset.id;
      const estadoDiv = document.querySelector(`.rubro-estado[data-estado-de="${rubroId}"]`);
      btn.disabled = true;
      btn.textContent = "Instalando...";

      const res = await api().instalar_rubro(rubroId);

      if (!res.ok) {
        estadoDiv.innerHTML = resultadoHTML(false, res.error);
        btn.disabled = false;
        btn.innerHTML = `${icono("descargar",14)} Instalar`;
        return;
      }

      estadoDiv.innerHTML = resultadoHTML(true, `${res.instaladas} plantilla(s) instalada(s)` +
        (res.omitidas > 0 ? ` (${res.omitidas} ya existían)` : ""));
      btn.innerHTML = `${icono("check",14)} Instalado`;

      // Refrescar el banco de plantillas en memoria para que aparezcan
      // de inmediato como chips en los módulos de texto ya abiertos.
      await cargarPlantillas();
      chipsRefrescables.forEach(fn => fn());
    });
  });
}

async function cargarPlantillasCampanaInfo() {
  const contenedor = document.getElementById("plantillas-campana-info-lista");
  contenedor.innerHTML = `<p class="muted" style="margin-left:0;">Cargando plantillas disponibles...</p>`;

  const res = await api().listar_campanas_plantillas_disponibles();
  if (!res.ok) {
    contenedor.innerHTML = `<p class="muted" style="margin-left:0;">${icono("alerta")} No se pudo conectar: ${escapeHtml(res.error)}</p>`;
    return;
  }
  if (!res.campanas || res.campanas.length === 0) {
    contenedor.innerHTML = `<p class="muted" style="margin-left:0;">Aún no hay plantillas de campaña publicadas.</p>`;
    return;
  }

  contenedor.innerHTML = "";
  res.campanas.forEach(c => {
    const div = document.createElement("div");
    div.className = "rubro-item";
    div.innerHTML = `
      <div>
        <div class="rubro-nombre">${escapeHtml(c.nombre)}</div>
        <div class="rubro-estado" data-estado-campana-de="${c.id}">Disponible para instalar</div>
      </div>
      <button class="btn btn-outline btn-sm btn-instalar-plantilla-campana-info" data-id="${c.id}">${icono("descargar",14)} Instalar</button>
    `;
    contenedor.appendChild(div);
  });

  document.querySelectorAll(".btn-instalar-plantilla-campana-info").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      const estadoDiv = document.querySelector(`.rubro-estado[data-estado-campana-de="${id}"]`);
      btn.disabled = true;
      btn.textContent = "Instalando...";

      const res = await api().instalar_plantilla_campana_github(id);

      if (!res.ok) {
        estadoDiv.innerHTML = resultadoHTML(false, res.error);
        btn.disabled = false;
        btn.innerHTML = `${icono("descargar",14)} Instalar`;
        return;
      }

      estadoDiv.innerHTML = res.ya_existia ? resultadoHTML(true, "Ya estaba instalada") : resultadoHTML(true, "Instalada correctamente");
      btn.innerHTML = `${icono("check",14)} Instalado`;
    });
  });
}

// =========================================================
// ASISTENTE DE PRIMER USO
// =========================================================
let onboardingPaso = 1;
const ONBOARDING_TOTAL_PASOS = 4;

function mostrarPasoOnboarding(n) {
  for (let i = 1; i <= ONBOARDING_TOTAL_PASOS; i++) {
    document.getElementById("onboarding-paso-" + i).style.display = (i === n) ? "block" : "none";
  }
  document.querySelectorAll(".onboarding-punto").forEach(p => {
    p.classList.toggle("activo", parseInt(p.dataset.punto) === n);
  });
  document.getElementById("btn-onboarding-anterior").style.display = n === 1 ? "none" : "inline-flex";
  document.getElementById("btn-onboarding-siguiente").innerHTML =
    n === ONBOARDING_TOTAL_PASOS ? `¡Entendido, empezar! ${icono("check",14)}` : `Siguiente ${icono("flechaDer",14)}`;
}

function abrirOnboarding() {
  onboardingPaso = 1;
  mostrarPasoOnboarding(1);
  document.getElementById("modal-onboarding").style.display = "flex";
}

document.getElementById("btn-onboarding-siguiente").addEventListener("click", async () => {
  if (onboardingPaso < ONBOARDING_TOTAL_PASOS) {
    onboardingPaso++;
    mostrarPasoOnboarding(onboardingPaso);
  } else {
    document.getElementById("modal-onboarding").style.display = "none";
    await api().marcar_onboarding_visto();
  }
});

document.getElementById("btn-onboarding-anterior").addEventListener("click", () => {
  if (onboardingPaso > 1) {
    onboardingPaso--;
    mostrarPasoOnboarding(onboardingPaso);
  }
});

document.getElementById("btn-ver-tutorial").addEventListener("click", abrirOnboarding);

document.getElementById("btn-exportar-respaldo").addEventListener("click", async () => {
  const resultado = document.getElementById("respaldo-resultado");
  const res = await api().exportar_respaldo();
  if (!res.ok) {
    if (res.error) {
      resultado.style.display = "block";
      resultado.innerHTML = resultadoHTML(false, res.error);
    }
    return;
  }
  resultado.style.display = "block";
  resultado.innerHTML = resultadoHTML(true, "Respaldo guardado en: " + res.ruta);
});

document.getElementById("btn-importar-respaldo").addEventListener("click", async () => {
  const resultado = document.getElementById("respaldo-resultado");
  if (!confirm("Esto reemplaza tu historial actual por el del archivo de respaldo que elijas. " +
               "Se guarda una copia de seguridad de lo que tienes ahora, por si acaso. ¿Continuar?")) {
    return;
  }
  const res = await api().importar_respaldo();
  if (!res.ok) {
    if (res.error) {
      resultado.style.display = "block";
      resultado.innerHTML = resultadoHTML(false, res.error);
    }
    return;
  }
  resultado.style.display = "block";
  resultado.innerHTML = resultadoHTML(true, "Respaldo restaurado. Cierra y vuelve a abrir el programa para verlo reflejado.");
});

// Estado inicial de los botones al cargar la página
actualizarBotonesEstado();

// =========================================================
// ACTIVACIÓN DE LICENCIAS (solo visible para el dueño)
// =========================================================
let solicitudesLicenciaCache = [];
let rechazadasLicenciaCache = [];
let mesesLicenciaDatosCache = {};
let mesDetalleLicenciaActual = null;
let licTimerInterval = null;
let licTimerInicio = null;

async function cargarActivacion() {
  const precios = await api().obtener_precios_licencia();
  document.getElementById("input-precio-mensual").value = precios.mensual;
  document.getElementById("input-precio-trimestral").value = precios.trimestral;

  const url = await api().obtener_url_hoja_licencias();
  document.getElementById("input-url-hoja").value = url;

  const numeroPropio = await api().obtener_numero_propio_whatsapp();
  document.getElementById("input-numero-propio").value = numeroPropio;

  solicitudesLicenciaCache = await api().listar_solicitudes_pendientes_licencia();
  pintarSolicitudesLicencia();

  rechazadasLicenciaCache = await api().listar_solicitudes_rechazadas_licencia();
  pintarSolicitudesRechazadas();

  await cargarPanoramaGeneralLicencias();
  await cargarMesesLicencia();
}

document.getElementById("btn-guardar-config-licencias").addEventListener("click", async () => {
  const mensual = document.getElementById("input-precio-mensual").value;
  const trimestral = document.getElementById("input-precio-trimestral").value;
  await api().guardar_precios_licencia(mensual, trimestral);
  await api().guardar_url_hoja_licencias(document.getElementById("input-url-hoja").value);
  await api().guardar_numero_propio_whatsapp(document.getElementById("input-numero-propio").value);
  alert("Configuración guardada.");
});

document.getElementById("btn-sincronizar-solicitudes").addEventListener("click", async () => {
  const url = document.getElementById("input-url-hoja").value.trim();
  if (!url) {
    alert("Primero guarda el enlace de la hoja de Google en Configuración.");
    return;
  }
  const res = await api().sincronizar_solicitudes_licencia(url);
  if (!res.ok) {
    alert(res.error);
    return;
  }
  solicitudesLicenciaCache = await api().listar_solicitudes_pendientes_licencia();
  pintarSolicitudesLicencia();
  alert(`Listo -- ${res.nuevas} solicitud(es) nueva(s) importada(s).`);
});

function pintarSolicitudesLicencia() {
  const contenedor = document.getElementById("lista-solicitudes-licencia");
  contenedor.innerHTML = "";

  if (solicitudesLicenciaCache.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0;">Sin solicitudes pendientes. Usa "Sincronizar solicitudes" para revisar el formulario.</div>`;
    actualizarBotonEnviarCodigos();
    return;
  }

  solicitudesLicenciaCache.forEach(s => {
    const div = document.createElement("div");
    div.className = "solicitud-licencia-item";

    const badge = s.es_renovacion
      ? `<span class="solicitud-licencia-badge renovacion">Renovación</span>`
      : `<span class="solicitud-licencia-badge nuevo">Nuevo</span>`;

    const duplicadoBadge = s.posible_duplicado
      ? `<span class="solicitud-licencia-badge duplicado">⚠️ Posible duplicado este mes</span>`
      : "";

    const semaforoClase = s.codigo_generado ? "naranja" : "gris";
    const semaforoTitulo = s.codigo_generado ? "Código generado, falta enviar" : "Sin generar todavía";

    const comprobanteHtml = s.comprobante_url
      ? `<a href="${s.comprobante_url}" target="_blank">Ver comprobante</a> · `
      : "";

    const codigoHtml = s.codigo_generado
      ? `<div class="solicitud-licencia-codigo">${icono("check", 12)} Código generado</div>`
      : "";

    div.innerHTML = `
      <div class="solicitud-licencia-datos">
        <span class="solicitud-licencia-semaforo ${semaforoClase}" title="${semaforoTitulo}"></span>
        <span class="solicitud-licencia-nombre">${escapeHtml(s.nombres)} ${escapeHtml(s.apellidos)}</span>${badge}${duplicadoBadge}
        <div class="solicitud-licencia-meta">
          ${escapeHtml(s.whatsapp_normalizado || s.whatsapp)} · Plan ${escapeHtml(s.plan)} ($${s.monto_esperado}) · ${escapeHtml(s.banco)} · Tx: ${escapeHtml(s.num_transaccion)}
        </div>
        <div class="solicitud-licencia-meta">${comprobanteHtml}${(s.fecha_solicitud || "").slice(0, 16).replace("T", " ")}</div>
        ${codigoHtml}
      </div>
      <div class="solicitud-licencia-acciones">
        <button class="btn btn-outline btn-sm btn-generar-codigo" ${s.codigo_generado ? "disabled" : ""}>
          ${s.codigo_generado ? "Código listo" : "Generar código"}
        </button>
        <button class="btn-link btn-whatsapp-solicitud" style="margin:0;">${icono("mensaje", 12)} WhatsApp</button>
        <button class="btn-link btn-rechazar-solicitud" style="margin:0; color:#dc2626;">Rechazar</button>
      </div>
    `;

    div.querySelector(".btn-generar-codigo").addEventListener("click", async (e) => {
      if (s.codigo_generado) return;
      e.target.disabled = true;
      e.target.textContent = "Generando...";
      const res = await api().generar_codigo_solicitud(s.id);
      if (!res.ok) {
        alert(res.error);
        e.target.disabled = false;
        e.target.textContent = "Generar código";
        return;
      }
      solicitudesLicenciaCache = res.solicitudes;
      pintarSolicitudesLicencia();
    });

    div.querySelector(".btn-whatsapp-solicitud").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = "Abriendo...";
      const res = await api().abrir_whatsapp_solicitud(s.id);
      btn.disabled = false;
      btn.innerHTML = original;
      if (!res.ok) alert(res.error);
      else if (res.aviso) alert(res.aviso);
    });

    div.querySelector(".btn-rechazar-solicitud").addEventListener("click", async () => {
      const motivo = prompt("Motivo del rechazo (quedará guardado para retomar el caso después):");
      if (motivo === null) return;
      if (!motivo.trim()) {
        alert("Escribe el motivo del rechazo.");
        return;
      }
      const res = await api().rechazar_solicitud_licencia(s.id, motivo);
      if (!res.ok) {
        alert(res.error);
        return;
      }
      solicitudesLicenciaCache = res.pendientes;
      rechazadasLicenciaCache = res.rechazadas;
      pintarSolicitudesLicencia();
      pintarSolicitudesRechazadas();
    });

    contenedor.appendChild(div);
  });

  actualizarBotonEnviarCodigos();
}

function pintarSolicitudesRechazadas() {
  const contenedor = document.getElementById("lista-solicitudes-rechazadas");
  contenedor.innerHTML = "";

  if (rechazadasLicenciaCache.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0;">Sin solicitudes rechazadas pendientes de respuesta.</div>`;
    return;
  }

  rechazadasLicenciaCache.forEach(s => {
    const div = document.createElement("div");
    div.className = "solicitud-licencia-item";
    div.innerHTML = `
      <div class="solicitud-licencia-datos">
        <span class="solicitud-licencia-semaforo" style="background:#dc2626;"></span>
        <span class="solicitud-licencia-nombre">${escapeHtml(s.nombres)} ${escapeHtml(s.apellidos)}</span>
        <span class="solicitud-licencia-badge rechazada">Rechazada</span>
        <div class="solicitud-licencia-meta">
          ${escapeHtml(s.whatsapp_normalizado || s.whatsapp)} · Plan ${escapeHtml(s.plan)} · ${escapeHtml(s.banco)}
        </div>
        <div class="solicitud-licencia-motivo">${escapeHtml(s.motivo_rechazo || "")}</div>
      </div>
      <div class="solicitud-licencia-acciones">
        <button class="btn btn-outline btn-sm btn-reactivar-solicitud">Reactivar</button>
        <button class="btn-link btn-whatsapp-solicitud" style="margin:0;">${icono("mensaje", 12)} WhatsApp</button>
      </div>
    `;

    div.querySelector(".btn-reactivar-solicitud").addEventListener("click", async () => {
      if (!confirm("¿Volver a poner esta solicitud como pendiente?")) return;
      const res = await api().reactivar_solicitud_licencia(s.id);
      solicitudesLicenciaCache = res.pendientes;
      rechazadasLicenciaCache = res.rechazadas;
      pintarSolicitudesLicencia();
      pintarSolicitudesRechazadas();
    });

    div.querySelector(".btn-whatsapp-solicitud").addEventListener("click", async (e) => {
      const btn = e.currentTarget;
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = "Abriendo...";
      const res = await api().abrir_whatsapp_solicitud(s.id);
      btn.disabled = false;
      btn.innerHTML = original;
      if (!res.ok) alert(res.error);
      else if (res.aviso) alert(res.aviso);
    });

    contenedor.appendChild(div);
  });
}

function actualizarBotonEnviarCodigos() {
  const hayListos = solicitudesLicenciaCache.some(s => s.codigo_generado);
  document.getElementById("btn-enviar-codigos").disabled = !hayListos;
}

document.querySelectorAll(".chip-etiqueta").forEach(btn => {
  btn.addEventListener("click", () => {
    const textarea = document.getElementById("input-mensaje-licencia");
    const inicio = textarea.selectionStart || textarea.value.length;
    const texto = textarea.value;
    textarea.value = texto.slice(0, inicio) + btn.dataset.etiqueta + texto.slice(inicio);
    textarea.focus();
  });
});

document.getElementById("btn-enviar-codigos").addEventListener("click", async () => {
  const ids = solicitudesLicenciaCache.filter(s => s.codigo_generado).map(s => s.id);
  if (ids.length === 0) return;
  if (!confirm(`Vas a enviar ${ids.length} código(s) por WhatsApp. ¿Continuar?`)) return;

  const mensaje = document.getElementById("input-mensaje-licencia").value;
  const logBox = document.getElementById("lic-envio-log");
  logBox.style.display = "block";
  logBox.innerHTML = "Iniciando envío... esto abre WhatsApp Web, puede tardar unos segundos.<br>";
  iniciarTimerLicencia();

  const res = await api().enviar_codigos_licencia(ids, mensaje);
  if (!res.ok) {
    logBox.innerHTML += `❌ ${res.error}<br>`;
    detenerTimerLicencia();
    return;
  }
  document.getElementById("btn-enviar-codigos").disabled = true;
});

// El motor manda aquí cada línea del progreso, en vivo, sin salir de esta pantalla
function appLicenciaLog(texto) {
  const logBox = document.getElementById("lic-envio-log");
  logBox.innerHTML += texto + "<br>";
  logBox.scrollTop = logBox.scrollHeight;
}

// El backend llama a esto cuando termina de mandar los códigos
function appCodigosLicenciaTerminado(totalEnviados, segundos) {
  const logBox = document.getElementById("lic-envio-log");
  logBox.innerHTML += `<b>Listo -- ${totalEnviados} código(s) enviado(s) por WhatsApp.</b><br>`;
  logBox.scrollTop = logBox.scrollHeight;
  detenerTimerLicencia(segundos);
  cargarActivacion();
}

function iniciarTimerLicencia() {
  licTimerInicio = Date.now();
  const caja = document.getElementById("lic-envio-progreso");
  caja.style.display = "flex";
  document.getElementById("lic-envio-tiempo").textContent = "00:00";
  if (licTimerInterval) clearInterval(licTimerInterval);
  licTimerInterval = setInterval(() => {
    const segundos = Math.floor((Date.now() - licTimerInicio) / 1000);
    document.getElementById("lic-envio-tiempo").textContent = formatearDuracion(segundos);
  }, 1000);
}

function detenerTimerLicencia(segundosFinal) {
  if (licTimerInterval) clearInterval(licTimerInterval);
  licTimerInterval = null;
  if (typeof segundosFinal === "number") {
    document.getElementById("lic-envio-tiempo").textContent = formatearDuracion(segundosFinal);
  }
}

function formatearDuracion(segundos) {
  const m = Math.floor(segundos / 60).toString().padStart(2, "0");
  const s = Math.floor(segundos % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

document.getElementById("btn-reset-log-licencia").addEventListener("click", () => {
  document.getElementById("lic-envio-log").innerHTML = "";
  document.getElementById("lic-envio-log").style.display = "none";
  document.getElementById("lic-envio-progreso").style.display = "none";
});

async function cargarPanoramaGeneralLicencias() {
  const general = await api().dashboard_licencias_general();
  document.getElementById("lic-usuarios-activos").textContent = general.usuarios_activos;
  document.getElementById("lic-usuarios-totales").textContent = general.usuarios_totales;
  document.getElementById("lic-perdidos").textContent = general.clientes_perdidos;

  const comp = general.comparativa_planes || {};
  const mensual = comp.Mensual || 0;
  const trimestral = comp.Trimestral || 0;
  let planPopular = "—";
  if (mensual > 0 || trimestral > 0) {
    planPopular = mensual >= trimestral ? `Mensual (${mensual})` : `Trimestral (${trimestral})`;
  }
  document.getElementById("lic-plan-popular").textContent = planPopular;
}

// ---- Tarjetas por mes: solo licencias ya otorgadas (enviadas) ----
async function cargarMesesLicencia() {
  const meses = await api().meses_disponibles_licencias();
  const grid = document.getElementById("activacion-meses-grid");
  grid.innerHTML = "";
  mesesLicenciaDatosCache = {};

  if (meses.length === 0) {
    grid.innerHTML = `<div class="muted" style="margin-left:0;">Todavía no se ha otorgado ninguna licencia.</div>`;
    return;
  }

  for (const mes of meses) {
    const [solicitudes, resumen] = await Promise.all([
      api().solicitudes_del_mes_licencia(mes),
      api().dashboard_licencias(mes),
    ]);
    mesesLicenciaDatosCache[mes] = solicitudes;

    const card = document.createElement("div");
    card.className = "seguimiento-campana-card activacion-mes-card";
    card.innerHTML = `
      <div class="activacion-mes-card-menu-wrap">
        <button class="btn-icon btn-menu-mes-licencia" title="Más opciones">${icono("masOpciones", 13)}</button>
        <div class="activacion-mes-card-menu">
          <button class="activacion-mes-card-menu-item btn-exportar-mes-desde-tarjeta">${icono("descargar", 13)} Exportar Excel de este mes</button>
        </div>
      </div>
      <div class="seguimiento-campana-nombre">${formatearMes(mes)}</div>
      <div class="seguimiento-campana-meta">${resumen.licencias_otorgadas} licencia(s) otorgada(s) · $${resumen.monto_total.toFixed(2)}</div>
      <div class="activacion-mes-card-stats">
        <span>Nuevos: ${resumen.clientes_nuevos}</span>
        <span>Renovaciones: ${resumen.renovaciones}</span>
      </div>
    `;

    card.addEventListener("click", () => abrirDetalleMesLicencia(mes));

    const menu = card.querySelector(".activacion-mes-card-menu");
    card.querySelector(".btn-menu-mes-licencia").addEventListener("click", (e) => {
      e.stopPropagation();
      const yaAbierto = menu.classList.contains("abierto");
      document.querySelectorAll(".activacion-mes-card-menu.abierto").forEach(m => m.classList.remove("abierto"));
      if (!yaAbierto) menu.classList.add("abierto");
    });
    card.querySelector(".btn-exportar-mes-desde-tarjeta").addEventListener("click", async (e) => {
      e.stopPropagation();
      menu.classList.remove("abierto");
      const res = await api().exportar_solicitudes_mes_licencia(mes);
      if (!res.ok) {
        if (res.error) alert(res.error);
        return;
      }
      alert(`Exportado a: ${res.ruta}`);
    });

    grid.appendChild(card);
  }
}

document.addEventListener("click", () => {
  document.querySelectorAll(".activacion-mes-card-menu.abierto").forEach(m => m.classList.remove("abierto"));
});

// ---- Al abrir una tarjeta: vista aparte completa (igual que el tablero de Seguimiento) ----
async function abrirDetalleMesLicencia(mes) {
  mesDetalleLicenciaActual = mes;
  document.getElementById("activacion-home").style.display = "none";
  document.getElementById("activacion-mes-detalle").style.display = "block";
  document.getElementById("activacion-mes-titulo").textContent = formatearMes(mes);

  const resumen = await api().dashboard_licencias(mes);
  document.getElementById("lic-mes-otorgadas").textContent = resumen.licencias_otorgadas;
  document.getElementById("lic-mes-monto").textContent = "$" + resumen.monto_total.toFixed(2);
  document.getElementById("lic-mes-nuevos").textContent = resumen.clientes_nuevos;
  document.getElementById("lic-mes-renovaciones").textContent = resumen.renovaciones;

  const datos = mesesLicenciaDatosCache[mes] || [];
  const planes = [...new Set(datos.map(s => s.plan).filter(Boolean))];
  const bancos = [...new Set(datos.map(s => s.banco).filter(Boolean))];

  const selPlan = document.getElementById("filtro-lic-plan");
  selPlan.innerHTML = `<option value="">Todos los planes</option>` + planes.map(p => `<option value="${p}">${p}</option>`).join("");
  const selBanco = document.getElementById("filtro-lic-banco");
  selBanco.innerHTML = `<option value="">Todos los bancos</option>` + bancos.map(b => `<option value="${escapeHtml(b)}">${escapeHtml(b)}</option>`).join("");
  document.getElementById("filtro-lic-tipo").value = "";

  pintarListaMesLicencia();
}

document.getElementById("btn-cerrar-mes-licencias").addEventListener("click", () => {
  document.getElementById("activacion-mes-detalle").style.display = "none";
  document.getElementById("activacion-home").style.display = "block";
  mesDetalleLicenciaActual = null;
});

["filtro-lic-plan", "filtro-lic-banco", "filtro-lic-tipo"].forEach(id => {
  document.getElementById(id).addEventListener("change", () => pintarListaMesLicencia());
});

function pintarListaMesLicencia() {
  const datos = mesesLicenciaDatosCache[mesDetalleLicenciaActual] || [];
  const plan = document.getElementById("filtro-lic-plan").value;
  const banco = document.getElementById("filtro-lic-banco").value;
  const tipo = document.getElementById("filtro-lic-tipo").value;

  const filtrados = datos.filter(s =>
    (!plan || s.plan === plan) &&
    (!banco || s.banco === banco) &&
    (!tipo || (tipo === "renovacion" ? !!s.es_renovacion : !s.es_renovacion))
  );

  const contenedor = document.getElementById("activacion-mes-lista");
  contenedor.innerHTML = "";

  if (filtrados.length === 0) {
    contenedor.innerHTML = `<div class="muted" style="margin-left:0;">Sin licencias con ese filtro.</div>`;
    return;
  }

  filtrados.forEach(s => {
    const div = document.createElement("div");
    div.className = "solicitud-licencia-item";
    const badge = s.es_renovacion
      ? `<span class="solicitud-licencia-badge renovacion">Renovación</span>`
      : `<span class="solicitud-licencia-badge nuevo">Nuevo</span>`;
    div.innerHTML = `
      <div class="solicitud-licencia-datos">
        <span class="solicitud-licencia-nombre">${escapeHtml(s.nombres)} ${escapeHtml(s.apellidos)}</span>${badge}
        <div class="solicitud-licencia-meta">
          ${escapeHtml(s.whatsapp_normalizado || s.whatsapp)} · Plan ${escapeHtml(s.plan)} ($${s.monto_esperado}) · ${escapeHtml(s.banco)}
        </div>
        <div class="solicitud-licencia-meta">Activaciones históricas de este cliente: ${s.total_licencias_cliente || 0} · Enviado: ${(s.fecha_enviado || "").slice(0, 16).replace("T", " ")}</div>
      </div>
    `;
    contenedor.appendChild(div);
  });
}

document.getElementById("btn-exportar-mes-licencias").addEventListener("click", async () => {
  if (!mesDetalleLicenciaActual) return;
  const res = await api().exportar_solicitudes_mes_licencia(mesDetalleLicenciaActual);
  if (!res.ok) {
    if (res.error) alert(res.error);
    return;
  }
  alert(`Exportado a: ${res.ruta}`);
});

// ---- Exportar por rango de meses (desde el Home, para análisis) ----
document.getElementById("btn-exportar-rango-licencias").addEventListener("click", async () => {
  const desde = document.getElementById("rango-lic-desde").value; // formato YYYY-MM
  const hasta = document.getElementById("rango-lic-hasta").value;
  if (!desde || !hasta) {
    alert("Elige el mes de inicio y el mes final del rango.");
    return;
  }
  const res = await api().exportar_licencias_rango(desde, hasta);
  if (!res.ok) {
    if (res.error) alert(res.error);
    return;
  }
  alert(`Exportado a: ${res.ruta}`);
});
