// =========================================================
// iconos.js
// Banco de íconos de una sola tinta, estilo línea (inspirado en Tabler
// Icons). Todos heredan el color del texto que los rodea (stroke =
// currentColor) -- el color no lo define el ícono, lo define el módulo
// donde vive. 24x24, trazo 2, esquinas y puntas redondeadas.
//
// Uso: icono("papelera")  -> devuelve el SVG como texto, listo para
// insertar con innerHTML o dentro de un template literal.
// =========================================================

const ICONOS_SVG = {
  inicio: '<path d="M4 11l8-7 8 7"/><path d="M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9"/>',
  mensaje: '<path d="M4 5h16v11H8l-4 4V5z"/>',
  grafico: '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M4 20h16"/>',
  documento: '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/><path d="M9 13h6"/><path d="M9 17h6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01"/><path d="M11 12h1v5h1"/>',
  papelera: '<path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-13"/><path d="M10 11v6"/><path d="M14 11v6"/>',
  lapiz: '<path d="M13.5 5.5l3 3L7 18l-4 1 1-4z"/><path d="M16.5 2.5l3 3"/>',
  campana: '<path d="M7 9a5 5 0 0 1 10 0v5l2 3H5l2-3z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  mas: '<path d="M12 5v14"/><path d="M5 12h14"/>',
  equis: '<path d="M6 6l12 12"/><path d="M18 6L6 18"/>',
  guardar: '<path d="M5 4h11l3 3v13H5V4z"/><path d="M8 4v5h7V4"/><path d="M8 14h8v6H8z"/>',
  descargar: '<path d="M12 4v11"/><path d="M7 11l5 5 5-5"/><path d="M5 19h14"/>',
  check: '<path d="M5 12l5 5L20 6"/>',
  candado: '<rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  carpeta: '<path d="M4 6h5l2 2h9v11H4z"/>',
  refrescar: '<path d="M4 10a8 8 0 0 1 14.9-4"/><path d="M4 4v6h6"/><path d="M20 14a8 8 0 0 1-14.9 4"/><path d="M20 20v-6h-6"/>',
  ayuda: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 4.6 1.3c0 1.5-2.1 1.7-2.1 3.2"/><path d="M12 17h.01"/>',
  bicho: '<rect x="8" y="8" width="8" height="10" rx="3"/><path d="M12 8V5"/><path d="M9 5l1.5 1.5"/><path d="M15 5l-1.5 1.5"/><path d="M5 12h3"/><path d="M16 12h3"/><path d="M5 17l3-1.5"/><path d="M16 15.5l3 1.5"/>',
  saludo: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5"/><path d="M11 11V4a1.5 1.5 0 0 1 3 0v7"/><path d="M14 11V6a1.5 1.5 0 0 1 3 0v7"/><path d="M17 12v-2a1.5 1.5 0 0 1 3 0v5c0 3-2 6-6 6h-2c-3 0-4.5-1.5-6-4l-2-3.5a1.4 1.4 0 0 1 2.4-1.5L8 14"/>',
  correo: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  ojo: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  bombilla: '<path d="M9 18h6"/><path d="M10 21h4"/><path d="M8 14a4 4 0 1 1 8 0c0 1.5-1 2.5-2 3.5-.5.5-1 1-1 1.5H11c0-.5-.5-1-1-1.5-1-1-2-2-2-3.5z"/>',
  clip: '<path d="M9 13l6-6a3 3 0 1 1 4 4l-8 8a5 5 0 1 1-7-7l7-7"/>',
  usuarios: '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3 2.5-5 6-5s6 2 6 5"/><circle cx="17" cy="9" r="2.5"/><path d="M15.5 20c.2-2.2 1.7-4 3.5-4.3"/>',
  tendencia: '<path d="M4 17l5-5 4 3 6-7"/><path d="M14 8h5v5"/>',
  tablero: '<rect x="3" y="4" width="6" height="16" rx="1.5"/><rect x="10.5" y="4" width="6" height="10" rx="1.5"/><rect x="18" y="4" width="3" height="7" rx="1.5"/>',
  ubicacion: '<path d="M12 21s-7-6.5-7-11a7 7 0 0 1 14 0c0 4.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
  masOpciones: '<circle cx="12" cy="5" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.4" fill="currentColor" stroke="none"/>',
  sol: '<circle cx="12" cy="12" r="4.5"/><path d="M12 3v2"/><path d="M12 19v2"/><path d="M4.2 4.2l1.4 1.4"/><path d="M18.4 18.4l1.4 1.4"/><path d="M3 12h2"/><path d="M19 12h2"/><path d="M4.2 19.8l1.4-1.4"/><path d="M18.4 5.6l1.4-1.4"/>',
  luna: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
  llave: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9"/><path d="M16 7l3 3"/><path d="M13 10l3 3"/>',
  sonrisa: '<circle cx="12" cy="12" r="9"/><path d="M8.5 10h.01"/><path d="M15.5 10h.01"/><path d="M8 14.5c1 1.3 2.5 2 4 2s3-.7 4-2"/>',
  alerta: '<path d="M12 4l9 16H3z"/><path d="M12 10v4"/><path d="M12 17h.01"/>',
  circulo: '<circle cx="12" cy="12" r="8" fill="currentColor" stroke="none"/>',
  flechaIzq: '<path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/>',
  flechaDer: '<path d="M5 12h14"/><path d="M13 6l6 6-6 6"/>',
  copiar: '<rect x="9" y="9" width="11" height="11" rx="1.5"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/>',
  portapapeles: '<rect x="6" y="4" width="12" height="16" rx="1.5"/><rect x="9" y="2.5" width="6" height="3" rx="1"/><path d="M9 11h6"/><path d="M9 15h6"/>',
  reproducir: '<path d="M7 5l12 7-12 7z" fill="currentColor" stroke="none"/>',
  pausar: '<rect x="7" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/><rect x="13" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none"/>',
  detener: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/>',
  retomar: '<path d="M9 10l-4 4 4 4"/><path d="M5 14h11a4 4 0 0 0 0-8h-1"/>',
  destacar: '<path d="M12 3l1.8 5.5H19l-4.5 3.3 1.7 5.5-4.2-3.3-4.2 3.3 1.7-5.5L5 8.5h5.2z"/>',
};

function icono(nombre, tamano) {
  tamano = tamano || 18;
  const contenido = ICONOS_SVG[nombre] || "";
  return `<svg class="icono" width="${tamano}" height="${tamano}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${contenido}</svg>`;
}
