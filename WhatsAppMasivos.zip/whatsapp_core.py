"""
whatsapp_core.py
Motor de automatización. Procesa una "campaña" dividida en segmentos
(rangos de contactos según la columna "Numero" del Excel). Cada segmento
tiene una lista ORDENADA de módulos (texto o archivo).

Soporta:
- Pausa real (se detiene entre contacto y contacto, se puede reanudar con
  configuración actualizada) distinta de Detener (cancela del todo, pero
  la campaña queda "Pausada" en la base de datos y se puede retomar luego
  desde el Home).
- Segmentación automática si el Excel trae una columna "Segmento".
- Chequeo previo (números inválidos, duplicados, sin segmento) antes de
  iniciar el envío real.
"""

import os
import re
import tempfile
import time
import random
import logging
import traceback
from datetime import datetime

import pandas as pd
import pyautogui
import pyperclip

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

import db
import selectores_whatsapp as sel

COLUMNAS_REQUERIDAS = ["Numero", "Nombre", "Celular"]

VELOCIDADES = {
    "Lento":  {"bloque_envio": (10, 15), "pausa_media": (40, 70),
               "bloque_grande": (20, 25), "pausa_larga": (90, 180),
               "delay_contacto": (8, 15)},
    "Normal": {"bloque_envio": (15, 20), "pausa_media": (20, 40),
               "bloque_grande": (20, 30), "pausa_larga": (60, 120),
               "delay_contacto": (5, 10)},
    "Rápido": {"bloque_envio": (20, 30), "pausa_media": (10, 20),
               "bloque_grande": (40, 60), "pausa_larga": (30, 60),
               "delay_contacto": (3, 6)},
}


def carpeta_datos_app():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    ruta = os.path.join(base, "WhatsAppMasivos")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def carpeta_perfil_chrome():
    ruta = os.path.join(carpeta_datos_app(), "chrome_profile")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def tipo_archivo(ruta):
    ext = os.path.splitext(ruta)[1].lower()
    if ext in [".jpg", ".jpeg", ".png", ".gif", ".webp", ".mp4", ".mov", ".avi"]:
        return "Fotos y videos"
    if ext in [".mp3", ".ogg", ".wav", ".m4a"]:
        return "Audio"
    return "Documento"  # pdf, docx, xlsx, pptx, etc.


def preparar_imagen_para_envio(ruta):
    """
    Si es un PNG con fondo transparente, lo convierte a JPG con fondo
    blanco antes de mandarlo -- un PNG transparente es, técnicamente, el
    mismo formato que usa un sticker de WhatsApp, y hemos visto que
    WhatsApp a veces lo trata como tal en vez de como foto normal.

    Si no es PNG, o el PNG no tiene transparencia, o algo falla en la
    conversión (ej. no se pudo leer el archivo), se devuelve la ruta
    original sin tocar -- nunca bloquea el envío por esto.
    """
    if os.path.splitext(ruta)[1].lower() != ".png":
        return ruta

    try:
        from PIL import Image
    except ImportError:
        return ruta  # Pillow no instalado -- se manda el PNG tal cual

    try:
        img = Image.open(ruta)
        tiene_transparencia = (
            img.mode in ("RGBA", "LA")
            or (img.mode == "P" and "transparency" in img.info)
        )
        if not tiene_transparencia:
            return ruta

        img = img.convert("RGBA")
        fondo = Image.new("RGB", img.size, (255, 255, 255))
        fondo.paste(img, mask=img.split()[-1])

        nombre_temporal = f"whatsapp_masivos_{os.path.basename(ruta)}.jpg"
        ruta_temp = os.path.join(tempfile.gettempdir(), nombre_temporal)
        fondo.save(ruta_temp, "JPEG", quality=92)
        return ruta_temp
    except Exception:
        return ruta


def reemplazar_etiquetas(texto, fila):
    texto = texto.replace("{Nombre}", str(fila.get("Nombre", "")))
    texto = texto.replace("{Empresa}", str(fila.get("Empresa", "")))
    texto = texto.replace("{Teléfono}", str(fila.get("Contáctanos", "")))
    texto = texto.replace("{Telefono}", str(fila.get("Contáctanos", "")))

    # Columnas OPCIONALES -- si el Excel no las trae, cada etiqueta
    # queda vacía en vez de reventar, para no romper campañas que
    # todavía no las usan.
    primer_nombre = str(fila.get("Primer Nombre", "") or "")
    segundo_nombre = str(fila.get("Segundo Nombre", "") or "")
    apellidos = str(fila.get("Apellidos", "") or "")
    trato = str(fila.get("Trato", "") or "")

    texto = texto.replace("{PrimerNombre}", primer_nombre)
    texto = texto.replace("{SegundoNombre}", segundo_nombre)
    texto = texto.replace(
        "{PrimerNombreApellido}",
        f"{primer_nombre} {apellidos}".strip()
    )
    texto = texto.replace("{Trato}", trato)
    return texto


def numero_valido(numero):
    numero = str(numero).strip()
    return numero.isdigit() and len(numero) >= 8


# =========================
# SEGMENTACIÓN AUTOMÁTICA DESDE EXCEL
# =========================
def detectar_segmentos_excel(df):
    """
    [MÉTODO ANTERIOR -- se conserva solo para no romper campañas viejas
    que ya estuvieran guardadas/pausadas con el sistema de rangos por
    posición (Desde/Hasta). Las campañas nuevas usan
    contar_segmentos_por_nombre() en su lugar.]

    Si el Excel trae una columna "Segmento", agrupa filas consecutivas que
    comparten la misma etiqueta y arma segmentos automáticamente con su
    rango (según la columna Numero). Devuelve lista de
    {"nombre": str, "desde": int, "hasta": int} — sin módulos, esos los
    define el usuario en la interfaz.
    """
    if "Segmento" not in df.columns:
        return []

    segmentos = []
    numeros = pd.to_numeric(df["Numero"], errors="coerce")
    etiquetas = df["Segmento"].fillna("").astype(str).str.strip()

    actual_label = None
    actual_desde = None
    actual_hasta = None

    def cerrar_segmento():
        if actual_label:
            segmentos.append({
                "nombre": actual_label,
                "desde": int(actual_desde),
                "hasta": int(actual_hasta),
            })

    for i in range(len(df)):
        label = etiquetas.iloc[i]
        num = numeros.iloc[i]

        if not label or pd.isna(num):
            cerrar_segmento()
            actual_label = None
            continue

        if label != actual_label:
            cerrar_segmento()
            actual_label = label
            actual_desde = num
            actual_hasta = num
        else:
            actual_hasta = num

    cerrar_segmento()
    return segmentos


def contar_segmentos_por_nombre(df):
    """
    Agrupa los contactos por el NOMBRE real de la columna "Segmento",
    sin importar su posición ni si están juntos o separados en el
    Excel -- a diferencia de detectar_segmentos_excel() (el método
    anterior, que necesitaba filas consecutivas). Devuelve
    {"nombre": str, "cantidad": int} por cada etiqueta distinta que
    tenga al menos un contacto, en el orden en que cada una aparece
    por primera vez en el archivo.

    Si la columna existe pero viene vacía en todas las filas, se trata
    como un único segmento "Sin segmento" cubriendo a todos -- es el
    mismo nombre que ya usa el motor cuando no encuentra ninguna
    tarjeta configurada para el nombre de un contacto, así que es un
    solo concepto en vez de dos parecidos con nombres distintos: si
    borras esa tarjeta a propósito, el motor va a escribir "Sin
    segmento" en Estado, que ya es 100% cierto sin inventar nada nuevo.
    """
    if "Segmento" not in df.columns:
        return []

    etiquetas = df["Segmento"].fillna("").astype(str).str.strip()
    etiquetas = etiquetas.where(etiquetas != "", "Sin segmento")

    conteo = etiquetas.value_counts()
    orden_aparicion = list(etiquetas.drop_duplicates())

    return [
        {"nombre": nombre, "cantidad": int(conteo[nombre])}
        for nombre in orden_aparicion
    ]


def chequeo_previo(df, segmentos):
    """Valida antes de enviar: inválidos, duplicados, sin segmento asignado."""
    total = len(df)
    numeros = pd.to_numeric(df["Numero"], errors="coerce")
    etiquetas_segmento = df["Segmento"].fillna("").astype(str).str.strip() if "Segmento" in df.columns else None

    invalidos = sum(1 for c in df["Celular"] if not numero_valido(c))
    duplicados = int(df["Celular"].duplicated().sum())

    sin_segmento = 0
    for i in range(total):
        # Igual que en procesar_campana: primero por el NOMBRE real de
        # la columna "Segmento" -- solo se cae al método viejo por
        # posición (desde/hasta) como respaldo, y ahí sí puede que un
        # segmento nuevo (por nombre) no tenga esas claves, así que se
        # revisan con .get() para no reventar con un KeyError.
        encontrado = False
        if etiquetas_segmento is not None:
            etiqueta = etiquetas_segmento.iloc[i]
            if etiqueta:
                encontrado = any(seg.get("nombre", "").strip() == etiqueta for seg in segmentos)

        if not encontrado:
            num = numeros.iloc[i]
            if pd.notna(num):
                encontrado = any(
                    seg.get("desde") is not None and seg.get("hasta") is not None
                    and seg["desde"] <= num <= seg["hasta"]
                    for seg in segmentos
                )

        if not encontrado:
            sin_segmento += 1

    ya_enviados = 0
    if "Estado" in df.columns:
        ya_enviados = int((df["Estado"].astype(str).str.lower() == "enviado").sum())

    return {
        "total": total,
        "invalidos": invalidos,
        "duplicados": duplicados,
        "sin_segmento": sin_segmento,
        "ya_enviados": ya_enviados,
        "pendientes": total - ya_enviados,
    }


def _existe_ventana_abrir_archivo():
    """
    Consulta directo a Windows (no a Chrome, no a coordenadas de
    pantalla) si hay una ventana nativa del sistema abierta con la
    apariencia de un diálogo "Abrir archivo" -- clase de ventana
    "#32770" (el diálogo estándar de Windows) con un título que
    contenga "abrir" (en español, que es el idioma de esta instalación).

    Se usa antes de presionar Escape para cerrar esa ventana huérfana,
    en vez de presionarlo siempre a ciegas -- si la ventana nunca
    llegó a abrirse (que es lo más común, ya que el archivo se manda
    por un canal directo que no depende de ella), Escape no se toca
    para nada, y así nunca hay riesgo de que le llegue por accidente a
    la pestaña de Chrome en su lugar.

    En cualquier sistema que no sea Windows (o si algo falla al
    consultar), se asume que no existe -- nunca bloquea el envío.
    """
    if os.name != "nt":
        return False
    try:
        import ctypes

        encontrada = {"valor": False}

        def _callback(hwnd, lparam):
            if not ctypes.windll.user32.IsWindowVisible(hwnd):
                return True
            longitud = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            if longitud == 0:
                return True
            buffer_titulo = ctypes.create_unicode_buffer(longitud + 1)
            ctypes.windll.user32.GetWindowTextW(hwnd, buffer_titulo, longitud + 1)
            titulo = buffer_titulo.value.lower()

            buffer_clase = ctypes.create_unicode_buffer(256)
            ctypes.windll.user32.GetClassNameW(hwnd, buffer_clase, 256)
            clase = buffer_clase.value

            if clase == "#32770" and "abrir" in titulo:
                encontrada["valor"] = True
                return False  # deja de enumerar, ya encontramos lo que buscábamos
            return True

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
        ctypes.windll.user32.EnumWindows(WNDENUMPROC(_callback), 0)
        return encontrada["valor"]
    except Exception:
        return False


def normalizar_numero_whatsapp(numero, codigo_pais="593"):
    """
    Un mismo número lo puede escribir la gente de 3 formas distintas
    (0963347432, 593963347432, +593963347432, o hasta solo 963347432) --
    esto los deja SIEMPRE en el único formato que WhatsApp Web reconoce
    de forma confiable: código de país + número, sin el 0 inicial, sin
    espacios ni símbolos. Se usa en abrir_chat(), así que aplica por
    igual a campañas y al envío de códigos de licencia -- un solo lugar,
    para no tener que repetir esta lógica en cada uno por separado.
    """
    solo_digitos = re.sub(r"\D", "", str(numero or ""))
    if not solo_digitos:
        return ""
    if solo_digitos.startswith(codigo_pais):
        return solo_digitos
    if solo_digitos.startswith("0"):
        return codigo_pais + solo_digitos[1:]
    return codigo_pais + solo_digitos


class EnvioDetenido(Exception):
    """El usuario detuvo la campaña por completo (no es solo pausa)."""
    pass


class EnvioNoConfirmado(Exception):
    """
    El mensaje se mandó, pero nunca se pudo confirmar con el ✓ real que
    WhatsApp lo recibió -- distinto de un error real como "número
    inválido". Se separa a propósito para no acusar al número de estar
    mal cuando en realidad el programa simplemente no pudo verificar a
    tiempo (conexión lenta, WhatsApp tardado, etc.). NO obliga a volver
    a abrir el chat -- el navegador sigue en la misma conversación.
    """
    pass


class ErrorNoRecuperable(Exception):
    """
    Errores donde reintentar NO tiene sentido porque el problema no va
    a cambiar entre un intento y el siguiente: número con formato
    inválido, archivo adjunto inexistente, configuración de campaña
    inválida, segmento inexistente, formato de adjunto no soportado, o
    que el número coincida con el propio (se salta a propósito, no es
    un fallo). Al lanzarse, el contacto se descarta de inmediato, sin
    gastar el segundo intento en algo que ya sabemos que no va a
    resolverse solo.
    """
    pass


def liberar_perfil_chrome(log_callback=None):
    """
    Si ya hay un proceso de Chrome usando nuestra carpeta de perfil (de
    un intento anterior que no cerró bien, o de otra parte del programa
    como "Abrir WhatsApp" desde una ficha), lo cierra primero. Chrome no
    deja que dos procesos usen la misma carpeta de perfil a la vez -- si
    no se libera antes, la sesión nueva queda en un estado inconsistente
    (pantalla en gris, o falla en silencio). No toca ningún otro Chrome
    que tengas abierto para navegar normalmente -- solo el que esté
    usando ESTA carpeta específica.
    """
    try:
        import psutil
    except ImportError:
        logging.error(
            "liberar_perfil_chrome(): el paquete 'psutil' no está instalado -- "
            "la limpieza de Chrome se saltó por completo. Corre "
            "'python -m pip install -r requirements.txt' en el entorno virtual."
        )
        if log_callback:
            log_callback("⚠ No se pudo limpiar Chrome (falta el paquete psutil) -- puede que el envío falle.")
        return 0

    carpeta = carpeta_perfil_chrome().lower()
    cerrados = 0
    procesos_chrome_a_esperar = []
    for proc in psutil.process_iter(["name", "cmdline"]):
        try:
            nombre = (proc.info.get("name") or "").lower()

            # chromedriver.exe nunca menciona la carpeta de perfil en su
            # propia línea de comando (se la pasa a Chrome por otro
            # canal) -- así que a diferencia de chrome.exe, aquí no se
            # filtra por carpeta: cualquier chromedriver.exe suelto es
            # seguro cerrarlo, porque nuestro programa es el único que
            # lo usa en este equipo (nunca lo abre el usuario a mano).
            # Como no mantiene sesión de usuario, un cierre de golpe no
            # tiene el mismo costo que con chrome.exe (ver más abajo).
            if nombre == "chromedriver.exe":
                proc.terminate()
                cerrados += 1
                continue

            if "chrome" not in nombre:
                continue
            cmdline = " ".join(proc.info.get("cmdline") or []).lower()
            if carpeta in cmdline:
                # A diferencia de chromedriver, chrome.exe SÍ necesita
                # cerrar ordenadamente -- un cierre de golpe (terminate/
                # TerminateProcess) no le da tiempo de guardar su sesión
                # ni de soltar el candado de almacenamiento persistente
                # que WhatsApp Web necesita para arrancar. El síntoma es
                # una pestaña que "abre" pero se queda en blanco para
                # siempre, sin ni siquiera intentar cargar la app.
                # taskkill sin /F pide un cierre normal en vez de matar
                # el proceso; solo si no responde a tiempo se recurre al
                # cierre forzoso como último recurso.
                if os.name == "nt":
                    try:
                        subprocess.run(
                            ["taskkill", "/PID", str(proc.pid)],
                            capture_output=True, timeout=5
                        )
                    except Exception:
                        proc.terminate()
                else:
                    proc.terminate()
                procesos_chrome_a_esperar.append(proc)
                cerrados += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # Se espera a que de verdad terminen de cerrar (hasta 5s cada uno);
    # si alguno se resiste, ahí sí se fuerza como último recurso.
    for proc in procesos_chrome_a_esperar:
        try:
            proc.wait(timeout=5)
        except psutil.TimeoutExpired:
            try:
                proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    if cerrados:
        if log_callback:
            log_callback(f"Se cerró una sesión de Chrome que había quedado abierta ({cerrados} proceso(s)) antes de empezar limpio.")
        time.sleep(2)

    # Si Chrome se cerró de golpe alguna vez (una caída, no un cierre
    # normal), deja atrás unos archivos de "candado" que le dicen a
    # Chrome "esta carpeta ya está en uso" -- aunque ya no haya ningún
    # proceso corriendo. Sin esto, Chrome se niega a arrancar bien la
    # próxima vez, cayéndose de nuevo y dejando el mismo candado, en un
    # ciclo que nunca se resuelve solo.
    carpeta_perfil = carpeta_perfil_chrome()
    archivos_candado = ["SingletonLock", "SingletonCookie", "SingletonSocket"]
    candados_borrados = 0
    for nombre_archivo in archivos_candado:
        ruta = os.path.join(carpeta_perfil, nombre_archivo)
        if os.path.exists(ruta):
            try:
                os.remove(ruta)
                candados_borrados += 1
            except OSError:
                pass
    if candados_borrados and log_callback:
        log_callback("Se limpiaron archivos de bloqueo de una sesión anterior que no cerró bien.")

    return cerrados


class CampaignEngine:
    def __init__(self, velocidad="Normal", log_callback=None,
                 progress_callback=None, stop_event=None, pause_event=None,
                 diag_callback=None):
        self.driver = None
        self.wait = None
        self.velocidad = VELOCIDADES.get(velocidad, VELOCIDADES["Normal"])
        self.log_callback = log_callback or (lambda texto: None)
        self.progress_callback = progress_callback or (lambda actual, total: None)
        self.stop_event = stop_event
        self.pause_event = pause_event
        # Callback opcional para la ventana de diagnóstico en vivo -- si
        # no se pasa (modo normal), diag() no hace nada y no le agrega
        # ningún costo al envío real. Recibe (tipo, dict_con_datos_crudos).
        self.diag_callback = diag_callback or (lambda tipo, datos: None)

        self.segmentos = []  # se actualiza en vivo si el usuario edita en pausa
        self._pausa_avisada = False

        self.contador_envios = 0
        self._navegaciones_contacto_actual = 0
        self.bloque_envio = random.randint(*self.velocidad["bloque_envio"])
        self.bloque_grande = random.randint(*self.velocidad["bloque_grande"])

    def log(self, texto):
        self.log_callback(texto)

    def diag(self, tipo, datos):
        """
        Manda un dato crudo (selector probado, HTML encontrado, error
        completo, etc.) a la ventana de diagnóstico, si está abierta.
        Nunca debe poder romper un envío real -- cualquier fallo aquí
        se traga en silencio.
        """
        try:
            self.diag_callback(tipo, datos)
        except Exception:
            pass

    def actualizar_segmentos(self, nuevos_segmentos):
        self.segmentos = nuevos_segmentos

    def _chequear_stop(self):
        if self.stop_event is not None and self.stop_event.is_set():
            raise EnvioDetenido()

    def _chequear_pausa(self):
        """Espera mientras esté en pausa, revisando también si piden detener."""
        if self.pause_event is None:
            return
        if self.pause_event.is_set() and not self._pausa_avisada:
            self.log("⏸ Campaña en pausa. Puedes editar los segmentos y luego reanudar.")
            self._pausa_avisada = True
        while self.pause_event.is_set():
            self._chequear_stop()
            time.sleep(0.5)
        if self._pausa_avisada:
            self.log("▶ Campaña reanudada.")
            self._pausa_avisada = False

    # -------------------------
    # Navegador
    # -------------------------
    def iniciar_navegador(self):
        liberar_perfil_chrome(log_callback=self.log)

        options = Options()
        options.add_argument("--start-maximized")
        options.add_argument("--disable-session-crashed-bubble")
        options.add_argument(f"user-data-dir={carpeta_perfil_chrome()}")

        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 30)

        self.log("Abriendo WhatsApp Web... si es la primera vez, escanea el código QR con tu celular.")
        self.driver.get("https://web.whatsapp.com")

        try:
            WebDriverWait(self.driver, 120).until(
                EC.presence_of_element_located((By.ID, sel.ID_BARRA_LATERAL))
            )
            self.log("Sesión de WhatsApp Web lista.")
            # Pequeña pausa extra: justo al terminar de cargar, WhatsApp
            # Web a veces todavía está terminando de sincronizar por
            # dentro -- sin esto, el primer contacto puede toparse con un
            # aviso de "número inválido" que en realidad no lo es (ya
            # existe un reintento automático que lo recupera solo, pero
            # esto reduce que pase en primer lugar).
            time.sleep(3)
        except TimeoutException:
            self.log("⚠ No se detectó la sesión de WhatsApp cargada (¿falta escanear el QR?).")

    def cerrar_navegador(self):
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None

    # -------------------------
    # Validaciones
    # -------------------------
    @staticmethod
    def validar_adjunto(ruta):
        if not ruta:
            return
        if not os.path.exists(ruta):
            raise ErrorNoRecuperable(f"Archivo adjunto no existe: {ruta}")

    # -------------------------
    # Chat
    # -------------------------
    def _marcar_posible_cambio_whatsapp(self, contexto):
        """
        Registra en el log con una etiqueta reconocible (SELENIUM_SELECTOR_FALLO)
        para poder distinguir "WhatsApp cambió su interfaz" de cualquier otro
        tipo de error -- si esto empieza a aparecer en varios reportes de
        distintos clientes a la vez, es la señal de que hay que revisar y
        actualizar los selectores del programa.
        """
        logging.error(f"SELENIUM_SELECTOR_FALLO: {contexto}")

    def esperar_chat_o_error(self, timeout=25):
        xpath_textbox = sel.XPATH_CAJA_TEXTO
        xpath_aviso_sin_whatsapp = sel.XPATH_AVISO_NUMERO_SIN_WHATSAPP

        fin = time.time() + timeout
        while time.time() < fin:
            self._chequear_stop()
            if self.driver.find_elements(By.XPATH, xpath_textbox):
                return "ok"

            avisos = self.driver.find_elements(By.XPATH, xpath_aviso_sin_whatsapp)
            if avisos:
                # A diferencia del selector genérico que se descartó
                # (cualquier pop-up con botón, que confundía el aviso de
                # carga normal "Iniciando chat..." con un error real),
                # este busca el TEXTO específico "no está en WhatsApp",
                # confirmado con una captura de pantalla real -- mucho
                # más difícil que un diálogo no relacionado contenga
                # esa frase por casualidad.
                self.diag("numero_sin_whatsapp_confirmado", {
                    "texto_encontrado": avisos[0].text[:200],
                })
                return "error_numero"

            time.sleep(0.5)

        # Si no apareció ni el cuadro de texto ni el aviso específico de
        # "no está en WhatsApp", no se adivina la causa -- se trata como
        # un fallo recuperable genérico (se reintenta), no como "no
        # tiene WhatsApp".
        self._marcar_posible_cambio_whatsapp("No cargó el cuadro de texto del chat ni el aviso de número sin WhatsApp")
        contexto = self._guardar_evidencia_fallo("chat_no_cargo")
        self.diag("error", {
            "motivo": "no cargó el chat dentro del tiempo de espera",
            "limite_usado_seg": timeout,
            "evidencia": contexto,
        })
        raise TimeoutException(
            "No se pudo abrir el chat a tiempo. Puede ser una conexión lenta, "
            "o que WhatsApp haya actualizado su interfaz."
        )

    # Cualquiera de estos 3 confirma que WhatsApp recibió y aceptó el
    # envío -- no se exige específicamente "Enviado" (✓ simple), porque
    # en la práctica WhatsApp puede pasar directo a "Entregado" o
    # "Leído" tan rápido que el programa nunca alcanza a ver el estado
    # intermedio. (Ver selectores_whatsapp.py -- ahí vive la lista real.)
    _ESTADOS_CONFIRMADO = sel.ESTADOS_ENVIO_CONFIRMADO

    def _esperar_confirmacion_envio(self, tamano_mb=0, etiqueta="mensaje"):
        """
        Espera al ✓ REAL de confirmación del último mensaje que se
        mandó, en vez de confiar en un tiempo fijo -- un archivo pesado
        tarda más en subir que uno liviano, y esperar por tiempo a
        ciegas o marca error antes de tiempo (falso negativo) o
        desperdicia tiempo de más en los livianos.

        Selector confirmado inspeccionando el HTML real de WhatsApp Web
        (no es una suposición, como sí lo fue el selector viejo que
        usaba "message-out"): cada mensaje real de la conversación vive
        dentro de <div id="main"> (el panel de la conversación abierta,
        separado de la lista de chats), como una fila con role="row" y
        un data-testid="conv-msg-XXXXX". El estado de envío vive en un
        bloque data-testid="msg-meta" dentro de esa fila, en un <span>
        con aria-label describiendo el estado en texto.

        Mientras no aparezca ninguno de los 3 estados confirmados, se
        sigue esperando sin rendirse antes de tiempo -- solo el límite
        total (que crece según el tamaño del archivo) corta la espera
        si nunca se confirma nada.
        """
        limite = min(120, 15 + tamano_mb * 1.5)
        fin = time.time() + limite
        xpath_ultima_fila = sel.XPATH_ULTIMA_FILA_MENSAJE

        intentos = 0
        while time.time() < fin:
            self._chequear_stop()
            intentos += 1

            filas = self.driver.find_elements(By.XPATH, xpath_ultima_fila)
            if not filas:
                self.diag("verificacion_envio", {
                    "etiqueta": etiqueta, "intento": intentos,
                    "selector": xpath_ultima_fila,
                    "resultado": "no se encontró ninguna fila de mensaje todavía",
                })
                time.sleep(0.4)
                continue

            fila = filas[0]
            estado_encontrado = None
            spans_estado = fila.find_elements(
                By.XPATH, sel.XPATH_ESTADO_EN_FILA
            )
            for span in spans_estado:
                texto_label = (span.get_attribute("aria-label") or "").strip()
                if any(estado in texto_label for estado in self._ESTADOS_CONFIRMADO):
                    estado_encontrado = texto_label
                    break

            self.diag("verificacion_envio", {
                "etiqueta": etiqueta, "intento": intentos,
                "selector": xpath_ultima_fila,
                "estado_encontrado": estado_encontrado,
                "html_fila": fila.get_attribute("outerHTML")[:1500],
            })

            if estado_encontrado:
                self.log(f"✔ Envío confirmado ({estado_encontrado.strip()})")
                return

            time.sleep(0.4)

        # Se acabó el tiempo sin ver ningún estado confirmado. Se guarda
        # evidencia completa (captura + HTML de la página entera) para
        # poder diagnosticar después qué pasaba en pantalla en ese
        # instante exacto -- no solo un mensaje de error genérico.
        contexto = self._guardar_evidencia_fallo(f"sin_confirmar_{etiqueta}")
        self.diag("error", {
            "etiqueta": etiqueta, "motivo": "tiempo agotado sin confirmación",
            "limite_usado_seg": limite, "evidencia": contexto,
        })
        raise EnvioNoConfirmado(
            f"No se pudo confirmar el envío del {etiqueta} (no apareció el estado de "
            f"enviado en {limite:.0f}s). Puede que sí haya llegado -- revisa el chat a mano."
        )

    def _contar_filas_mensaje(self):
        """Cuántos mensajes hay ahora mismo en la conversación abierta --
        se usa antes/después de un intento fallido para saber si en
        realidad SÍ llegó a mandarse algo nuevo, aunque no se haya
        podido confirmar con el estado (ver EnvioNoConfirmado)."""
        try:
            xpath = sel.XPATH_FILA_MENSAJE
            return len(self.driver.find_elements(By.XPATH, xpath))
        except Exception:
            return -1  # -1 = no se pudo contar, se trata como "no hay forma de saber"

    def _ultimo_mensaje_texto_coincide(self, texto_esperado):
        """
        Antes de reintentar un módulo de TEXTO que quedó "sin
        confirmar" (recomendación aprobada: no reenviar a ciegas algo
        que puede que ya haya llegado), se revisa si el último mensaje
        de la conversación ya coincide con lo que se iba a mandar --
        si coincide, no hace falta reenviarlo, solo se da por hecho.
        """
        try:
            xpath = sel.XPATH_ULTIMA_FILA_MENSAJE
            filas = self.driver.find_elements(By.XPATH, xpath)
            if not filas:
                return False
            texto_visible = filas[0].text.strip()
            # Comparación flexible: el texto real puede traer la hora y
            # el ✓ pegados al final, así que basta con que el mensaje
            # esperado esté CONTENIDO en lo que se ve, no una igualdad
            # exacta carácter por carácter.
            return texto_esperado.strip() in texto_visible
        except Exception:
            return False

    def _guardar_evidencia_fallo(self, motivo):
        """Guarda una captura de pantalla + el HTML completo de la página
        en el momento exacto de un fallo, para diagnóstico posterior."""
        try:
            carpeta = os.path.join(carpeta_datos_app(), "diagnostico")
            os.makedirs(carpeta, exist_ok=True)
            marca = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            ruta_png = os.path.join(carpeta, f"{marca}_{motivo}.png")
            ruta_html = os.path.join(carpeta, f"{marca}_{motivo}.html")
            self.driver.save_screenshot(ruta_png)
            with open(ruta_html, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            return {"captura": ruta_png, "html": ruta_html}
        except Exception as e:
            return {"error_guardando_evidencia": str(e)}

    def _navegar(self, url, motivo):
        """
        Único punto del programa que de verdad navega el navegador a
        otra página -- todo pasa por aquí para poder contar con
        certeza cuántas cargas reales ocurren por contacto, en vez de
        discutir con teorías: esto lo deja registrado con hora exacta.
        """
        self._navegaciones_contacto_actual += 1
        marca = time.time()
        self.diag("navegacion", {
            "motivo": motivo, "url": url,
            "numero_de_navegacion_para_este_contacto": self._navegaciones_contacto_actual,
        })
        self.driver.get(url)
        self.diag("navegacion_completada", {
            "motivo": motivo, "duracion_seg": round(time.time() - marca, 2),
        })

    def abrir_chat(self, numero):
        numero_normalizado = normalizar_numero_whatsapp(numero)
        self.log(f"🔍 Diagnóstico -- número recibido: '{numero}' -> normalizado: '{numero_normalizado}'")

        # WhatsApp Web ya no soporta abrir un chat contigo mismo por
        # enlace directo (send?phone=) -- devuelve un error interno
        # ("invalid wid") y la pestaña se queda esperando para siempre.
        # Si tu propio número aparece en la lista de envío (ej. para
        # probarte la campaña a ti mismo primero), se avisa con
        # claridad en vez de que parezca "número inválido".
        numero_propio = normalizar_numero_whatsapp(db.obtener_config("numero_propio_whatsapp", ""))
        if numero_propio and numero_normalizado == numero_propio:
            raise ErrorNoRecuperable(
                "Este es tu propio número -- WhatsApp no permite abrir un chat contigo mismo "
                "por enlace directo durante un envío automatizado. Se saltó este contacto."
            )

        url = f"https://web.whatsapp.com/send?phone={numero_normalizado}"
        self._navegar(url, motivo=f"abrir_chat({numero_normalizado})")
        resultado = self.esperar_chat_o_error()
        if resultado == "error_numero":
            # Ahora sí con evidencia real detrás (texto específico
            # confirmado con captura de pantalla) -- no tiene sentido
            # reintentar, el número no va a tener WhatsApp en el
            # segundo intento si no lo tiene en el primero.
            raise ErrorNoRecuperable("Número válido, pero sin cuenta de WhatsApp asociada")

    def enviar_texto_en_chat(self, texto):
        box = self.driver.find_element(
            By.XPATH, sel.XPATH_CAJA_TEXTO
        )
        pyperclip.copy(texto)
        box.click()
        time.sleep(random.uniform(1, 2))
        box.send_keys(Keys.CONTROL, "v")
        time.sleep(random.uniform(1, 2))
        box.send_keys(Keys.ENTER)

        self._esperar_confirmacion_envio(tamano_mb=0, etiqueta="texto")

    def _abrir_menu_adjuntar_y_elegir_tipo(self, label, intentos_maximos=3):
        """
        Abre el menú de "Adjuntar" y hace clic en el tipo (Fotos y
        videos / Documento / Audio), reintentando desde cero si el
        menú se cierra solo antes de alcanzar a hacer el segundo clic.

        Se confirmó con evidencia real (captura + relato del usuario)
        que esto pasa en chats con mucho contenido: WhatsApp puede
        seguir "asentando" un mensaje anterior que todavía está
        cargando, y ese redibujado de la página cierra el menú que se
        acababa de abrir -- no es que el botón no exista, es que
        desaparece por una fracción de segundo por una razón ajena al
        adjunto en sí. Reabrir el menú desde cero, después de una
        pausa corta, suele bastar para que la segunda vez sí funcione.

        Devuelve la lista de campos de archivo que ya existían ANTES
        del clic exitoso en el tipo -- la necesita el resto de
        enviar_adjunto() para encontrar el campo nuevo correcto.
        """
        ultimo_error = None
        for intento in range(1, intentos_maximos + 1):
            try:
                clip = self.wait.until(EC.element_to_be_clickable(
                    (By.XPATH, sel.XPATH_BOTON_ADJUNTAR)
                ))
                clip.click()
                time.sleep(random.uniform(1, 2))

                inputs_antes = self.driver.find_elements(By.CSS_SELECTOR, sel.CSS_CAMPO_ARCHIVO_OCULTO)

                tipo = self.wait.until(EC.element_to_be_clickable(
                    (By.XPATH, sel.xpath_boton_tipo_adjunto(label))
                ))
                tipo.click()

                if intento > 1:
                    self.log(f"↺ El menú de adjuntar se cerró solo, pero funcionó al reabrirlo (intento {intento}).")
                    self.diag("reintento_menu_adjuntar", {"etiqueta": label, "intento_exitoso": intento})

                return inputs_antes

            except TimeoutException as e:
                ultimo_error = e
                self.diag("menu_adjuntar_se_cerro", {
                    "etiqueta": label, "intento": intento,
                    "va_a_reintentar": intento < intentos_maximos,
                })
                time.sleep(random.uniform(1.5, 3))

        raise ultimo_error

    def enviar_adjunto(self, ruta):
        ruta = preparar_imagen_para_envio(ruta)
        ruta = ruta.replace("/", "\\")
        label = tipo_archivo(ruta)

        self.log("📎 Enviando adjunto...")

        try:
            # Antes de elegir el tipo, anotamos qué campos de archivo ya
            # existen en la página -- WhatsApp puede tener más de uno
            # coexistiendo (ej. el de "Fotos y videos" Y el de "Nuevo
            # sticker", que también acepta imágenes), y buscar solo por
            # atributos como accept="image/*" puede coincidir con el
            # equivocado por accidente.
            inputs_antes = self._abrir_menu_adjuntar_y_elegir_tipo(label)
            time.sleep(random.uniform(1, 2))

            # En vez de esperar el cuadro nativo de "Abrir archivo" de
            # Windows y pegar la ruta con pyautogui (que depende de que
            # Chrome tenga el foco del sistema en ese instante exacto),
            # se manda la ruta directo al campo oculto que WhatsApp Web ya
            # dejó listo en la página -- esto habla con Chrome por el
            # mismo canal de control que usa Selenium para todo lo demás,
            # así que funciona sin importar qué ventana esté al frente.
            #
            # El campo correcto es el que APARECIÓ justo después de este
            # clic específico -- no el que mejor coincida por atributos,
            # que puede confundirse con el de "Nuevo sticker" si ambos
            # aceptan imágenes.
            def _campo_recien_aparecido(driver):
                actuales = driver.find_elements(By.CSS_SELECTOR, sel.CSS_CAMPO_ARCHIVO_OCULTO)
                nuevos = [c for c in actuales if c not in inputs_antes]
                return nuevos[-1] if nuevos else False

            try:
                campo_archivo = self.wait.until(_campo_recien_aparecido)
            except TimeoutException:
                # Respaldo: si por algún motivo no apareció ningún campo
                # nuevo (ej. WhatsApp reutiliza uno que ya existía), se
                # usa el método anterior por atributos como último recurso.
                selector = sel.SELECTOR_INPUT_ARCHIVO_POR_TIPO.get(label, sel.CSS_CAMPO_ARCHIVO_OCULTO)
                campo_archivo = self.driver.find_element(By.CSS_SELECTOR, selector)

            campo_archivo.send_keys(ruta)
            time.sleep(random.uniform(1, 2))

            # El clic anterior en "Documento"/"Fotos y videos" PUEDE haber
            # abierto el cuadro nativo de "Abrir archivo" de Windows como
            # efecto secundario (eso Chrome lo hace solo, no lo pedimos
            # nosotros) -- como el archivo ya se mandó por el canal directo
            # de arriba, esa ventana (si existe) queda huérfana. Antes esto
            # presionaba Escape siempre, a ciegas, sin confirmar si la
            # ventana de verdad estaba ahí -- si no lo estaba, esa tecla le
            # llegaba directo a WhatsApp en la pestaña de Chrome en su
            # lugar (sospechamos que esto interrumpía cosas como el modo de
            # reproducción de video). Ahora se pregunta primero.
            if _existe_ventana_abrir_archivo():
                try:
                    pyautogui.press("escape")
                except Exception:
                    pass
                time.sleep(random.uniform(1, 2))

            send = self.wait.until(EC.element_to_be_clickable(
                (By.XPATH, sel.XPATH_BOTON_ENVIAR_ADJUNTO)
            ))
            time.sleep(random.uniform(1, 2))
            send.click()

            # Antes se esperaba un tiempo fijo calculado según el tamaño
            # del archivo, sin nunca confirmar que de verdad se envió --
            # ahora se espera al ícono real (✓), usando el tamaño solo
            # para saber cuánta paciencia darle como límite máximo.
            try:
                tamano_mb = os.path.getsize(ruta) / (1024 * 1024)
            except Exception:
                tamano_mb = 1
            self._esperar_confirmacion_envio(tamano_mb=tamano_mb, etiqueta=f"adjunto ({label})")
        except TimeoutException:
            self._marcar_posible_cambio_whatsapp(f"No se encontró un elemento esperado al enviar adjunto (tipo: {label})")
            # Se guarda evidencia completa (captura + HTML) ANTES de
            # lanzar el error -- este punto de falla nunca la tenía, a
            # diferencia de la verificación de envío, así que hasta
            # ahora solo se veía el traceback de Python sin poder ver
            # qué había en pantalla en ese instante exacto.
            contexto = self._guardar_evidencia_fallo(f"enviar_adjunto_{label}")
            self.diag("error", {
                "etiqueta": f"adjunto ({label})",
                "motivo": "no se encontró un elemento esperado al enviar el adjunto",
                "evidencia": contexto,
            })
            raise Exception(
                "No se pudo enviar el adjunto. Es posible que WhatsApp haya actualizado "
                "su interfaz -- contacta a tu proveedor si esto se repite seguido."
            )

        self.log("✅ Adjunto enviado")
        time.sleep(random.uniform(4, 7))

    # -------------------------
    # Procesar un contacto según los módulos de su segmento
    # -------------------------
    def procesar_contacto(self, fila, modulos, nombre_segmento):
        nombre = str(fila.get("Nombre", ""))
        numero = str(fila.get("Celular", ""))

        self.log(f"📤 Procesando: **{nombre}** ({numero}) — {nombre_segmento}")

        # Se normaliza PRIMERO y se valida el resultado normalizado --
        # antes se validaba el número tal como venía en el Excel, así
        # que un número perfectamente válido escrito con guiones o
        # espacios ("096-334-7432") podía rechazarse como "inválido"
        # sin necesidad, antes de darle la oportunidad de limpiarse.
        numero_normalizado = normalizar_numero_whatsapp(numero)
        if not numero_valido(numero_normalizado):
            return False, "Número inválido"

        self._navegaciones_contacto_actual = 0

        intento = 0
        error = "Error desconocido"
        # Índices de módulos que YA se mandaron bien para este contacto,
        # aunque haya sido en un intento anterior -- así un reintento no
        # vuelve a mandar de nuevo un adjunto (o texto) que ya llegó,
        # solo continúa desde donde de verdad se quedó.
        modulos_completados = set()
        # Si el chat sigue abierto y en buen estado, un reintento NO
        # necesita volver a navegar desde cero -- solo se reabre cuando
        # el problema fue justo al abrir el chat, o cuando algo salió
        # mal de una forma que deja la página en un estado dudoso.
        chat_abierto = False

        while intento < 2:
            self._chequear_stop()
            try:
                if not chat_abierto:
                    marca_paso = time.time()
                    self.abrir_chat(numero)
                    chat_abierto = True
                    self.diag("tiempo_paso", {
                        "contacto": nombre, "paso": "abrir_chat",
                        "duracion_seg": round(time.time() - marca_paso, 2),
                    })

                for idx, modulo in enumerate(modulos):
                    if idx in modulos_completados:
                        continue
                    self._chequear_stop()
                    self._chequear_pausa()  # entre acciones, no solo entre contactos
                    marca_paso = time.time()

                    if modulo["tipo"] == "texto":
                        texto = reemplazar_etiquetas(modulo["contenido"], fila)
                        try:
                            self.enviar_texto_en_chat(texto)
                        except EnvioNoConfirmado:
                            # Antes de darlo por fallido, se revisa si el
                            # texto en realidad SÍ llegó -- para no
                            # arriesgarse a mandarlo dos veces en el
                            # reintento (recomendación aprobada).
                            if self._ultimo_mensaje_texto_coincide(texto):
                                self.log(f"↺ El texto de **{nombre}** sí aparece en el chat -- se da por enviado pese al aviso.")
                            else:
                                raise

                    elif modulo["tipo"] == "archivo":
                        self.validar_adjunto(modulo["ruta"])
                        filas_antes = self._contar_filas_mensaje()
                        try:
                            self.enviar_adjunto(modulo["ruta"])
                        except EnvioNoConfirmado:
                            # Con un adjunto no se puede comparar el
                            # contenido como con el texto, pero si
                            # apareció un mensaje nuevo en el chat desde
                            # que se intentó, lo más probable es que sí
                            # se haya mandado -- se avisa igual, para que
                            # se revise a mano si hace falta.
                            filas_despues = self._contar_filas_mensaje()
                            if filas_despues > filas_antes >= 0:
                                self.log(f"↺ Apareció un mensaje nuevo en el chat de **{nombre}** pese al aviso de 'sin confirmar' -- probablemente sí se envió el adjunto, revisa a mano si quieres estar 100% seguro.")
                            else:
                                raise

                    modulos_completados.add(idx)
                    self.diag("tiempo_paso", {
                        "contacto": nombre, "paso": f"modulo_{idx}_{modulo['tipo']}",
                        "duracion_seg": round(time.time() - marca_paso, 2),
                    })

                self.log(f"✅ **{nombre}**: completado ({self._navegaciones_contacto_actual} navegación(es) real(es))")
                return True, ""

            except EnvioDetenido:
                raise

            except ErrorNoRecuperable as e:
                # No tiene sentido reintentar: el número no tiene
                # WhatsApp, el archivo no existe, o es el número propio
                # -- ninguno de estos cambia entre un intento y el
                # siguiente, así que se descarta de inmediato sin gastar
                # el segundo intento.
                error = str(e)
                self.log(f"⛔ **{nombre}**: {error} (no se reintenta, no tiene caso)")
                self.diag("error_no_recuperable", {
                    "contacto": nombre, "numero": numero,
                    "motivo": error,
                })
                break

            except EnvioNoConfirmado as e:
                # Se distingue de un error real: no se sabe si llegó o
                # no, así que no debería decir "número inválido" ni
                # nada que suene a una causa que no se comprobó. El chat
                # sigue abierto -- el navegador no se movió de ahí, así
                # que el siguiente intento no necesita re-navegar.
                error = f"SIN_CONFIRMAR::{e}"
                self.log(f"⚠ Sin confirmar con **{nombre}**: {e}")
                self.diag("reintento", {
                    "contacto": nombre, "numero": numero,
                    "intento_que_fallo": intento + 1,
                    "motivo": "no se pudo confirmar el envío (ver evidencia arriba)",
                    "requiere_reabrir_chat": False,
                    "va_a_reintentar": intento + 1 < 2,
                })
                intento += 1
                time.sleep(random.uniform(2, 5))

            except Exception as e:
                error = str(e)
                self.log(f"❌ Error con **{nombre}**: {error}")
                # Cualquier otro fallo (no cargó el chat, no encontró un
                # botón, WhatsApp cambió algo en la página) deja la
                # sesión en un estado dudoso -- por seguridad, el
                # siguiente intento SÍ vuelve a abrir el chat desde cero.
                chat_abierto = False
                # A diferencia de arriba, aquí puede ser CUALQUIER fallo
                # -- se guarda el traceback completo, no solo el
                # mensaje resumido, para poder ver la línea exacta donde
                # truena en vez de adivinar por el texto del error.
                self.diag("error_no_confirmacion", {
                    "contacto": nombre, "numero": numero,
                    "intento_que_fallo": intento + 1,
                    "error_resumido": error,
                    "traceback_completo": traceback.format_exc(),
                    "requiere_reabrir_chat": True,
                    "va_a_reintentar": intento + 1 < 2,
                })
                intento += 1
                time.sleep(random.uniform(2, 5))

        self.diag("contacto_fallido_definitivo", {
            "contacto": nombre, "numero": numero,
            "error_final": error, "intentos_realizados": intento,
        })
        return False, error

    # -------------------------
    # Pausas anti-bloqueo
    # -------------------------
    def controlar_pausas(self):
        if self.contador_envios > 0 and self.contador_envios % self.bloque_envio == 0:
            pausa = random.uniform(*self.velocidad["pausa_media"])
            self.log(f"⏸ Pausa media: {round(pausa)}s")
            self._esperar_con_stop(pausa)
            self.bloque_envio = random.randint(*self.velocidad["bloque_envio"])

        if self.contador_envios > 0 and self.contador_envios % self.bloque_grande == 0:
            pausa = random.uniform(*self.velocidad["pausa_larga"])
            self.log(f"🛑 Pausa larga: {round(pausa)}s")
            self._esperar_con_stop(pausa)
            self.bloque_grande = random.randint(*self.velocidad["bloque_grande"])

    def _esperar_con_stop(self, segundos):
        fin = time.time() + segundos
        while time.time() < fin:
            self._chequear_stop()
            time.sleep(0.5)

    # -------------------------
    # Proceso completo de la campaña
    # -------------------------
    def _guardar_progreso_excel(self, df, ruta_excel):
        """
        Guarda el progreso actual en el Excel real -- se llama después
        de CUALQUIER cambio de Estado (enviado, error, sin confirmar,
        sin segmento, omitido), no solo tras un intento de envío real.
        Antes, los casos "Sin segmento" y "Omitido" solo actualizaban
        el Estado en memoria y se saltaban sin guardar -- si ese
        contacto era el último de la lista, el cambio nunca llegaba a
        quedar guardado en el archivo.
        """
        try:
            df.drop(columns=["_num"]).to_excel(ruta_excel, index=False)
        except PermissionError:
            raise Exception(
                f"No se pudo guardar el progreso en el Excel porque está abierto en otro "
                f"programa (probablemente Excel mismo). Cierra el archivo '{os.path.basename(ruta_excel)}' "
                f"y reanuda la campaña."
            )

    def procesar_campana(self, ruta_excel, segmentos, nombre_campana, campana_id):
        """
        segmentos: lista de dicts:
          {"nombre": str, "desde": int, "hasta": int, "modulos": [ {tipo, contenido|ruta}, ... ]}
        campana_id: ya debe existir en la base de datos (lo crea la capa de la API
        antes de llamar a este método), así que aquí solo se actualiza su estado.
        """
        self.segmentos = segmentos

        df = pd.read_excel(ruta_excel, dtype=str).fillna("")

        # Modo Básico: el Excel puede no traer columna "Numero" (el usuario
        # no la necesita ver). Se sintetiza automáticamente en orden.
        if "Numero" not in df.columns:
            df["Numero"] = [str(i + 1) for i in range(len(df))]

        faltantes = [c for c in ["Nombre", "Celular"] if c not in df.columns]
        if faltantes:
            raise Exception(f"Faltan columnas en el Excel: {', '.join(faltantes)}")

        if "Estado" not in df.columns:
            df["Estado"] = ""
        if "Error" not in df.columns:
            df["Error"] = ""

        df["_num"] = pd.to_numeric(df["Numero"], errors="coerce")

        total = len(df)
        self.progress_callback(0, total)

        # Reinicio preventivo del navegador: WhatsApp Web va acumulando
        # cosas en la página mientras más chats se visitan (nunca se
        # "limpia" solo) -- en una campaña larga esto puede ir haciendo
        # que Chrome se vuelva más lento con el tiempo. En vez de
        # esperar a que falle por acumulación, se cierra y se vuelve a
        # abrir la sesión de forma ordenada cada cierto número de
        # contactos procesados (no solo enviados -- cuenta cualquier
        # intento real, haya salido bien o no).
        proximo_reinicio = random.randint(150, 200)
        contactos_procesados_desde_reinicio = 0

        try:
            for i in range(total):
                self._chequear_stop()
                self._chequear_pausa()

                if contactos_procesados_desde_reinicio >= proximo_reinicio:
                    self.log(f"🔄 Reinicio preventivo del navegador tras {contactos_procesados_desde_reinicio} contactos procesados (mantenimiento normal, no es un error).")
                    self.diag("reinicio_preventivo_navegador", {
                        "contactos_procesados": contactos_procesados_desde_reinicio,
                        "fila_actual": i,
                    })
                    marca_reinicio = time.time()
                    self.cerrar_navegador()
                    self.iniciar_navegador()
                    self.diag("reinicio_preventivo_completado", {
                        "duracion_seg": round(time.time() - marca_reinicio, 2),
                    })
                    contactos_procesados_desde_reinicio = 0
                    proximo_reinicio = random.randint(150, 200)

                fila = df.loc[i]
                nombre = fila.get("Nombre", "")

                if str(fila.get("Estado", "")).lower() == "enviado":
                    self.progress_callback(i + 1, total)
                    continue

                # "Enviar" es la decisión del usuario (independiente de
                # "Estado", que es del motor) -- cualquier valor que NO
                # sea exactamente "no" (sin importar mayúsculas ni
                # espacios de sobra) se trata como "sí, mándale". Se
                # tolera así, en vez de exigir el texto exacto "No",
                # porque la columna puede editarse por fuera del
                # programa a mano, sin pasar por el desplegable.
                valor_enviar = str(fila.get("Enviar", "") or "").strip().lower()
                if valor_enviar == "no":
                    df.loc[i, "Estado"] = "Omitido"
                    self._guardar_progreso_excel(df, ruta_excel)
                    self.progress_callback(i + 1, total)
                    continue

                # Se decide el segmento por el NOMBRE real que tiene el
                # contacto en la columna "Segmento" del Excel -- ya no
                # por su posición numérica. Esto evita el problema que
                # tenía el método anterior: dos contactos del mismo
                # segmento que quedaran separados en el Excel (por
                # ejemplo, tras editar uno en medio) se reconocían como
                # dos segmentos distintos, y solo el primero contaba.
                #
                # Se cae al método viejo (por posición, Desde/Hasta)
                # solo como respaldo -- para Modo Básico (que no usa
                # columna "Segmento") y para no romper una campaña
                # vieja que ya estuviera pausada con el método manual
                # de antes.
                segmento_encontrado = None
                etiqueta_segmento = str(fila.get("Segmento", "") or "").strip()

                if etiqueta_segmento:
                    for seg in self.segmentos:
                        if seg["nombre"].strip() == etiqueta_segmento:
                            segmento_encontrado = seg
                            break

                if segmento_encontrado is None:
                    num_secuencial = fila["_num"]
                    for seg in self.segmentos:
                        # Los segmentos nuevos (por nombre) no traen
                        # desde/hasta -- solo los guardados con el
                        # método viejo de posición los tienen.
                        desde = seg.get("desde")
                        hasta = seg.get("hasta")
                        if desde is not None and hasta is not None and pd.notna(num_secuencial) and desde <= num_secuencial <= hasta:
                            segmento_encontrado = seg
                            break

                if segmento_encontrado is None:
                    df.loc[i, "Estado"] = "Sin segmento"
                    self._guardar_progreso_excel(df, ruta_excel)
                    self.progress_callback(i + 1, total)
                    continue

                ok, error = self.procesar_contacto(fila, segmento_encontrado["modulos"], segmento_encontrado["nombre"])
                contactos_procesados_desde_reinicio += 1

                if ok:
                    df.loc[i, "Estado"] = "Enviado"
                    df.loc[i, "Error"] = ""
                    self.contador_envios += 1
                    # Contacto persistente entre campañas -- si es la
                    # primera vez que se ve este número, queda registrado
                    # desde ahora; si ya existía, se actualiza sin tocar
                    # la etapa en la que ya estaba.
                    db.upsert_contacto(
                        numero=fila.get("Celular", ""),
                        nombre=nombre,
                    )
                    db.asegurar_contacto_en_tablero(campana_id, fila.get("Celular", ""))
                elif error.startswith("SIN_CONFIRMAR::"):
                    # No es un error comprobado -- puede que sí haya
                    # llegado y solo no se alcanzó a confirmar a tiempo.
                    # Se guarda aparte para que el reintento y los
                    # reportes no lo traten igual que un número inválido.
                    df.loc[i, "Estado"] = "Sin confirmar"
                    df.loc[i, "Error"] = error.replace("SIN_CONFIRMAR::", "", 1)
                else:
                    df.loc[i, "Estado"] = "Error"
                    df.loc[i, "Error"] = error

                db.registrar_envio(
                    campana_id=campana_id,
                    campana_nombre=nombre_campana,
                    segmento=segmento_encontrado["nombre"],
                    nombre=nombre,
                    numero=fila.get("Celular", ""),
                    empresa=fila.get("Empresa", ""),
                    estado=df.loc[i, "Estado"],
                    error=df.loc[i, "Error"] if not ok else "",
                )

                self._guardar_progreso_excel(df, ruta_excel)
                self.progress_callback(i + 1, total)

                self.controlar_pausas()
                self._esperar_con_stop(random.uniform(*self.velocidad["delay_contacto"]))

        except EnvioDetenido:
            db.actualizar_estado_campana(campana_id, "Pausada")
            self.log("⏹ Campaña detenida. Puedes retomarla luego desde el Inicio.")
            raise
        except Exception:
            db.actualizar_estado_campana(campana_id, "Pausada")
            raise
        else:
            db.actualizar_estado_campana(campana_id, "Finalizada")
            self.log("🎉 Campaña finalizada")
